﻿using UnityEngine;
#if !IS_ANDROID
using UnityEngine.XR;
#endif

public class GestureAndControllerInputModeManager : MonoBehaviour
{
#if !IS_ANDROID
    // ========== 手势相关 ==========
    private OVRHand leftHand;
    private OVRSkeleton leftskeleton;

    private OVRHand rightHand;
    private OVRSkeleton rightskeleton;

    bool prevGesture1 = false;
    bool prevGesture2 = false;
    bool prevGesture3 = false;

    // ========== 控制器相关 ==========
    private float holdTime = 0f;
    private bool controllerModeActivated = false;

    private XRNode leftinputSource = XRNode.LeftHand;
    private XRNode rightinputSource = XRNode.RightHand;

    // ========== 模式状态 ==========
    private AudioMode RobotAudioMode;
    private AudioMode PreviousAudioMode = AudioMode.SLEEP;
    private VideoMode RobotVideoMode;
    private VideoMode PreviousVideoMode = VideoMode.PERSPECTIVE;
    private RobotMode RobotStateMode;
    private RobotMode PreviousRobotMode = RobotMode.Home;

    private void Awake()
    {
        leftHand = DataManager.Instance.leftHand;
        rightHand = DataManager.Instance.rightHand;
        leftskeleton = DataManager.Instance.leftSkeleton;
        rightskeleton = DataManager.Instance.rightSkeleton;
    }

    void Update()
    {
        HandleControllerInput(); // 手柄控制
        HandleHandGestures();    // 手势控制
    }


    // ==========================================================
    //                  手柄按键模式（原逻辑）
    // ==========================================================
    int menuCount;
    void HandleControllerInput()
    {
        // 1️⃣ 四个扳机同时按    // 获取按钮状态
        bool LHT = OVRInput.Get(OVRInput.Button.PrimaryHandTrigger);
        bool RHT = OVRInput.Get(OVRInput.Button.SecondaryHandTrigger);
        bool LIT = OVRInput.Get(OVRInput.Button.PrimaryIndexTrigger);
        bool RIT = OVRInput.Get(OVRInput.Button.SecondaryIndexTrigger);
        bool AButton = OVRInput.Get(OVRInput.Button.One);
        bool BButton = OVRInput.Get(OVRInput.Button.Two);
        bool XButton = OVRInput.Get(OVRInput.Button.Three);
        bool menuButton = OVRInput.GetDown(OVRInput.Button.Start);

        bool AButtonDown = OVRInput.GetDown(OVRInput.Button.One);
        bool BButtonDown = OVRInput.GetDown(OVRInput.Button.Two);
        if (menuButton) 
        {
            menuCount++;
            if (menuCount % 2 == 0)
            {
                OVRManager.instance.isInsightPassthroughEnabled = false;
            }
            else
            {
                OVRManager.instance.isInsightPassthroughEnabled = true;
            }
        }


        //DebugTextManager.Instance._debugText2.text = "LHT:" + LHT + "RHT:" + RHT + "LIT:" + LIT + "RIT:" + RIT +
        //    "AButton:" + AButton + "BButton:" + BButton + "XButton:" + XButton;
        // Oculus 按钮下 → 调整高度        
        // 四个扳机长按一秒后，通过右摇杆的上为加，下为减取值，每次差值0.1，最高高度为1，最低为0.44
        if (LHT && RHT && LIT && RIT)
        {
            // 检测长按一秒（需要添加计时逻辑）
            if (AreAllTriggersLongPressed(1f)) // 需要实现这个长按检测方法
            {
                float rightStickY = OVRInput.Get(OVRInput.Axis2D.SecondaryThumbstick).y;
                if (Mathf.Abs(rightStickY) > 0.2f) // 添加死区避免微小输入
                {
                    float tempheight = DataManager.Instance.robotheight;
                    if (rightStickY > 0)
                    {
                        // 上推摇杆增加高度
                        tempheight += 0.1f;
                    }
                    else if (rightStickY < 0)
                    {
                        // 下拉摇杆减少高度
                        tempheight -= 0.1f;
                    }

                    // 限制高度在0.44-1之间
                    DataManager.Instance.robotheight = Mathf.Clamp(tempheight, 0.44f, 1f);

                    DataManager.Instance.robotheight = (float)System.Math.Round(DataManager.Instance.robotheight, 2);

                    ResetAllTriggersTimer();
                }
            }
        }
        else
        {
            // 重置长按计时器（如果不是四个扳机同时按下）
            ResetAllTriggersTimer();
        }

        // 2️⃣ 如果不是四个扳机同时按下，IndexTrigger 控制手部角度
        //长按一秒LIT+左手轮盘输入的y为正，LeftHandAngle+=0.1； 值在0 - 1之间
        //长按一秒RIT+右手轮盘输入的y为正，RighttHandAngle+=0.1； 值在0 - 1之间
        // 2️⃣ 如果不是四个扳机同时按下，IndexTrigger 控制手部角度
        // 长按一秒LIT+左手轮盘输入的y为正，LeftHandAngle+=0.1；值在0 - 1之间
        // 长按一秒RIT+右手轮盘输入的y为正，RightHandAngle+=0.1；值在0 - 1之间
        if (!(LHT && RHT && LIT && RIT))
        {
            // 左手控制
            if (LIT)
            {
                // 检测长按一秒（需要添加计时逻辑）
                // 这里假设有长按检测，实际需要您实现计时器
                if (IsLITLongPressed(1f)) // 需要实现这个长按检测方法
                {
                    litPressTime = 0;
                    float leftStickY = OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick).y;
                    if (leftStickY > 0.2f)
                    {
                        DataManager.Instance.LeftHandAngle += 0.1f;
                        // 限制在0-1之间
                        DataManager.Instance.LeftHandAngle = Mathf.Clamp(DataManager.Instance.LeftHandAngle, 0f, 1f);
                    }
                    else if (leftStickY < -0.2f)
                    {
                        DataManager.Instance.LeftHandAngle -= 0.1f;
                        // 限制在0-1之间
                        DataManager.Instance.LeftHandAngle = Mathf.Clamp(DataManager.Instance.LeftHandAngle, 0f, 1f);
                    }
                }
            }
            else 
            {
                litPressTime = 0;
            }

            // 右手控制
            if (RIT)
            {
                // 检测长按一秒
                if (IsBITLongPressed(1f)) // 需要实现这个长按检测方法
                {
                    float rightStickY = OVRInput.Get(OVRInput.Axis2D.SecondaryThumbstick).y;
                    if (rightStickY > 0.2f)
                    {
                        DataManager.Instance.RightHandAngle += 0.1f;
                        // 限制在0-1之间
                        DataManager.Instance.RightHandAngle = Mathf.Clamp(DataManager.Instance.RightHandAngle, 0f, 1f);
                    }
                    else if (rightStickY < -0.2f)
                    {
                        DataManager.Instance.RightHandAngle -= 0.1f;
                        // 限制在0-1之间
                        DataManager.Instance.RightHandAngle = Mathf.Clamp(DataManager.Instance.RightHandAngle, 0f, 1f);
                    }
                    bitPressTime = 0;
                }
            }
            else
            {
                bitPressTime = 0;
            }
        }

        // 3️⃣ 仅同时按下 LHT + RHT 且不含 IndexTrigger → 持续 1 秒触发模式切换
        if (LHT && RHT && !(LIT || RIT))
        {
            holdTime += Time.deltaTime;

            if (holdTime >= 1f && !controllerModeActivated)
            {
                controllerModeActivated = true;
                if (AButton)
                    SwitchRobotMode();
                else if (BButton)
                    SwitchVoiceMode();
                else if (XButton)
                    SwitchVideoMode();
            }
        }
        else
        {
            holdTime = 0;
            controllerModeActivated = false;
        }

        // 4️⃣ 单独按 A/B 键调整速度（不受扳机干扰）
        if (AButtonDown && !(LHT || RHT || LIT || RIT))
        {
            if (DataManager.Instance.velocity < 30)
                DataManager.Instance.velocity += 5;
        }

        if (BButtonDown && !(LHT || RHT || LIT || RIT))
        {
            if (DataManager.Instance.velocity > 10)
                DataManager.Instance.velocity -= 5;
        }

    }

    // ==========================================================
    //                  手势控制（你设计的3种）
    // ==========================================================

    // 手势持续时间记录
    private float g1StartTime = -1f;
    private float g2StartTime = -1f;
    private float g3StartTime = -1f;
    private const float gestureHoldTime = 1f; // 持续时间 1 秒
    private float allTriggersPressTime = 0f;

    private bool AreAllTriggersLongPressed(float requiredTime)
    {
        allTriggersPressTime += Time.deltaTime;
        return allTriggersPressTime >= requiredTime;
    }

    private void ResetAllTriggersTimer()
    {
        allTriggersPressTime = 0f;
    }
    private float litPressTime = 0f;
    private float bitPressTime = 0f;

    private bool IsLITLongPressed(float requiredTime)
    {
            litPressTime += Time.deltaTime;
            return litPressTime >= requiredTime;
    }

    private bool IsBITLongPressed(float requiredTime)
    {
            bitPressTime += Time.deltaTime;
            return bitPressTime >= requiredTime;
    }
    void HandleHandGestures()
    {
        if (!leftHand.IsTracked || !rightHand.IsTracked) return;

        bool g1 = IsGesture1();
        bool g2 = IsGesture2();
        bool g3 = IsGesture3();

        //DebugTextManager.Instance._debugText1.text =
        //    "IsGesture1():" + g1 +
        //    "IsGesture2():" + g2 +
        //    "IsGesture3():" + g3 +
        //    "IsFist(isleft):" + IsFist(isleft) +
        //    " IsFist(isright):" + IsFist(!isleft) +
        //    " isopen(isleft):" + IsOpen(isleft) +
        //    " isopen(isright):" + IsOpen(!isleft) +
        //    " ispulmup(left):" + CheckPalmIsUp(leftskeleton) +
        //    " ispulmup(right):" + CheckPalmIsUp(rightskeleton)
        //    + "isrighttwo:" + IsRightTwo();

        // 三个姿势全部没触发 → 重置计时
        if (!g1 && !g2 && !g3)
        {
            g1StartTime = g2StartTime = g3StartTime = -1f;
            prevGesture1 = prevGesture2 = prevGesture3 = false;
            return;
        }

        float timeNow = Time.time;

        // ---------- 手势1 ---------- 
        if (g1)
        {
            if (g1StartTime < 0f) g1StartTime = timeNow; // 第一次发现手势
            if (!prevGesture1 && (timeNow - g1StartTime >= gestureHoldTime))
            {
                prevGesture1 = true;
                SwitchRobotMode();
                g1StartTime = -1f; // 防止重复触发
                return;
            }
        }
        else
        {
            g1StartTime = -1f;
            prevGesture1 = false;
        }

        // ---------- 手势2 ----------
        if (g2)
        {
            if (g2StartTime < 0f) g2StartTime = timeNow;
            if (!prevGesture2 && (timeNow - g2StartTime >= gestureHoldTime))
            {
                prevGesture2 = true;
                SwitchVoiceMode();
                g2StartTime = -1f;
                return;
            }
        }
        else
        {
            g2StartTime = -1f;
            prevGesture2 = false;
        }

        // ---------- 手势3 ----------
        if (g3)
        {
            if (g3StartTime < 0f) g3StartTime = timeNow;
            if (!prevGesture3 && (timeNow - g3StartTime >= gestureHoldTime))
            {
                prevGesture3 = true;
                SwitchVideoMode();
                g3StartTime = -1f;
                return;
            }
        }
        else
        {
            g3StartTime = -1f;
            prevGesture3 = false;
        }
    }

    // ==========================================================
    //                           手势判定
    // ==========================================================

    bool IsRightTwo()
    {
        return DataManager.Instance.rightFingerPos[2] < 0.5f &&
            DataManager.Instance.rightFingerPos[3] < 0.5f &&
            DataManager.Instance.rightFingerPos[4] > 0.6f &&
            DataManager.Instance.rightFingerPos[5] > 0.6f;
    }

    bool IsFist(bool isleft)        //是否弯曲
    {
        if (isleft)
        {
            return DataManager.Instance.leftFingerPos[2] > 0.7f &&
                DataManager.Instance.leftFingerPos[3] > 0.8f &&
                DataManager.Instance.leftFingerPos[4] > 0.8f &&
                DataManager.Instance.leftFingerPos[5] > 0.8f;
        }
        else
        {
            return DataManager.Instance.rightFingerPos[2] > 0.7f &&
                DataManager.Instance.rightFingerPos[3] > 0.8f &&
                DataManager.Instance.rightFingerPos[4] > 0.8f &&
                DataManager.Instance.rightFingerPos[5] > 0.8f;
        }
    }
    bool IsOpen(bool isleft)        //打开
    {
        if (isleft)
        {
            return DataManager.Instance.leftFingerPos[2] < 0.15f &&
                DataManager.Instance.leftFingerPos[3] < 0.15f &&
                DataManager.Instance.leftFingerPos[4] < 0.15f &&
                DataManager.Instance.leftFingerPos[5] < 0.15f;
        }
        else
        {
            return DataManager.Instance.rightFingerPos[2] < 0.15f &&
                DataManager.Instance.rightFingerPos[3] < 0.15f &&
                DataManager.Instance.rightFingerPos[4] < 0.15f &&
                DataManager.Instance.rightFingerPos[5] < 0.15f;
        }
    }

    /// <summary>
    /// 判断手掌朝向（只返回朝上、朝下、其他）
    /// </summary>
    public int CheckPalmIsUp(OVRSkeleton skeleton)
    {
        if (skeleton == null || !skeleton.IsInitialized)
            return 0;

        // 直接使用手掌骨骼的法线朝向
        foreach (var bone in skeleton.Bones)
        {
            if (bone.Id == OVRSkeleton.BoneId.XRHand_Palm)
            {
                Vector3 palmNormal = bone.Transform.up;
                float dot = Vector3.Dot(palmNormal, Vector3.up);

                if (dot > 0.5f)
                    return -1;
                else if (dot < -0.5f)
                    return 1;
                else
                    return 0;
            }
        }
        return 0;

    }

    bool isleft = true;

    bool IsGesture1()       //双手握拳并手掌朝上   切换机器人模式
    {
        return IsFist(isleft) && IsFist(!isleft) && CheckPalmIsUp(leftskeleton) == 1 && CheckPalmIsUp(rightskeleton) == 1;
    }

    bool IsGesture2()       //双手握拳并手掌朝下       切换声音模式
    {
        return (IsFist(isleft) && CheckPalmIsUp(leftskeleton) == -1 && IsFist(!isleft) && CheckPalmIsUp(rightskeleton) == -1);
    }

    bool IsGesture3()     //双手捏合并手掌朝上         切换视频模式
    {
        bool leftPinching = leftHand.GetFingerIsPinching(OVRHand.HandFinger.Index);
        bool rightPinching = rightHand.GetFingerIsPinching(OVRHand.HandFinger.Index);
        return (leftPinching && CheckPalmIsUp(leftskeleton) == 1 && rightPinching && CheckPalmIsUp(rightskeleton) == 1);
    }

    // ==========================================================
    //                       模式切换函数
    // ==========================================================

    private void SwitchRobotMode()
    {
        switch (RobotStateMode)
        {
            case RobotMode.Home:
                RobotStateMode = RobotMode.Async;
                OVRReset.Instance.AlignChildToWorld();
                DataManager.Instance.RefreshBodyOriginFromHead();
                PreviousRobotMode = RobotMode.Home;
                break;
            case RobotMode.Async:
                // 判断上一次是否是 Home 来决定下一步
                if (PreviousRobotMode == RobotMode.Home)
                {
                    RobotStateMode = RobotMode.Sync;
                    OVRReset.Instance.AlignChildToWorld();
                    DataManager.Instance.RefreshBodyOriginFromHead();
                }
                else
                {
                    RobotStateMode = RobotMode.Home;
                }
                PreviousRobotMode = RobotMode.Async;
                break;
            case RobotMode.Sync:
                RobotStateMode = RobotMode.Async;
                OVRReset.Instance.AlignChildToWorld();
                DataManager.Instance.RefreshBodyOriginFromHead();
                PreviousRobotMode = RobotMode.Sync;
                break;
        }

        // 保存上一次模式
        TriggerHapticFeedback();
        DataManager.Instance.currobotState.SET_ROBOT_MODE = (int)RobotStateMode;
        DebugState();
    }


    private void SwitchVoiceMode()
    {
        switch (RobotAudioMode)
        {
            case AudioMode.SLEEP:
                RobotAudioMode = AudioMode.DIRECT;
                PreviousAudioMode = AudioMode.SLEEP;
                break;
            case AudioMode.DIRECT:
                // 判断上一次是否是 Home 来决定下一步
                if (PreviousAudioMode == AudioMode.SLEEP)
                {
                    RobotAudioMode = AudioMode.REALTIME;
                }
                else 
                {
                    RobotAudioMode = AudioMode.SLEEP;
                }
                PreviousAudioMode = AudioMode.DIRECT;

                break;
            case AudioMode.REALTIME:
                RobotAudioMode = AudioMode.DIRECT;
                PreviousAudioMode = AudioMode.REALTIME;
                break;
        }
        TriggerHapticFeedback();
        DataManager.Instance.currobotState.SET_AUDIO_MODE = (int)RobotAudioMode;
        DebugState();
    }

    private void SwitchVideoMode()
    {
        switch (RobotVideoMode)
        {
            case VideoMode.PERSPECTIVE:
                RobotVideoMode = VideoMode.Front;
                PreviousVideoMode = VideoMode.PERSPECTIVE;
                break;
            case VideoMode.Front:
                // 判断上一次是否是 Home 来决定下一步
                if (PreviousVideoMode == VideoMode.PERSPECTIVE) 
                {
                    RobotVideoMode = VideoMode.Realsense;
                }
                else 
                {
                    RobotVideoMode = VideoMode.PERSPECTIVE;
                }
                PreviousVideoMode = VideoMode.Front;
                break;
            case VideoMode.Realsense:
                RobotVideoMode = VideoMode.Front;
                PreviousVideoMode = VideoMode.Realsense;

                break;
        }

        TriggerHapticFeedback();
        DataManager.Instance.currobotState.SET_VIDEO_MODE = (int)RobotVideoMode;
        DebugState();
    }

    void DebugState() 
    {
        DebugTextManager.Instance._debugClientstatetext.text = "ClientMode:";
        DebugTextManager.Instance._debugClientstatetext.text += "Robot Mode = " + RobotStateMode;
        DebugTextManager.Instance._debugClientstatetext.text += "Video Mode = " + RobotVideoMode;
        DebugTextManager.Instance._debugClientstatetext.text += "Audio Mode = " + RobotAudioMode;
    }

    // ==========================================================
    //                           震动反馈
    // ==========================================================

    private void TriggerHapticFeedback()
    {
        InputDevices.GetDeviceAtXRNode(leftinputSource).SendHapticImpulse(0, 0.5f, 0.2f);
        InputDevices.GetDeviceAtXRNode(rightinputSource).SendHapticImpulse(0, 0.5f, 0.2f);
    }
#endif
}
