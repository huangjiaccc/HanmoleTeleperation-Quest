using System;
#nullable enable

[Serializable]

public class HeartbeatMessage 
{
    public string user_email;
    public string device_id;
    public string target_device_id;
    public string token;
}
[Serializable]

public class HelmeData 
{
    public string device_id;      //唯一ID
    public long ts;      //时间戳
    //public string target_device_id;     //机器人唯一id
    public int video_last_received_id;      //回传视频最新的id
    public float video_rtt_mean_ms;       //视频延迟
    public float hand_left;       //左手开合角度
    public float hand_right;      //右手开合角度
    public float[] pos_head;    //头盔位置
    public float[] quat_head;    //头盔转向
    public float[] pos_left_hand;   //左手弯曲程度  拇指最底，到拇指中，然后食指中指无名指尾指
    public float[] pos_left_arm;    //左手位置
    public float[] quat_left_arm;    //左手转向
    public float[] pos_right_hand;   //右手弯曲程度  拇指最底，到拇指中，然后食指中指无名指尾指
    public float[] pos_right_arm;   //右手位置
    public float[] quat_right_arm;   //右手转向
    public float[] joystick_left;   //左轮盘值
    public float[] joystick_right;  //右轮盘值
    public float velocity;          //机器人速度
    public int hand_mode;           //"controller" | "handtracking";      0|1
    public float height;            //机器人高度
    public PartialCommand commands;     //相关机器状态
}

[System.Serializable]
public class PartialCommand
{
    public int? SET_ROBOT_MODE;
    public int? SET_VIDEO_MODE;
    public int? SET_AUDIO_MODE;
    public float? SET_AUDIO_VOLUME;
    public float? MOVE_IDX_LEFT_X;
    public float? MOVE_IDX_LEFT_Y;
    public float? MOVE_IDX_RIGHT_X;
    public float? MOVE_IDX_RIGHT_Y;
    public float? SET_LEFT_ROTATE_ANGLE;
    public float? SET_RIGHT_ROTATE_ANGLE;
    public ACTION? ACTION;
    public TTS? TTS;
}

[System.Serializable]
public class ACTION 
{
    public string? cmd;
    public string? name;
}

[System.Serializable]
public class TTS
{
    public string? cmd;
    public string? text;
}


[Serializable]

public class RobotState 
{
    public int SET_ROBOT_MODE = (int)RobotMode.Home;           //机器状态 //1、同步、异步、睡眠 //2、语音状态1仅能听到机器人的声音，状态2为与机器人AI对话，状态3双向对话  //3、小车模式
    public int SET_VIDEO_MODE = (int)VideoMode.PERSPECTIVE;           //视频模式
    public int SET_AUDIO_MODE = (int)AudioMode.SLEEP;       //音频模式
    public float SET_AUDIO_VOLUME;     //设置音量
    public float MOVE_IDX_LEFT_X;           //"MOVE_IDX_LEFT_X": lambda v: self._handle_move_idx("left", "x", int (v)),
    public float MOVE_IDX_LEFT_Y;           //"MOVE_IDX_LEFT_Y": lambda v: self._handle_move_idx("left", "y", int (v)),
    public float MOVE_IDX_RIGHT_X;          //"MOVE_IDX_RIGHT_X": lambda v: self._handle_move_idx("right", "x", int (v)),
    public float MOVE_IDX_RIGHT_Y;          //"MOVE_IDX_RIGHT_Y": lambda v: self._handle_move_idx("right", "y", int (v)),
    public float SET_LEFT_ROTATE_ANGLE;     //"SET_LEFT_ROTATE_ANGLE": lambda v: self._safe_float(//    self._handle_set_rotate_angle, v, side="left"//),
    public float SET_RIGHT_ROTATE_ANGLE;    //"SET_RIGHT_ROTATE_ANGLE": lambda v: self._safe_float(  //    self._handle_set_rotate_angle, v, side="right"//),

    public ACTION ACTION = new ACTION();           //动作action
    public TTS TTS = new TTS();                 //TTS

    public RobotState Clone(RobotState src)
    {
        if (src == null)
        {
            return new RobotState();
        }

        return new RobotState
        {
            SET_ROBOT_MODE = src.SET_ROBOT_MODE,
            SET_VIDEO_MODE = src.SET_VIDEO_MODE,
            SET_AUDIO_MODE = src.SET_AUDIO_MODE,
            SET_AUDIO_VOLUME = src.SET_AUDIO_VOLUME,
            MOVE_IDX_LEFT_X = src.MOVE_IDX_LEFT_X,
            MOVE_IDX_LEFT_Y = src.MOVE_IDX_LEFT_Y,
            MOVE_IDX_RIGHT_X = src.MOVE_IDX_RIGHT_X,
            MOVE_IDX_RIGHT_Y = src.MOVE_IDX_RIGHT_Y,
            SET_LEFT_ROTATE_ANGLE = src.SET_LEFT_ROTATE_ANGLE,
            SET_RIGHT_ROTATE_ANGLE = src.SET_RIGHT_ROTATE_ANGLE,
            ACTION = CloneAction(src.ACTION),
            TTS = CloneTTS(src.TTS)
        };
    }

    private static ACTION CloneAction(ACTION src)
    {
        if (src == null)
        {
            return null;
        }

        return new ACTION
        {
            cmd = src.cmd,
            name = src.name
        };
    }

    private static TTS CloneTTS(TTS src)
    {
        if (src == null)
        {
            return null;
        }

        return new TTS
        {
            cmd = src.cmd,
            text = src.text
        };
    }
}

[Serializable]
// 机器工作模式枚举
public enum RobotMode
{
    Home,        // 睡眠模式
    Async,      // 异步模式
    Sync        // 同步模式
}
[Serializable]

public enum AudioMode
{
    SLEEP,  //  仅能听到机器人的声音
    DIRECT,  // 双向对话
    REALTIME // 机器人AI对话
}
[Serializable]
public enum VideoMode 
{
    PERSPECTIVE,
    Front,          //两个鱼目相机
    Realsense       //鱼目相机+深度相机
}

public enum DecoderFlavor
{
    H264,
    HEVC,
    AV1

}

[Serializable]

public class ServerRobotData
{
    public string id;
    public string name;
    public string device_id;
    public string store;
    public string ip_address;
    public string device_type;
    public string last_seen;
    public string status;
    public string user_email;
    public string created_at;
    public string updated_at;
}
[Serializable]

public class ServerRobotList 
{
    public ServerRobotData[]  list;
}

[System.Serializable]
public class RobotStateMessage
{
    public string type;
    public RobotStateData data;
}

[System.Serializable]
public class RobotStateData
{
    public int audio_mode;
    public float? robot_height; // 使用可空类型处理null
    public int robot_mode;
    public int video_mode;
}

[System.Serializable]
public class RobotJointStateMessage
{
    public string type;
    public RobotJointStateData data;
}

[System.Serializable]
public class RobotJointStateData
{
    public float[] joints_pos;
    public float[] left_arm_pos;
    public float[] leg_pos;
    public float[] neck_pos;
    public float[] right_arm_pos;
    public long ts; // 时间戳
}

