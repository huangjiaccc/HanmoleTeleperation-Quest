using System.IO;
using UnityEngine;
public static class RuntimeServerConfig
{
    public static string serverIp;
    public static int serverVideoPort;
    public static int serverDataPort;
    public static int serverAudioPort;
    public static int clientVideoPort;
    public static int clientAudioPort;
    public static int clientDataPort;
    public static string configPath => Path.Combine(Application.persistentDataPath, "server_config.json");
    public static string streamingconfigPath = Path.Combine(Application.streamingAssetsPath, "server_config.json");

    // ���� JSON ���л��Ķ���
    [System.Serializable]
    private class SerializableConfig
    {
        public string defaultServerIp;
        public int defaultVideoPort;
        public int defaultDataPort;
        public int defaultAudioPort;
        public int defaultClientVideoPort;
        public int defaultClientAudioPort;
        public int defaultClientDataPort;
    }
    public static void Load(ServerConfigSO defaultConfig)
    {
        if (File.Exists(configPath))
        {
            string json = File.ReadAllText(configPath);
            // תΪ��ʱ����
            SerializableConfig sc = JsonUtility.FromJson<SerializableConfig>(json);
            // �������ֶ�д�� static �ֶ�
            serverIp = sc.defaultServerIp;
            serverVideoPort = sc.defaultVideoPort;
            serverDataPort = sc.defaultDataPort;
            serverAudioPort = sc.defaultAudioPort;
            clientVideoPort = sc.defaultClientVideoPort;
            clientAudioPort = sc.defaultClientAudioPort;
            clientDataPort = sc.defaultClientDataPort;
        }
        else
        {
            // ʹ��Ĭ�� SO ����
            serverIp = defaultConfig.defaultServerIp;
            serverVideoPort = defaultConfig.defaultVideoPort;
            serverDataPort = defaultConfig.defaultDataPort;
            serverAudioPort = defaultConfig.defaultAudioPort;
            clientVideoPort = defaultConfig.defaultClientVideoPort;
            clientAudioPort = defaultConfig.defaultClientAudioPort;
            clientDataPort = defaultConfig.defaultClientDataPort;
        }
    }
    public static void Save()
    {
        SerializableConfig sc = new SerializableConfig()
        {
            defaultServerIp = serverIp,
            defaultVideoPort = serverVideoPort,
            defaultDataPort = serverDataPort,
            defaultAudioPort = serverAudioPort,
            defaultClientVideoPort = clientVideoPort,
            defaultClientAudioPort = clientAudioPort,
            defaultClientDataPort = clientDataPort,
        };
        string json = JsonUtility.ToJson(sc, true);
        File.WriteAllText(configPath, json);
        NetClient.instance.ReloadUdpManagers();
    }
}
