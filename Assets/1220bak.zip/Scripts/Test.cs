using UnityEngine;
using Debug = AppLog;
using static Oculus.Interaction.Context;

public class Test : MonoBehaviour
{

    public enum ControlCommand
    {
        LeftCam_Left,
        LeftCam_Right,

        RightCam_Left,
        RightCam_Right,

        LeftMove_Up,
        LeftMove_Down,
        LeftMove_Left,
        LeftMove_Right,

        RightMove_Up,
        RightMove_Down,
        RightMove_Left,
        RightMove_Right,
    }

    [SerializeField]
    private ControlCommand command;

    public ControlCommand Command => command;

    public void OnClick()
    {
        Debug.Log($"Button Clicked: {command}");
        OnCommand(command);
    }
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public void OnCommand(ControlCommand cmd)
    {
        // ������ͳһ����
        // 1. ������
        // 2. �������
        // 3. ���ƻ�����
        // 4. ��¼��־

    }
}
