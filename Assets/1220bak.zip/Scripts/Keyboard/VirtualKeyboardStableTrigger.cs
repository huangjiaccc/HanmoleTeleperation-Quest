﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Debug = AppLog;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class VirtualKeyboardStableTrigger : MonoBehaviour
{
    [Header("虚拟键盘配置")]
#if !IS_ANDROID
    public OVRVirtualKeyboard virtualKeyboard;
#endif
    public InputField targetInputField;
    [SerializeField] private List<InputField> targetInputFields = new List<InputField>();

#if !IS_ANDROID
    private OVRVirtualKeyboard.KeyboardPosition keyboardPosition = OVRVirtualKeyboard.KeyboardPosition.Far;
    private OVRVirtualKeyboardInputFieldTextHandlerExtral textHandler;
#endif
    public float keyboardShowDelay = 0.1f;
    private bool isKeyboardReady;
    private bool isKeyboardVisible;
    private bool isAdjustingPosition;
    private Coroutine hideCoroutine;
    private readonly List<InputField> resolvedInputFields = new List<InputField>();
    private readonly HashSet<InputField> registeredInputFields = new HashSet<InputField>();
    private InputField currentInputField;

    void Start()
    {
        Log("VirtualKeyboardStableTrigger 开始初始化");

        ResolveInputFields();
        RegisterResolvedFields();

#if !IS_ANDROID
        if (virtualKeyboard == null)
        {
            virtualKeyboard = FindObjectOfType<OVRVirtualKeyboard>();
        }

        InitializeTextHandler();

        if (virtualKeyboard != null)
        {
            if (virtualKeyboard.gameObject.activeInHierarchy)
            {
                virtualKeyboard.gameObject.SetActive(false);
            }

            virtualKeyboard.CommitTextEvent.AddListener(OnKeyboardCommitText);
            virtualKeyboard.BackspaceEvent.AddListener(OnKeyboardBackspace);
            virtualKeyboard.EnterEvent.AddListener(OnKeyboardEnter);
            virtualKeyboard.UseSuggestedLocation(OVRVirtualKeyboard.KeyboardPosition.Far);
        }
        else
        {
            Debug.LogWarning("[VirtualKeyboard] 未找到 OVRVirtualKeyboard 实例。", this);
        }
#endif
        isKeyboardReady = true;
        Log("虚拟键盘触发器初始化完成");
    }
#if !IS_ANDROID
    private void InitializeTextHandler()
    {
        textHandler = GetComponent<OVRVirtualKeyboardInputFieldTextHandlerExtral>();
        if (textHandler == null)
        {
            textHandler = gameObject.AddComponent<OVRVirtualKeyboardInputFieldTextHandlerExtral>();
        }

        textHandler.AssignInputFields(resolvedInputFields);
        if (currentInputField == null && resolvedInputFields.Count > 0)
        {
            currentInputField = resolvedInputFields[0];
        }

        if (virtualKeyboard != null)
        {
            textHandler.InputField = currentInputField;
            virtualKeyboard.TextHandler = textHandler;
        }
    }
#endif

    private void ResolveInputFields()
    {
        resolvedInputFields.Clear();

        if (targetInputField == null)
        {
            targetInputField = GetComponent<InputField>();
        }
        AddResolvedField(targetInputField);

        if (targetInputFields != null)
        {
            foreach (var field in targetInputFields)
            {
                AddResolvedField(field);
            }
        }

        if (resolvedInputFields.Count == 0)
        {
            foreach (var field in GetComponentsInChildren<InputField>(true))
            {
                AddResolvedField(field);
            }
        }
    }

    private void AddResolvedField(InputField field)
    {
        if (field != null && !resolvedInputFields.Contains(field))
        {
            resolvedInputFields.Add(field);
        }
    }

    private void RegisterResolvedFields()
    {
        foreach (var field in resolvedInputFields)
        {
            RegisterField(field);
        }

        if (currentInputField == null && resolvedInputFields.Count > 0)
        {
            currentInputField = resolvedInputFields[0];
        }
    }

    private void RegisterField(InputField field)
    {
        if (field == null || !registeredInputFields.Add(field))
        {
            return;
        }

        field.readOnly = true;
        AttachPointerTrigger(field);

        if (currentInputField == null)
        {
            currentInputField = field;
        }
    }

    private void AttachPointerTrigger(InputField field)
    {
        var trigger = field.GetComponent<EventTrigger>();
        if (trigger == null)
        {
            trigger = field.gameObject.AddComponent<EventTrigger>();
        }

        if (trigger.triggers == null)
        {
            trigger.triggers = new List<EventTrigger.Entry>();
        }

        var clickEntry = new EventTrigger.Entry { eventID = EventTriggerType.PointerClick };
        clickEntry.callback.AddListener(_ => HandleInputFieldSelected(field));
        trigger.triggers.Add(clickEntry);

        var selectEntry = new EventTrigger.Entry { eventID = EventTriggerType.Select };
        selectEntry.callback.AddListener(_ => HandleInputFieldSelected(field));
        trigger.triggers.Add(selectEntry);

        var submitEntry = new EventTrigger.Entry { eventID = EventTriggerType.Submit };
        submitEntry.callback.AddListener(_ => HandleInputFieldSelected(field));
        trigger.triggers.Add(submitEntry);
    }

    private void EnsureFieldRegistered(InputField field)
    {
        if (!resolvedInputFields.Contains(field))
        {
            resolvedInputFields.Add(field);
        }
        if (!registeredInputFields.Contains(field))
        {
            RegisterField(field);
#if !IS_ANDROID
            textHandler?.AssignInputFields(resolvedInputFields);
#endif
        }
    }

    private void HandleInputFieldSelected(InputField field)
    {
        if (field == null)
        {
            return;
        }

        currentInputField = field;
#if !IS_ANDROID
        if (textHandler != null)
        {
            textHandler.InputField = field;
        }
#endif
        ShowVirtualKeyboard();
    }

    private void ShowVirtualKeyboard()
    {
        if (!isKeyboardReady)
        {
            return;
        }

        Log("调起虚拟键盘");

        if (hideCoroutine != null)
        {
            StopCoroutine(hideCoroutine);
            hideCoroutine = null;
        }

        StartCoroutine(ShowVirtualKeyboardWithDelay());
    }

    private IEnumerator ShowVirtualKeyboardWithDelay()
    {
        yield return new WaitForSeconds(keyboardShowDelay);
#if !IS_ANDROID
        if (virtualKeyboard != null)
        {
            if (!virtualKeyboard.gameObject.activeInHierarchy)
            {
                virtualKeyboard.gameObject.SetActive(true);
            }

            virtualKeyboard.UseSuggestedLocation(keyboardPosition);
            virtualKeyboard.InputEnabled = true;
            virtualKeyboard.UseSuggestedLocation(OVRVirtualKeyboard.KeyboardPosition.Far);

            isKeyboardVisible = true;

            Log("虚拟键盘已显示");
        }
#endif
    }

    private void OnKeyboardCommitText(string text)
    {
        Log($"键盘提交文本: {text}");
    }

    private void OnKeyboardBackspace()
    {
        Log("键盘按下退格");
    }

    private void OnKeyboardEnter()
    {
        Log("键盘按下回车");
        var field = currentInputField;
        if (field != null && field.lineType != InputField.LineType.MultiLineNewline)
        {
            HideVirtualKeyboard();
        }
    }

    public void HideVirtualKeyboard()
    {
#if !IS_ANDROID
        if (virtualKeyboard != null && virtualKeyboard.gameObject.activeInHierarchy)
        {
            virtualKeyboard.gameObject.SetActive(false);
            isKeyboardVisible = false;
            isAdjustingPosition = false;
            Log("虚拟键盘已隐藏");
        }
#endif
    }

    public void ScheduleHideKeyboard()
    {
        if (hideCoroutine != null)
        {
            StopCoroutine(hideCoroutine);
        }
        hideCoroutine = StartCoroutine(HideKeyboardWithDelay());
    }

    private IEnumerator HideKeyboardWithDelay()
    {
        yield return new WaitForSeconds(0.1f);
        HideVirtualKeyboard();
    }

    void Update()
    {
        CheckForExternalClicks();
    }

    private void CheckForExternalClicks()
    {
        if (!isKeyboardVisible || isAdjustingPosition)
        {
            return;
        }

        CheckControllerInput();
    }

    private void CheckControllerInput()
    {
#if !IS_ANDROID
        if (OVRInput.GetDown(OVRInput.Button.Two) && !isAdjustingPosition)
        {
            Log("控制器B按钮按下，隐藏键盘");
            HideVirtualKeyboard();
        }
#endif
    }

    private void Log(string message)
    {
        Debug.Log($"[VirtualKeyboard] {message}", this);
    }

    void OnDestroy()
    {
#if !IS_ANDROID
        if (virtualKeyboard != null)
        {
            virtualKeyboard.CommitTextEvent.RemoveListener(OnKeyboardCommitText);
            virtualKeyboard.BackspaceEvent.RemoveListener(OnKeyboardBackspace);
            virtualKeyboard.EnterEvent.RemoveListener(OnKeyboardEnter);
        }
#endif
    }
}
