using UnityEngine;
using TMPro;

public class KeyboardPreviewBar : MonoBehaviour
{
    public RectTransform previewBar;
    public TMP_InputField inputField;

    private TouchScreenKeyboard keyboard;
    private bool wasKeyboardVisible = false;

#if IS_ANDROID
    void Update()
    {
        if (keyboard != null && TouchScreenKeyboard.visible)
        {
            wasKeyboardVisible = true;

            // Android �������̸߶�
            float keyboardHeight = Screen.height - Screen.safeArea.yMax;

            // ��ʾԤ����
            if (!previewBar.gameObject.activeSelf)
                previewBar.gameObject.SetActive(true);

            float scale = previewBar.lossyScale.y;
            previewBar.anchoredPosition =
                new Vector2(0, keyboardHeight / scale + 20f);

            // ͬ����������
            previewBar.GetComponentInChildren<TextMeshProUGUI>().text =
                inputField.text;
        }
        else
        {
            if (wasKeyboardVisible)
            {
                wasKeyboardVisible = false;
                previewBar.gameObject.SetActive(false);
            }
        }
    }

    // TMP InputField �� OnSelect �ص�
    public void OnInputFieldSelected()
    {
        // ��Ҫ�Լ� Open!
        // ֻ��ȡ TMP ��ǰ����ʹ�õļ�������
        keyboard = inputField.touchScreenKeyboard;
    }
#endif
}
