using UnityEngine;
using TMPro;

public class FloatingKeyboardPreview : MonoBehaviour
{
    [Header("����Ԥ����")]
    [SerializeField]
    private RectTransform previewBar;

    [Header("������ʾ")]
    public TextMeshProUGUI previewText;

#if IS_ANDROID
    private TMP_InputField curField;
    private bool wasVisible = false;


    private void Start()
    {
        previewBar.gameObject.SetActive(false);
    }
    void Update()
    {
        if (TouchScreenKeyboard.visible)
        {
            wasVisible = true;

            // ��ʾ��
            if (!previewBar.gameObject.activeSelf)
                previewBar.gameObject.SetActive(true);

            previewBar.anchoredPosition =
                new Vector2(0, 0);

            // ͬ���ı�
            if (curField != null)
                previewText.text = curField.text;
        }
        else
        {
            if (wasVisible)
            {
                wasVisible = false;
                previewBar.gameObject.SetActive(false);
            }
        }
    }

    /// ����� InputField �� OnSelect ���ã�
    public void OnInputSelected(TMP_InputField field)
    {
        curField = field;
    }
#endif
}
