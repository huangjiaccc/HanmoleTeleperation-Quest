using System;
using System.Collections;
using Concentus;
using Concentus.Enums;
using UnityEngine;
using Debug = AppLog;

public class RecordingManager : MonoBehaviour
{
    [Header("Microphone")]
    [SerializeField] private int sampleRate = 16000;
    [SerializeField, Range(10, 100)] private int packetDurationMs = 20;
    [SerializeField, Min(1)] private int recordBufferSeconds = 10;

    [Header("Opus Send")]
    [SerializeField, Range(6000, 96000)] private int opusBitrate = 16000;
    [SerializeField, Range(0, 10)] private int opusComplexity = 5;
    [SerializeField] private bool opusUseVbr = true;
    [SerializeField] private bool opusUseInbandFec = false;
    [SerializeField] private bool opusUseDtx = false;
    [SerializeField, Min(256)] private int opusMaxPacketBytes = 2048;

    [Header("Debug")]
    [SerializeField] private bool debugMicrophonePosition = false;
    [SerializeField, Range(0.1f, 5f)] private float debugIntervalSeconds = 1f;

    [Header("Resilience")]
    [SerializeField] private bool autoRestartIfPositionStalls = true;
    [SerializeField, Range(0.5f, 10f)] private float stallRestartSeconds = 2f;

    [Header("Local Monitor (Test Playback)")]
    [SerializeField] private bool monitorToAudioStreamPlayer = true;
    [SerializeField, Range(0f, 5f)] private float monitorGain = 1f;


    private AudioClip recordingClip;
    private string microphone;
    private bool isRecording;

    private int lastSamplePosition;
    private float[] micPacketFloats;

    private IOpusEncoder opusEncoder;
    private byte[] opusPacketBytes;
    private int lastOpusPacketBytes;

    private float lastMicDebugAt;
    private int lastMicPosition = -999;
    private float lastMicPositionChangedAt;
    private int lastPumpPosition = -999;
    private float lastPumpPositionChangedAt;
    private int lastPumpedPackets;
    private int lastPumpedFrames;
    private long totalPumpedPackets;
    private long totalPumpedFrames;
    private float lastPacketRms;
    private float lastPacketPeak;

    private int FramesPerPacket => Mathf.Max(1, sampleRate * packetDurationMs / 1000);

    private void Start()
    {
        StartCoroutine(EnsureMicrophoneReady());
    }

    private IEnumerator EnsureMicrophoneReady()
    {
        bool hasAuth = Application.HasUserAuthorization(UserAuthorization.Microphone);
        if (!hasAuth)
        {
            yield return Application.RequestUserAuthorization(UserAuthorization.Microphone);
            hasAuth = Application.HasUserAuthorization(UserAuthorization.Microphone);
        }

        int deviceCount = Microphone.devices != null ? Microphone.devices.Length : 0;
        microphone = deviceCount > 0 ? Microphone.devices[0] : null;

        Debug.Log(
            "[RecordingManager] Mic auth=" + hasAuth +
            " devices=" + deviceCount +
            " selected=" + (microphone ?? "null"));

        if (microphone == null)
        {
            Debug.LogWarning("[RecordingManager] No microphone device available.");
        }
    }

    private void Update()
    {
        bool shouldRecord = false;
        if (DataManager.Instance != null)
        {
            shouldRecord = (DataManager.Instance.currobotState != null && DataManager.Instance.currobotState.SET_AUDIO_MODE == (int)AudioMode.DIRECT);
        }

        if (!shouldRecord)
        {
            if (isRecording)
            {
                StopRecording();
            }
            return;
        }

        if (!isRecording)
        {
            StartRecording();
        }

        if (isRecording)
        {
            PumpMicrophoneAndSend();
            DebugMicrophoneState();
        }
    }

    private void DebugMicrophoneState()
    {
        if (!debugMicrophonePosition)
        {
            return;
        }

        float now = Time.unscaledTime;
        if (now - lastMicDebugAt < debugIntervalSeconds)
        {
            return;
        }
        lastMicDebugAt = now;

        bool authorized = Application.HasUserAuthorization(UserAuthorization.Microphone);
        int deviceCount = Microphone.devices != null ? Microphone.devices.Length : 0;
        bool isMicRecording = microphone != null && Microphone.IsRecording(microphone);
        int position = microphone != null ? Microphone.GetPosition(microphone) : -2;
        int clipSamples = recordingClip != null ? recordingClip.samples : -1;
        int channels = recordingClip != null ? recordingClip.channels : -1;
        int clipFrequency = recordingClip != null ? recordingClip.frequency : -1;

        if (position != lastMicPosition)
        {
            lastMicPosition = position;
            lastMicPositionChangedAt = now;
        }

        int availableFrames = 0;
        if (position >= 0 && clipSamples > 0)
        {
            availableFrames = position - lastSamplePosition;
            if (availableFrames < 0) availableFrames += clipSamples;
        }

        //Debug.Log(
        //    "[MicDebug] auth=" + authorized +
        //    " devices=" + deviceCount +
        //    " mic=" + (microphone ?? "null") +
        //    " micRec=" + isMicRecording +
        //    " pos=" + position +
        //    " clipSamples=" + clipSamples +
        //    " ch=" + channels +
        //    " clipHz=" + clipFrequency +
        //    " lastSamplePos=" + lastSamplePosition +
        //    " availFrames=" + availableFrames +
        //    " framesPerPkt=" + FramesPerPacket +
        //    " secsSincePosChange=" + (now - lastMicPositionChangedAt).ToString("F1") +
        //    " pumpedPkts=" + lastPumpedPackets +
        //    " pumpedFrames=" + lastPumpedFrames +
        //    " totalPkts=" + totalPumpedPackets +
        //    " totalFrames=" + totalPumpedFrames +
        //    " pktRms=" + lastPacketRms.ToString("F4") +
        //    " pktPeak=" + lastPacketPeak.ToString("F4") +
        //    " opusBytes=" + lastOpusPacketBytes);
    }

    private void StartRecording()
    {
        if (microphone == null)
        {
            Debug.LogWarning("[RecordingManager] StartRecording skipped: microphone is null.");
            return;
        }

        if (!Application.HasUserAuthorization(UserAuthorization.Microphone))
        {
            Debug.LogWarning("[RecordingManager] StartRecording skipped: microphone permission not granted.");
            return;
        }

        int lengthSec = Mathf.Clamp(recordBufferSeconds, 1, 60);
        recordingClip = Microphone.Start(microphone, true, lengthSec, sampleRate);
        if (recordingClip == null)
        {
            Debug.LogWarning("[RecordingManager] Microphone.Start returned null AudioClip.");
            isRecording = false;
            return;
        }

        int channels = Mathf.Clamp(recordingClip.channels, 1, 2);
        try
        {
            opusEncoder = OpusCodecFactory.CreateEncoder(sampleRate, channels, OpusApplication.OPUS_APPLICATION_VOIP, null);
            opusEncoder.Bitrate = opusBitrate;
            opusEncoder.Complexity = opusComplexity;
            opusEncoder.UseVBR = opusUseVbr;
            opusEncoder.UseInbandFEC = opusUseInbandFec;
            opusEncoder.UseDTX = opusUseDtx;
        }
        catch (Exception ex)
        {
            Debug.LogWarning("[RecordingManager] Failed to create Opus encoder: " + ex.Message);
            opusEncoder = null;
        }

        lastSamplePosition = 0;
        lastPumpPosition = -999;
        lastPumpPositionChangedAt = Time.unscaledTime;
        isRecording = true;

        micPacketFloats = null;
        opusPacketBytes = null;
        lastOpusPacketBytes = 0;

        Debug.Log("Recording started...");
    }

    private void StopRecording()
    {
        if (microphone != null)
        {
            Microphone.End(microphone);
        }

        isRecording = false;
        recordingClip = null;
        opusEncoder = null;
        Debug.Log("Recording stopped.");
    }

    private void PumpMicrophoneAndSend()
    {
        if (recordingClip == null)
        {
            return;
        }

        int position = Microphone.GetPosition(microphone);
        if (position < 0)
        {
            return;
        }

        float now = Time.unscaledTime;
        if (position != lastPumpPosition)
        {
            lastPumpPosition = position;
            lastPumpPositionChangedAt = now;
        }
        else if (autoRestartIfPositionStalls && now - lastPumpPositionChangedAt > stallRestartSeconds)
        {
            Debug.LogWarning(
                "[RecordingManager] Microphone.GetPosition stalled at " + position +
                " for " + (now - lastPumpPositionChangedAt).ToString("F1") + "s, restarting Microphone.");

            try { Microphone.End(microphone); } catch { }

            int lengthSec = Mathf.Clamp(recordBufferSeconds, 1, 60);
            recordingClip = Microphone.Start(microphone, true, lengthSec, sampleRate);
            lastSamplePosition = 0;
            lastPumpPosition = -999;
            lastPumpPositionChangedAt = now;
            return;
        }


        int clipSamples = recordingClip.samples;
        int channels = recordingClip.channels;

        int availableFrames = position - lastSamplePosition;
        if (availableFrames < 0)
        {
            availableFrames += clipSamples;
        }

        int framesPerPacket = FramesPerPacket;
        EnsurePacketBuffers(framesPerPacket, channels);

        int packetsSentThisTick = 0;
        int framesPumpedThisTick = 0;
        const int maxPacketsPerTick = 20;

        try
        {
            while (availableFrames >= framesPerPacket && packetsSentThisTick < maxPacketsPerTick)
            {
                ReadFramesIntoPacket(framesPerPacket, channels);
                SendPacket(framesPerPacket, channels);

                lastSamplePosition += framesPerPacket;
                if (lastSamplePosition >= clipSamples)
                {
                    lastSamplePosition -= clipSamples;
                }

                availableFrames -= framesPerPacket;
                packetsSentThisTick++;
                framesPumpedThisTick += framesPerPacket;
            }
        }
        catch (Exception ex)
        {
            Debug.LogWarning("[RecordingManager] PumpMicrophoneAndSend failed: " + ex);
        }

        lastPumpedPackets = packetsSentThisTick;
        lastPumpedFrames = framesPumpedThisTick;
        totalPumpedPackets += packetsSentThisTick;
        totalPumpedFrames += framesPumpedThisTick;
    }

    private void EnsurePacketBuffers(int framesPerPacket, int channels)
    {
        int floatCount = framesPerPacket * channels;
        if (micPacketFloats == null || micPacketFloats.Length != floatCount)
        {
            micPacketFloats = new float[floatCount];
        }

        if (opusPacketBytes == null || opusPacketBytes.Length != opusMaxPacketBytes)
        {
            opusPacketBytes = new byte[opusMaxPacketBytes];
        }
    }

    private void ReadFramesIntoPacket(int framesPerPacket, int channels)
    {
        int clipSamples = recordingClip.samples;
        int remainingToEnd = clipSamples - lastSamplePosition;

        if (framesPerPacket <= remainingToEnd)
        {
            recordingClip.GetData(micPacketFloats, lastSamplePosition);
            return;
        }

        int firstFrames = remainingToEnd;
        int secondFrames = framesPerPacket - firstFrames;

        float[] first = new float[firstFrames * channels];
        float[] second = new float[secondFrames * channels];

        recordingClip.GetData(first, lastSamplePosition);
        recordingClip.GetData(second, 0);

        Buffer.BlockCopy(first, 0, micPacketFloats, 0, first.Length * sizeof(float));
        Buffer.BlockCopy(second, 0, micPacketFloats, first.Length * sizeof(float), second.Length * sizeof(float));
    }

    private void SendPacket(int framesPerPacket, int channels)
    {
        int floatCount = framesPerPacket * channels;
        if (debugMicrophonePosition && micPacketFloats != null && micPacketFloats.Length >= floatCount)
        {
            float peak = 0f;
            double sumSq = 0;
            for (int i = 0; i < floatCount; i++)
            {
                float v = micPacketFloats[i];
                float av = Mathf.Abs(v);
                if (av > peak) peak = av;
                sumSq += (double)v * v;
            }
            lastPacketPeak = peak;
            lastPacketRms = floatCount > 0 ? (float)Math.Sqrt(sumSq / floatCount) : 0f;
        }

        if (monitorToAudioStreamPlayer && AudioStreamPlayer.Instance != null)
        {
            AudioStreamPlayer.Instance.FeedPcmFloats(micPacketFloats, floatCount, channels, monitorGain);
        }

        if (opusEncoder == null || opusPacketBytes == null)
        {
            lastOpusPacketBytes = 0;
            return;
        }

        int encodedBytes = 0;
        try
        {
            encodedBytes = opusEncoder.Encode(
                micPacketFloats.AsSpan(0, floatCount),
                framesPerPacket,
                opusPacketBytes.AsSpan(),
                opusPacketBytes.Length);
        }
        catch (Exception ex)
        {
            Debug.LogWarning("[RecordingManager] Opus encode failed: " + ex.Message);
            lastOpusPacketBytes = 0;
            return;
        }

        lastOpusPacketBytes = encodedBytes;
        if (encodedBytes <= 0)
        {
            return;
        }

        var client = NetClient.instance;
        var audioUdp = client != null ? client.udpAudioManager : null;
        if (client == null || (object)audioUdp == null)
        {
            return;
        }

        audioUdp.Send(opusPacketBytes, null, encodedBytes);
    }

    private void OnDisable()
    {
        if (isRecording)
        {
            StopRecording();
        }
    }
}
