using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using UnityEngine;
using Debug = AppLog;
using UnityEngine.Networking;
using UnityEngine.SceneManagement;
using Quest3VideoPlayer;
#nullable enable
public class NetClient : MonoBehaviour
{

    public static NetClient instance;
    private bool connecting = false; // Whether a server connection attempt is already running
    private bool questVideoPlayerWarningLogged;
    private bool videoPortPacketWarningLogged;

    public ServerRobotList serverRobotLists;
    private string robotdataUrl;
    [HideInInspector]
    public UdpManager udpDataManager;
    [HideInInspector]
    public UdpManager udpAudioManager;
    [HideInInspector]
    public UdpManager? udpVideoManager;
    public HeartbeatMessage _heartbeatMessage;
    
    // 消息处理频率控制
    private readonly Dictionary<string, float> _lastProcessTime = new();
    private const float MinProcessInterval = 0.01f; // 最小处理间隔，100Hz
    private byte[] _heartbeatsenddata;
    public ServerConfigSO configSO;
    private Coroutine heartbeatCoroutine;

    [HideInInspector]
    public bool islan;
    private bool unityBridgesVideo;

    [Header("Video UDP Transport")]

    public bool IsUsingUnityUdpVideoBridge => unityBridgesVideo;
    public bool IsUnityReceivingVideoUdp => udpVideoManager != null;

    private readonly object _ttsOptionsLock = new();
    private readonly object _actionOptionsLock = new();
    private List<string> _pendingTTSOptions;
    private List<string> _pendingActionOptions;
    private bool _hasPendingTTSUpdate;
    private bool _hasPendingActionUpdate;
    private QuestStreamVideoPlayer? questStreamVideoPlayer;
    private int LocalVideoPort => islan ? RuntimeServerConfig.serverVideoPort : RuntimeServerConfig.clientVideoPort;
    private int LocalAudioPort => islan ? RuntimeServerConfig.serverAudioPort : RuntimeServerConfig.clientAudioPort;
    private int LocalDataPort => islan ? RuntimeServerConfig.serverDataPort : RuntimeServerConfig.clientDataPort;
    private int RemoteVideoPort => islan ? RuntimeServerConfig.clientVideoPort : RuntimeServerConfig.serverVideoPort;
    private int RemoteAudioPort => islan ? RuntimeServerConfig.clientAudioPort : RuntimeServerConfig.serverAudioPort;
    private int RemoteDataPort => islan ? RuntimeServerConfig.clientDataPort : RuntimeServerConfig.serverDataPort;

    void Awake()
    {
        instance = this;
        islan = false;
        StartCoroutine(CopyFile());
        RuntimeServerConfig.Load(configSO);
    }

    private void Start()
    {
        NetWorkStart();
    }

    private void OnDisable()
    {
        if (heartbeatCoroutine != null)
        {
            StopCoroutine(heartbeatCoroutine);
            heartbeatCoroutine = null;
        }
    }

    private void Update()
    {
        udpDataManager?.DispatchQueuedPackets();
        udpAudioManager?.DispatchQueuedPackets();
        udpVideoManager?.DispatchQueuedPackets();
        ProcessPendingTTSOptions();
        ProcessPendingActionOptions();
    }


    public static IEnumerator CopyFile()
    {
        if (!File.Exists(RuntimeServerConfig.configPath)) 
        {
#if UNITY_ANDROID
            // Android must load this via WWW request
            UnityWebRequest req = UnityWebRequest.Get(RuntimeServerConfig.streamingconfigPath);
            yield return req.SendWebRequest();
            File.WriteAllText(RuntimeServerConfig.configPath, req.downloadHandler.text);
#else
            File.Copy(RuntimeServerConfig.streamingconfigPath, RuntimeServerConfig.configPath);
            yield return null;
#endif
        }
    }

    public void NetWorkStart() 
    {
        ReloadUdpManagers();
        InitializeHeartbeatMessage();
        RestartHeartbeatCoroutine();
    }

    private void RestartHeartbeatCoroutine()
    {
        if (heartbeatCoroutine != null)
        {
            StopCoroutine(heartbeatCoroutine);
        }

        heartbeatCoroutine = StartCoroutine(HeartbeatSendData());
    }

    private void InitializeHeartbeatMessage()
    {
        Debug.Log(SystemInfo.deviceUniqueIdentifier + "devicesid");
        _heartbeatMessage = new HeartbeatMessage
        {
            user_email = "chaochen497@gmail.com",
            device_id = SystemInfo.deviceUniqueIdentifier,
            target_device_id = "",
            token = ""
        };
    }

    private IEnumerator HeartbeatSendData()
    {
        while (true)
        {
            PrepareHeartbeatData();
            SendHeartbeat();
            yield return new WaitForSeconds(3);
        }
    }

    private void PrepareHeartbeatData()
    {
        byte[] startingBytes = new byte[] { 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF };
        string heartbeatJson = JsonConvert.SerializeObject(_heartbeatMessage);
        byte[] messageBytes = Encoding.UTF8.GetBytes(heartbeatJson);
        _heartbeatsenddata = startingBytes.Concat(messageBytes).ToArray();
    }

    private void SendHeartbeat()
    {
        if (_heartbeatsenddata == null || _heartbeatsenddata.Length == 0)
        {
            Debug.LogError("Heartbeat data is null or empty.");
            return;
        }
        udpDataManager.Send(_heartbeatsenddata);
        udpAudioManager.Send(_heartbeatsenddata);

        if (unityBridgesVideo)
        {
            udpVideoManager?.Send(_heartbeatsenddata);
        }
        else
        {
            questStreamVideoPlayer?.SubmitVideoHeartbeat(_heartbeatsenddata, _heartbeatsenddata.Length);
        }
    }

    public static string GetTextFromStreamingAssets(string path)
    {
        string localPath = Application.platform == RuntimePlatform.Android
            ? Path.Combine(Application.streamingAssetsPath, path)
            : $"file:///{Application.streamingAssetsPath}/{path}";

        UnityWebRequest request = UnityWebRequest.Get(localPath);
        var operation = request.SendWebRequest();
        while (!operation.isDone) { }

        
        if (request.result == UnityWebRequest.Result.ConnectionError)
        {
            Debug.Log(request.error);
            return string.Empty;
        }

        return request.downloadHandler.text;
    }

    public void StartRequest()
    {
        if (connecting) return;
        connecting = true;
        StartCoroutine(RequestGetRobotData());
    }

    private IEnumerator RequestGetRobotData()
    {

        string jsonData = "{\"email\":\"chaochen497@gmail.com\"}";
        UnityWebRequest request = new UnityWebRequest(robotdataUrl, "POST")
        {
            uploadHandler = new UploadHandlerRaw(Encoding.UTF8.GetBytes(jsonData)),
            downloadHandler = new DownloadHandlerBuffer()
        };

        SetRequestHeaders(request);
        yield return request.SendWebRequest();

        if (request.result != UnityWebRequest.Result.Success)
        {
            Debug.LogError("Error: " + request.error);
            connecting = false;
            yield break;
        }

        Debug.Log("Response: " + request.downloadHandler.text);
        ReceiveRobotData(request.downloadHandler.text);
        connecting = false;
    }

    private void SetRequestHeaders(UnityWebRequest request)
    {
        request.SetRequestHeader("Content-Type", "application/json");
        request.SetRequestHeader("Accept", "*/*");
        request.SetRequestHeader("Host", RuntimeServerConfig.serverIp + ":8080");
        request.SetRequestHeader("User-Agent", "Apifox/1.0.0 (https://apifox.com)");
        request.SetRequestHeader("Connection", "keep-alive");
    }

    private void ReceiveRobotData(string data)
    {
        serverRobotLists = JsonUtility.FromJson<ServerRobotList>("{\"list\":" + data + "}");
        foreach (ServerRobotData item in serverRobotLists.list)
        {
            Debug.Log($"device_id: {item.device_id}, Name: {item.name}, id: {item.id}");
        }

        UIManager.Instance.CreateRobotList(serverRobotLists);
    }

    /// <summary>
    /// 
    /// </summary>
    
    /// <param name="data"></param>
    /// <param name="iPEndPoint"></param>

    public void ReceiveData(byte[] data, IPEndPoint iPEndPoint)
    {
        try
        {
            // IMPORTANT: Avoid decoding binary UDP payloads (audio/video) as UTF-8 strings.
            // This creates large allocations/GC spikes and can stall both video + audio playback.
#if UNITY_EDITOR
            Debug.Log($"[NetClient] {data.Length} {iPEndPoint.Port} (来自 {iPEndPoint.Address})");
#endif
            if (IsDataPort(iPEndPoint.Port))
            {
                int headerLength = 0;  // 如果没有头，改成 0
                int jsonLength = data.Length - headerLength;
                string jsonString = Encoding.UTF8.GetString(data, headerLength, jsonLength);
                // Extract the JSON body from the payload and convert it to UTF-8 text
                //  string jsonString = Encoding.UTF8.GetString(data, headerLength, jsonLength);
                HandleIncomingJson(jsonString);
                DebugState();
            }
            else if (IsAudioPort(iPEndPoint.Port))
            {
                if (AudioStreamPlayer.Instance != null)
                {
                    AudioStreamPlayer.Instance.FeedNetworkPacket(data, data.Length, iPEndPoint);
                }
            }
            else if (IsVideoPort(iPEndPoint.Port))
            {
                if (!unityBridgesVideo)
                {
                    // In Java-direct mode we should not bind the video port on the C# side.
                    if (!videoPortPacketWarningLogged)
                    {
                        Debug.LogWarning($"[NetClient] Received a packet on video port {iPEndPoint.Port} via C# UdpManager, " +
                                         "but current mode uses Java-side UDP receive. Dropping.");
                        videoPortPacketWarningLogged = true;
                    }
                    return;
                }

                if (questStreamVideoPlayer != null)
                {
                    questStreamVideoPlayer.SubmitVideoPacket(data, data.Length);
                    videoPortPacketWarningLogged = false;
                }
            }
            else
            {
                Debug.LogWarning($"[NetClient] 未识别的UDP端口 {iPEndPoint.Port} (来自 {iPEndPoint.Address})");
            }
        }
        catch (Exception ex)
        {
            Debug.LogError(ex);

        }
        finally
        {
            // Return the rented buffer to the pool
            ByteArrayPool.Return(data);
        }
    }

    void DebugState()
    {
        if (DebugTextManager.Instance == null)
        {
            return;
        }

        var stateData = DataManager.Instance != null ? DataManager.Instance.latestRobotStateData : null;
        if (stateData == null)
        {
            DebugTextManager.Instance._debugServerstatetext.text = "ServerMode: 未收到服务器数据";
            return;
        }

        string robotMode = FormatEnumValue<RobotMode>(stateData.robot_mode);
        string videoMode = FormatEnumValue<VideoMode>(stateData.video_mode);
        string audioMode = FormatEnumValue<AudioMode>(stateData.audio_mode);
        string height = stateData.robot_height.HasValue ? stateData.robot_height.Value.ToString("F2") : "null";

        DebugTextManager.Instance._debugServerstatetext.text =
            $"ServerMode: Robot Mode = {robotMode} Audio Mode = {audioMode} Video Mode = {videoMode} Robot Height = {height}";
    }

    private static string FormatEnumValue<T>(int value) where T : struct
    {
        Type enumType = typeof(T);
        if (enumType.IsEnum && Enum.IsDefined(enumType, value))
        {
            return Enum.GetName(enumType, value);
        }

        return $"Unknown({value})";
    }


    public void HandleIncomingJson(string jsonString)
    {
        foreach (string singleJson in SplitConcatenatedJson(jsonString))
        {
            if (string.IsNullOrWhiteSpace(singleJson))
            {
                continue;
            }

            try
            {
                // 快速检查消息类型，避免完整解析
                int typeStartIndex = singleJson.IndexOf("type",StringComparison.Ordinal);
                if (typeStartIndex == -1)
                {
                    continue;
                }
                
                int typeValueStart = typeStartIndex + 7; // Length of the literal "type":"
                int typeValueEnd = singleJson.IndexOf('"', typeValueStart);
                if (typeValueEnd == -1)
                {
                    continue;
                }
                
                string messageType = singleJson.Substring(typeValueStart, typeValueEnd - typeValueStart);

                // 频率控制：检查该类型消息上次处理时间
                float currentTime = Time.time;
                if (_lastProcessTime.TryGetValue(messageType, out float lastTime))
                {
                    if (currentTime - lastTime < MinProcessInterval)
                    {
                        // 处理太频繁，跳过
                        continue;
                    }
                }
                _lastProcessTime[messageType] = currentTime;

                switch (messageType)
                {
                    case "robot_state":
                        RobotStateMessage stateMsg = JsonUtility.FromJson<RobotStateMessage>(singleJson);
                        if (stateMsg != null)
                        {
                            DataManager.Instance?.UpdateRobotState(stateMsg);
                        }
                        break;
                    case "robot_joint_state":
                        RobotJointStateMessage jointMsg = JsonUtility.FromJson<RobotJointStateMessage>(singleJson);
                        if (jointMsg != null)
                        {
                            DataManager.Instance?.UpdateRobotJointState(jointMsg);
                        }
                        break;
                    case "tts_list":
                        var ttsListMsg = JsonConvert.DeserializeObject<StringArrayMessage>(singleJson);
                        if (ttsListMsg?.data != null)
                        {
                            QueueTTSOptions(ttsListMsg.data);
                        }
                        break;
                    case "action":
                        var actionListMsg = JsonConvert.DeserializeObject<StringArrayMessage>(singleJson);
                        if (actionListMsg?.data != null)
                        {
                            QueueActionOptions(actionListMsg.data);
                        }
                        break;
                    // 移除未知消息类型的警告日志，减少IO
                }
            }
            catch (Exception ex)
            {
                // 移除解析失败的详细日志，减少IO
                //Debug.LogError($"解析 UDP JSON 失败: {ex.Message}\n{singleJson}");
            }
        }
    }

    private static IEnumerable<string> SplitConcatenatedJson(string rawJson)
    {
        List<string> result = new List<string>();
        if (string.IsNullOrWhiteSpace(rawJson))
        {
            return result;
        }

        int depth = 0;
        int startIndex = -1;
        for (int i = 0; i < rawJson.Length; i++)
        {
            char currentChar = rawJson[i];
            if (currentChar == '{')
            {
                if (depth == 0)
                {
                    startIndex = i;
                }
                depth++;
            }
            else if (currentChar == '}')
            {
                depth--;
                if (depth == 0 && startIndex != -1)
                {
                    int length = i - startIndex + 1;
                    result.Add(rawJson.Substring(startIndex, length));
                    startIndex = -1;
                }
            }
        }

        if (depth != 0)
        {
            Debug.LogWarning($"UDP JSON payload is incomplete: {rawJson}");
        }

        return result;
    }

    private void ProcessPendingTTSOptions()
    {
        if (UIManager.Instance == null)
        {
            return;
        }

        List<string> options = null;
        lock (_ttsOptionsLock)
        {
            if (_hasPendingTTSUpdate)
            {
                options = _pendingTTSOptions;
                _pendingTTSOptions = null;
                _hasPendingTTSUpdate = false;
            }
        }
        if (options != null)
        {
            UIManager.Instance.UpdateTTSOptions(options);
        }
    }

    private void ProcessPendingActionOptions()
    {
        if (UIManager.Instance == null)
        {
            return;
        }

        List<string> options = null;
        lock (_actionOptionsLock)
        {
            if (_hasPendingActionUpdate)
            {
                options = _pendingActionOptions;
                _pendingActionOptions = null;
                _hasPendingActionUpdate = false;
            }
        }
        if (options != null)
        {
            UIManager.Instance.UpdateActionOptions(options);
        }
    }

    private void QueueTTSOptions(List<string> options)
    {
        if (options == null) return;
        lock (_ttsOptionsLock)
        {
            _pendingTTSOptions = new List<string>(options);
            _hasPendingTTSUpdate = true;
        }
    }

    private void QueueActionOptions(List<string> options)
    {
        if (options == null) return;
        lock (_actionOptionsLock)
        {
            _pendingActionOptions = new List<string>(options);
            _hasPendingActionUpdate = true;
        }
    }

    private void OnApplicationQuit()
    {
        udpDataManager?.Close();
        udpAudioManager?.Close();
        udpVideoManager?.Close();
    }

    private bool IsVideoPort(int port) => port == RemoteVideoPort || port == LocalVideoPort;
    private bool IsAudioPort(int port) => port == RemoteAudioPort || port == LocalAudioPort;
    private bool IsDataPort(int port) => port == RemoteDataPort || port == LocalDataPort;


    public void ReloadUdpManagers()
    {
        Debug.Log("[NetClient] Reloading UdpManagers with new server config...");
        // 1. 关闭旧的
        udpDataManager?.Close();
        udpAudioManager?.Close();
        udpVideoManager?.Close();
        //udpHeartbeatManager?.Close();
        videoPortPacketWarningLogged = false;

        // 2. Reload IP/Port since RuntimeServerConfig has already been updated
        Debug.Log(RuntimeServerConfig.serverIp);
        robotdataUrl = $"http://{RuntimeServerConfig.serverIp}:8080/devices/list";
        int localDataPort = LocalDataPort;
        int localAudioPort = LocalAudioPort;
        int localVideoPort = LocalVideoPort;
        int remoteDataPort = RemoteDataPort;
        int remoteAudioPort = RemoteAudioPort;
        int remoteVideoPort = RemoteVideoPort;

        udpDataManager = new UdpManager(
            localDataPort,
            "0.0.0.0",
            RuntimeServerConfig.serverIp,
            remoteDataPort);
        udpDataManager.OnDataReceived += ReceiveData;

        udpAudioManager = new UdpManager(
            localAudioPort,
            "0.0.0.0",
            RuntimeServerConfig.serverIp,
            remoteAudioPort);
        udpAudioManager.OnDataReceived += ReceiveData;


        questStreamVideoPlayer = transform.GetComponent<QuestStreamVideoPlayer>() ??
                                 FindObjectOfType<QuestStreamVideoPlayer>();
        unityBridgesVideo = questStreamVideoPlayer != null && questStreamVideoPlayer.UseUnityUdpVideoBridge;
        if (unityBridgesVideo)
        {
            udpVideoManager = new UdpManager(
                localVideoPort,
                "0.0.0.0",
                RuntimeServerConfig.serverIp,
                remoteVideoPort);
            udpVideoManager.OnDataReceived += ReceiveData;
        }
        else
        {
            udpVideoManager = null;
        }

        ConfigureQuestVideoPlayer(localVideoPort, remoteVideoPort, unityBridgesVideo);

        Debug.Log($"[NetClient] UDP Managers Reloaded. isLAN={islan}\n" +
                  $"UnityVideoUdpBridge: {unityBridgesVideo}\n" +
                  $"Server IP: {RuntimeServerConfig.serverIp}\n" +
                  $"Local Ports: Video({localVideoPort}), Audio({localAudioPort}), Data({localDataPort})\n" +
                  $"Remote Ports: Video({remoteVideoPort}), Audio({remoteAudioPort}), Data({remoteDataPort})");

    }

    private void ConfigureQuestVideoPlayer(int primaryPort, int secondaryPort, bool unityUdpBridge)
    {
        questStreamVideoPlayer = transform.GetComponent<QuestStreamVideoPlayer>() ??
                                 FindObjectOfType<QuestStreamVideoPlayer>();
        if (questStreamVideoPlayer == null)
        {
            if (!questVideoPlayerWarningLogged)
            {
                Debug.Log("[NetClient] QuestStreamVideoPlayer 未在当前场景中找到，跳过视频端口配置。");
                questVideoPlayerWarningLogged = true;
            }
            return;
        }

        questVideoPlayerWarningLogged = false;
        questStreamVideoPlayer.SetUseUnityUdpVideoBridge(unityUdpBridge);
        questStreamVideoPlayer.ConfigureNetwork(
            "0.0.0.0",
            primaryPort,
            secondaryPort,
            RuntimeServerConfig.serverIp,
            secondaryPort,
            RuntimeServerConfig.serverIp);
        Debug.Log($"[NetClient] QuestStreamVideoPlayer 已配置监听端口 {primaryPort} (备用 {secondaryPort})");
    }

}
[System.Serializable]
public class GenericRobotMessage
{
    public string type;

}

[System.Serializable]
public class StringArrayMessage
{
    public string type;
    public List<string> data;
}
