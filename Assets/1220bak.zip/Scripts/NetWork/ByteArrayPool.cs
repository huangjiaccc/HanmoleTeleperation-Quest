using System;
using System.Collections.Concurrent;

/// <summary>
/// Shared byte[] pool to reduce allocations for UDP send/receive workloads.
/// </summary>
public static class ByteArrayPool
{
    private const int MaxArraySize = 1024 * 1024; // 1 MB
    private static readonly ConcurrentDictionary<int, ConcurrentQueue<byte[]>> Pools = new();

    /// <summary>
    /// Rent a buffer with the exact requested length (or a new buffer if none are available).
    /// </summary>
    public static byte[] Rent(int size)
    {
        if (size <= 0)
        {
            size = 1;
        }

        if (size > MaxArraySize)
        {
            return new byte[size];
        }

        var pool = GetOrCreatePool(size);
        if (pool.TryDequeue(out var buffer))
        {
            return buffer;
        }

        return new byte[size];
    }

    /// <summary>
    /// Return a buffer previously obtained via <see cref="Rent"/>.
    /// </summary>
    public static void Return(byte[] buffer)
    {
        if (buffer == null || buffer.Length == 0 || buffer.Length > MaxArraySize)
        {
            return;
        }

        var pool = GetOrCreatePool(buffer.Length);
        Array.Clear(buffer, 0, buffer.Length);
        pool.Enqueue(buffer);
    }

    /// <summary>
    /// Clear all pools (mainly for tests / diagnostics).
    /// </summary>
    public static void Clear()
    {
        Pools.Clear();
    }

    private static ConcurrentQueue<byte[]> GetOrCreatePool(int size)
    {
        return Pools.GetOrAdd(size, _ => new ConcurrentQueue<byte[]>());
    }
}
