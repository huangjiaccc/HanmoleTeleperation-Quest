using System;
using UnityEngine;

public static class CommandDiff
{
    private const float FLOAT_EPSILON = 0.0001f;

    // 返回 PartialCommand：只有变化的字段会被赋值，未变化的字段保持 null
    public static PartialCommand BuildPartial(RobotState oldCmd, RobotState newCmd)
    {
        if (newCmd == null)
        {
            return new PartialCommand();
        }

        if (oldCmd == null)
        {
            oldCmd = new RobotState();
        }
        var partial = new PartialCommand();

        if (oldCmd.SET_ROBOT_MODE != newCmd.SET_ROBOT_MODE)
        {
            partial.SET_ROBOT_MODE = newCmd.SET_ROBOT_MODE;
        }

        if (oldCmd.SET_VIDEO_MODE != newCmd.SET_VIDEO_MODE)
        {
            partial.SET_VIDEO_MODE = newCmd.SET_VIDEO_MODE;
        }

        if (oldCmd.SET_AUDIO_MODE != newCmd.SET_AUDIO_MODE)
        {
            partial.SET_AUDIO_MODE = newCmd.SET_AUDIO_MODE;
        }

        if (Mathf.Abs(oldCmd.SET_AUDIO_VOLUME - newCmd.SET_AUDIO_VOLUME) > FLOAT_EPSILON)
        {
            partial.SET_AUDIO_VOLUME = newCmd.SET_AUDIO_VOLUME;
        }

        if (Mathf.Abs(oldCmd.MOVE_IDX_LEFT_X - newCmd.MOVE_IDX_LEFT_X) > FLOAT_EPSILON)
        {
            partial.MOVE_IDX_LEFT_X = newCmd.MOVE_IDX_LEFT_X;
        }

        if (Mathf.Abs(oldCmd.MOVE_IDX_LEFT_Y - newCmd.MOVE_IDX_LEFT_Y) > FLOAT_EPSILON)
        {
            partial.MOVE_IDX_LEFT_Y = newCmd.MOVE_IDX_LEFT_Y;
        }

        if (Mathf.Abs(oldCmd.MOVE_IDX_RIGHT_X - newCmd.MOVE_IDX_RIGHT_X) > FLOAT_EPSILON)
        {
            partial.MOVE_IDX_RIGHT_X = newCmd.MOVE_IDX_RIGHT_X;
        }

        if (Mathf.Abs(oldCmd.MOVE_IDX_RIGHT_Y - newCmd.MOVE_IDX_RIGHT_Y) > FLOAT_EPSILON)
        {
            partial.MOVE_IDX_RIGHT_Y = newCmd.MOVE_IDX_RIGHT_Y;
        }

        if (Mathf.Abs(oldCmd.SET_LEFT_ROTATE_ANGLE - newCmd.SET_LEFT_ROTATE_ANGLE) > FLOAT_EPSILON)
        {
            partial.SET_LEFT_ROTATE_ANGLE = newCmd.SET_LEFT_ROTATE_ANGLE;
        }

        if (Mathf.Abs(oldCmd.SET_RIGHT_ROTATE_ANGLE - newCmd.SET_RIGHT_ROTATE_ANGLE) > FLOAT_EPSILON)
        {
            partial.SET_RIGHT_ROTATE_ANGLE = newCmd.SET_RIGHT_ROTATE_ANGLE;
        }

        var oldAction = oldCmd.ACTION;
        var newAction = newCmd.ACTION;
        bool actionChanged = false;
        string normalizedOldActionName = NormalizeString(oldAction?.name);
        string normalizedNewActionName = NormalizeString(newAction?.name);
        string normalizedOldActionCmd = NormalizeString(oldAction?.cmd);
        string normalizedNewActionCmd = NormalizeString(newAction?.cmd);
        if (!string.Equals(normalizedOldActionName, normalizedNewActionName, StringComparison.Ordinal))
        {
            if (normalizedNewActionName != null)
            {
                EnsureAction().name = normalizedNewActionName;
            }
        }
        if (!string.Equals(normalizedOldActionCmd, normalizedNewActionCmd, StringComparison.Ordinal))
        {
            if (normalizedNewActionCmd != null)
            {
                EnsureAction().cmd = normalizedNewActionCmd;
            }
        }
        if (!actionChanged)
        {
            partial.ACTION = null;
        }

        var oldTts = oldCmd.TTS;
        var newTts = newCmd.TTS;
        bool ttsChanged = false;
        string normalizedOldTtsText = NormalizeString(oldTts?.text);
        string normalizedNewTtsText = NormalizeString(newTts?.text);
        string normalizedOldTtsCmd = NormalizeString(oldTts?.cmd);
        string normalizedNewTtsCmd = NormalizeString(newTts?.cmd);
        if (!string.Equals(normalizedOldTtsText, normalizedNewTtsText, StringComparison.Ordinal))
        {
            if (normalizedNewTtsText != null)
            {
                EnsureTts().text = normalizedNewTtsText;
            }
        }
        if (!string.Equals(normalizedOldTtsCmd, normalizedNewTtsCmd, StringComparison.Ordinal))
        {
            if (normalizedNewTtsCmd != null)
            {
                EnsureTts().cmd = normalizedNewTtsCmd;
            }
        }
        if (!ttsChanged)
        {
            partial.TTS = null;
        }

        // 如果没有任何变化，返回一个“空” PartialCommand（所有字段 null）
        // 如果你希望在无变化时直接把 commands 设为 null，请改成 `return null;`
        return partial;

        ACTION EnsureAction()
        {
            actionChanged = true;
            if (partial.ACTION == null)
            {
                partial.ACTION = new ACTION();
            }
            return partial.ACTION;
        }

        TTS EnsureTts()
        {
            ttsChanged = true;
            if (partial.TTS == null)
            {
                partial.TTS = new TTS();
            }
            return partial.TTS;
        }

        static string NormalizeString(string value) => string.IsNullOrEmpty(value) ? null : value;
    }

    // 一个快速判断：partial 是否真的有字段被设置
    public static bool IsEmpty(PartialCommand p)
    {
        if (p == null) return true;
        return p.SET_ROBOT_MODE == null &&
               p.SET_VIDEO_MODE == null &&
               p.SET_AUDIO_MODE == null &&
               p.SET_AUDIO_VOLUME == null &&
               p.MOVE_IDX_LEFT_X == null &&
               p.MOVE_IDX_LEFT_Y == null &&
               p.MOVE_IDX_RIGHT_X == null &&
               p.MOVE_IDX_RIGHT_Y == null &&
               p.SET_LEFT_ROTATE_ANGLE == null &&
               p.SET_RIGHT_ROTATE_ANGLE == null &&
               IsActionEmpty(p.ACTION) &&
               IsTtsEmpty(p.TTS);
    }

    private static bool IsActionEmpty(ACTION action)
    {
        return action == null ||
               (string.IsNullOrEmpty(action.cmd) && string.IsNullOrEmpty(action.name));
    }

    private static bool IsTtsEmpty(TTS tts)
    {
        return tts == null ||
               (string.IsNullOrEmpty(tts.cmd) && string.IsNullOrEmpty(tts.text));
    }
}
