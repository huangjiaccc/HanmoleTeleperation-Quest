﻿using System;
using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using UnityEngine;
using Debug = AppLog;

#nullable enable

public class UdpManager : MonoBehaviour
{
    private Socket _socket = null!;
    private byte[] _rxBuffer = null!;

    private IPEndPoint? _txEndpoint;

    private bool _rxEnabled;
    private bool _closed;
    private Thread? _rxThread;

    // Unity 主线程队列
    private readonly ConcurrentQueue<(byte[], IPEndPoint)> _mainThreadQueue = new();
    private readonly ConcurrentQueue<(string message, bool isError)> _logQueue = new();


    public Action<byte[], IPEndPoint>? OnDataReceived;

    // ------------------------ 初始化 ------------------------

    public UdpManager(
        int? rxPort = null,
        string rxHost = "0.0.0.0",
        string? txHost = null,
        int? txPort = null,
        int rxBufferSize = 1024 * 1024 * 2,
        bool reuseAddress = true,
        bool enableReceive = true)
    {
        if ((txHost == null) != (txPort == null))
            throw new ArgumentException("txHost 和 txPort 必须同时提供或同时为 null");
        if (rxPort == null && txHost == null)
            throw new ArgumentException("必须提供接收端口或发送端点至少一个");

        _socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        _socket.Blocking = true;
        _socket.ReceiveBufferSize = rxBufferSize;
        _socket.SendBufferSize = rxBufferSize;

        if (reuseAddress)
            _socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);

        _rxBuffer = new byte[rxBufferSize];

        bool hasRxPort = rxPort.HasValue;
        _rxEnabled = enableReceive && hasRxPort;

        // 绑定接收端口（可选开启接收线程）
        if (hasRxPort)
        {
            var localEP = new IPEndPoint(IPAddress.Parse(rxHost), rxPort.Value);
            _socket.Bind(localEP);
            Debug.Log($"[UdpManager] 绑定到本地端口: {localEP} (接收{(enableReceive ? "开启" : "关闭")})");
        }

        StartReceiveThread();

        // 设置发送端
        if (txHost != null)
            UpdateTxEndpoint(txHost, txPort!.Value);

        Debug.Log($"[UdpManager] 初始化完成 - 接收:{rxPort.HasValue} 发送:{txHost != null}");
    }

    // ------------------------ 接收 ------------------------

    private void StartReceiveThread()
    {
        if (!_rxEnabled || _closed || _rxThread != null)
        {
            return;
        }

        _rxThread = new Thread(ReceiveLoop)
        {
            IsBackground = true,
            Name = "UdpManagerRx"
        };
        _rxThread.Start();
    }

    private void ReceiveLoop()
    {
        while (!_closed)
        {
            EndPoint remote = new IPEndPoint(IPAddress.Any, 0);
            try
            {
                int received = _socket.ReceiveFrom(_rxBuffer, 0, _rxBuffer.Length, SocketFlags.None, ref remote);
                if (received > 0)
                {
                    byte[] data = ByteArrayPool.Rent(received);
                    Buffer.BlockCopy(_rxBuffer, 0, data, 0, received);
                    _mainThreadQueue.Enqueue((data, (IPEndPoint)remote));
                }
            }
            catch (ObjectDisposedException)
            {
                break;
            }
            catch (SocketException sex)
            {
                if (_closed || sex.SocketErrorCode == SocketError.Interrupted || sex.SocketErrorCode == SocketError.OperationAborted)
                {
                    break;
                }
                _logQueue.Enqueue(($"[UdpManager] 接收 Socket 异常: {sex.SocketErrorCode}", true));
            }
            catch (Exception ex)
            {
                if (_closed)
                {
                    break;
                }
                _logQueue.Enqueue(($"[UdpManager] 接收异常: {ex.Message}", true));
            }
        }
    }

    // ------------------------ 主线程分发 ------------------------

    public void DispatchQueuedPackets()
    {
        while (_mainThreadQueue.TryDequeue(out var pair))
        {
            OnDataReceived?.Invoke(pair.Item1, pair.Item2);
        }

        while (_logQueue.TryDequeue(out var log))
        {
            if (log.isError)
            {
                Debug.LogWarning(log.message);
            }
            else
            {
                Debug.Log(log.message);
            }
        }
    }

    // ------------------------ 发送 ------------------------

    public void Send(byte[] data, IPEndPoint? address = null, int length = -1)
    {
        if (data == null || data.Length == 0) return;

        var target = address ?? _txEndpoint;
        if (target == null) return;

        int payloadLength = (length > 0 && length <= data.Length) ? length : data.Length;

        try
        {
            _socket.SendTo(data, 0, payloadLength, SocketFlags.None, target);
#if UNITY_EDITOR
            _logQueue.Enqueue(("[UdpManager] 发送：" + payloadLength + "target:" + target, false));
#endif      //_totalSent++;
        }
        catch (Exception ex)
        {
            Debug.LogWarning($"[UdpManager] 发送异常: {ex.Message}");
        }
    }

    public void UpdateTxEndpoint(string host, int port)
    {
        _txEndpoint = new IPEndPoint(IPAddress.Parse(host), port);
        Debug.Log($"[UdpManager] 设置发送端点: {_txEndpoint}");
        // ❗ UDP 多通道接收：不使用 Connect
    }

    // ------------------------ 生命周期 ------------------------

    public void Close()
    {
        if (_closed) return;
        _closed = true;

        try
        {
            _socket?.Close();
            _socket?.Dispose();
        }
        catch { }

        if (_rxThread != null && _rxThread.IsAlive)
        {
            try
            {
                if (!_rxThread.Join(100))
                {
                    _rxThread.Interrupt();
                }
            }
            catch { }
        }
        _rxThread = null;

        while (_mainThreadQueue.TryDequeue(out _)) { }

        Debug.Log("[UdpManager] 已关闭");
    }

    private void OnDestroy()
    {
        Close();
    }
}
