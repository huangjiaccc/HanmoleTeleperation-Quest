using System.Runtime.InteropServices;
using UnityEngine;
using Debug = AppLog;

namespace Quest3VideoPlayer
{
    /// <summary>
    /// Utility helpers for allocating and updating Unity textures with RGBA frame data.
    /// </summary>
    public static class QuestVideoImageUtils
    {
        /// <summary>
        /// Ensures that the referenced texture exists and matches the requested resolution.
        /// </summary>
        public static void EnsureTexture(ref Texture2D texture, int width, int height)
        {
            if (texture != null && (texture.width != width || texture.height != height))
            {
                Object.Destroy(texture);
                texture = null;
            }

            if (texture == null)
            {
                texture = new Texture2D(width, height, TextureFormat.RGBA32, false, true)
                {
                    wrapMode = TextureWrapMode.Clamp,
                    filterMode = FilterMode.Bilinear
                };
            }
        }

        /// <summary>
        /// Uploads RGBA32 data into the provided texture.
        /// </summary>
        public static void ApplyFrame(Texture2D texture, byte[] rgbaData)
        {
            if (texture == null || rgbaData == null || rgbaData.Length == 0)
            {
                return;
            }

            int expected = texture.width * texture.height * 4;
            if (rgbaData.Length != expected)
            {
                Debug.LogWarning($"[QuestVideoImageUtils] Frame size mismatch. Expected {expected} bytes, got {rgbaData.Length}.");
                return;
            }

            texture.LoadRawTextureData(rgbaData);
            texture.Apply(false);
        }

        /// <summary>
        /// Uploads RGBA32 data that originated from a Java sbyte[] without allocating a managed copy.
        /// </summary>
        public static void ApplyFrame(Texture2D texture, sbyte[] rgbaData)
        {
            if (texture == null || rgbaData == null || rgbaData.Length == 0)
            {
                return;
            }

            int expected = texture.width * texture.height * 4;
            if (rgbaData.Length != expected)
            {
                Debug.LogWarning($"[QuestVideoImageUtils] Frame size mismatch. Expected {expected} bytes, got {rgbaData.Length}.");
                return;
            }

            var handle = GCHandle.Alloc(rgbaData, GCHandleType.Pinned);
            try
            {
                texture.LoadRawTextureData(handle.AddrOfPinnedObject(), rgbaData.Length);
                texture.Apply(false);
            }
            finally
            {
                handle.Free();
            }
        }

        /// <summary>
        /// Assigns the texture to either a Renderer or RawImage target.
        /// </summary>
        public static void BindTexture(
            Texture texture,
            Renderer renderer,
            UnityEngine.UI.RawImage uiImage,
            bool flipHorizontal,
            bool flipVertical,
            int actualWidth,
            int actualHeight,
            int desiredWidth,
            int desiredHeight)
        {
            if (texture == null)
            {
                return;
            }

            int safeActualWidth = Mathf.Max(1, actualWidth);
            int safeActualHeight = Mathf.Max(1, actualHeight);
            int targetWidth = desiredWidth > 0 ? desiredWidth : safeActualWidth;
            int targetHeight = desiredHeight > 0 ? desiredHeight : safeActualHeight;

            float cropU = Mathf.Clamp01((float)targetWidth / safeActualWidth);
            float cropV = Mathf.Clamp01((float)targetHeight / safeActualHeight);
            float baseOffsetU = (1f - cropU) * 0.5f;
            float baseOffsetV = (1f - cropV) * 0.5f;
            float scaleU = flipHorizontal ? -cropU : cropU;
            float scaleV = flipVertical ? -cropV : cropV;
            float offsetU = flipHorizontal ? baseOffsetU + cropU : baseOffsetU;
            float offsetV = flipVertical ? baseOffsetV + cropV : baseOffsetV;

            if (renderer != null)
            {
                Material material = renderer.material;
                material.mainTexture = texture;

                material.mainTextureScale = new Vector2(scaleU, scaleV);
                material.mainTextureOffset = new Vector2(offsetU, offsetV);
            }

            if (uiImage != null)
            {
                uiImage.texture = texture;
                float rectWidth = scaleU;
                float rectHeight = scaleV;
                float rectX = offsetU;
                float rectY = offsetV;
                uiImage.uvRect = new Rect(rectX, rectY, rectWidth, rectHeight);
            }
        }
    }
}
