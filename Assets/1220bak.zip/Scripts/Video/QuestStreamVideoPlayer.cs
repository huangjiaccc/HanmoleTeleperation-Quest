using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Net;
using System.Threading;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;
using Debug = AppLog;

namespace Quest3VideoPlayer
{
    /// <summary>
    /// Receives H.264 frames over UDP and feeds them to the Android streaming decoder.
    /// </summary>
    public class QuestStreamVideoPlayer : MonoBehaviour
    {

        public struct VideoReleasePacketHeader
        {
            public int Timestamp;
            public int FrameId;
            public int SplitId;
            public int TotalSplits;
            public int FragmentId;
            public int TotalFragments;
            public int FragmentSize;
            public int TestingId;
        }

        [Header("Stream Format")]
        [SerializeField, Min(16)] private int expectedWidth = 1920;
        [SerializeField, Min(16)] private int expectedHeight = 1080;
        [SerializeField] private bool useReleasePacketFormat = true;
        [SerializeField, Range(1, 64)] private int maxFrameDrainPerTick = 8;
        [SerializeField] private bool drainFrameQueueCompletely = false;

        [Header("Playback Timing")]
        [SerializeField] private bool useBufferedPlayback = true;
        [SerializeField] private bool paceBySourceTimestamp = true;
        [SerializeField, Range(0f, 0.5f)] private float playbackDelaySeconds = 0.08f;
        [SerializeField, Range(0.01f, 1f)] private float lateDropThresholdSeconds = 0.25f;
        [SerializeField, Range(1, 16)] private int maxBufferedFrames = 3;
        [SerializeField, Range(0.0f, 0.2f)] private float maxWaitPerIterationSeconds = 0.05f;

        [Header("Targets")]
        [SerializeField] private Renderer targetRenderer;
        [SerializeField] private RawImage targetUI;

        [Header("Behavior")]
        [SerializeField] private bool autoStart = true;
        [SerializeField] private bool verboseLogging = true;
        [SerializeField] private bool flipTextureHorizontally = true;
        [SerializeField] private bool flipTextureVertically = true;
        [Tooltip("When enabled, Unity binds the video UDP port and forwards packets to Java. When disabled, Java binds the UDP port and receives packets directly.")]
        [SerializeField] private bool unityReceivesVideoUdp = false;
        [Header("Debug")]
        [SerializeField] private bool logFrameChecksums = true;

        [Header("Network")]
        private string listenAddress = "0.0.0.0";
        private string expectedSenderIp = string.Empty;
        private string remoteHost = string.Empty;
        private int remotePort;
        [SerializeField, Range(1024, 65535)] private int listenPort = 5000;
        [SerializeField, Range(0, 65535)] private int listenPortSecondary = 4000;

        private AndroidJavaObject decoder;
        private Texture2D videoTexture;
        private Coroutine frameRoutine;
        private int framesDecoded;
        private int emptyFrameTicks;
        private const int MaxCachedReleasePacketHeaders = 32;
        private readonly Queue<VideoReleasePacketHeader> releasePacketHeaderQueue = new Queue<VideoReleasePacketHeader>();
        private VideoReleasePacketHeader? latestReleasePacketHeader;
        private sbyte[] javaPacketBridge;
        private IntPtr submitUdpPayloadMethodId = IntPtr.Zero;
        private sbyte[] javaHeartbeatBridge;
        private IntPtr submitHeartbeatPayloadMethodId = IntPtr.Zero;
        private readonly ConcurrentQueue<PendingPacket> pendingPackets = new ConcurrentQueue<PendingPacket>();
        private AutoResetEvent packetSignal;
        private Thread packetForwarderThread;
        private volatile bool packetForwarderRunning;
        private const int MaxPendingPacketQueue = 256;

        private readonly Queue<DecodedFrame> decodedFrameQueue = new Queue<DecodedFrame>(8);
        private bool hasStreamClock;
        private uint baseRemoteTimestampMs;
        private double baseLocalTimeSeconds;

        private struct PendingPacket
        {
            public byte[] Buffer;
            public int Length;
        }

        private struct DecodedFrame
        {
            public sbyte[] ImageBytes;
            public int Width;
            public int Height;
            public bool IsYuvFormat;
            public int[] HeaderData;
            public bool HasTimestamp;
            public uint TimestampMs;
        }

        public event Action<VideoReleasePacketHeader> ReleasePacketHeaderReceived;

        public bool UseUnityUdpVideoBridge => unityReceivesVideoUdp;

        public void SetUseUnityUdpVideoBridge(bool enable)
        {
            // enable=true: Unity binds UDP video port and forwards packets to Java (external UDP transport)
            // enable=false: Java binds UDP video port and receives packets directly
            if (unityReceivesVideoUdp == enable)
            {
                return;
            }

            unityReceivesVideoUdp = enable;

            if (decoder != null)
            {
                RestartStream();
            }
        }

        private void Start()
        {
            if (autoStart)
            {
                StartStream();
            }
        }

        private void OnDisable()
        {
            StopStream();
        }

        public void ConfigureNetwork(string address, int primaryPort, int secondaryPort, string senderIp = "")
        {
            ConfigureNetwork(address, primaryPort, secondaryPort, string.Empty, 0, senderIp);
        }

        public void ConfigureNetwork(
            string address,
            int primaryPort,
            int secondaryPort,
            string udpRemoteHost,
            int udpRemotePort,
            string senderIp = "")
        {
            listenAddress = string.IsNullOrWhiteSpace(address) ? "0.0.0.0" : address.Trim();
            listenPort = Mathf.Clamp(primaryPort, 1024, 65535);
            listenPortSecondary = Mathf.Clamp(secondaryPort, 0, 65535);
            remoteHost = string.IsNullOrWhiteSpace(udpRemoteHost) ? string.Empty : udpRemoteHost.Trim();
            remotePort = Mathf.Clamp(udpRemotePort, 0, 65535);
            expectedSenderIp = string.IsNullOrEmpty(senderIp) ? string.Empty : senderIp.Trim();

            if (decoder != null)
            {
                RestartStream();
            }
        }

        public void ConfigureExpectedResolution(int width, int height)
        {
            expectedWidth = Mathf.Max(16, width);
            expectedHeight = Mathf.Max(16, height);

            if (decoder != null)
            {
                RestartStream();
            }
        }

        public bool TryDequeueReleasePacketHeader(out VideoReleasePacketHeader header)
        {
            if (releasePacketHeaderQueue.Count > 0)
            {
                header = releasePacketHeaderQueue.Dequeue();
                return true;
            }

            header = default;
            return false;
        }

        public bool TryGetLatestReleasePacketHeader(out VideoReleasePacketHeader header)
        {
            if (latestReleasePacketHeader.HasValue)
            {
                header = latestReleasePacketHeader.Value;
                return true;
            }

            header = default;
            return false;
        }

        public void SubmitVideoPacket(byte[] packet, int length)
        {
            if (!unityReceivesVideoUdp || decoder == null)
            {
                return;
            }

            if (packet == null || length <= 0)
            {
                return;
            }

            if (length > packet.Length)
            {
                length = packet.Length;
            }

            if (!packetForwarderRunning)
            {
                StartPacketForwarder();
            }

            if (pendingPackets.Count >= MaxPendingPacketQueue)
            {
                if (verboseLogging)
                {
                    Debug.LogWarning("[QuestStreamVideoPlayer] Dropping video packet due to queue overflow.");
                }
                return;
            }

            byte[] buffer = ByteArrayPool.Rent(length);
            Buffer.BlockCopy(packet, 0, buffer, 0, length);
            pendingPackets.Enqueue(new PendingPacket { Buffer = buffer, Length = length });
            packetSignal?.Set();
        }

        private void EnsureJavaBridgeBuffer(int length)
        {
            if (javaPacketBridge == null || javaPacketBridge.Length != length)
            {
                javaPacketBridge = new sbyte[length];
            }
        }

        private void EnsureJavaHeartbeatBridgeBuffer(int length)
        {
            if (javaHeartbeatBridge == null || javaHeartbeatBridge.Length != length)
            {
                javaHeartbeatBridge = new sbyte[length];
            }
        }

        private void StartPacketForwarder()
        {
            if (!unityReceivesVideoUdp || packetForwarderRunning)
            {
                return;
            }

            packetSignal ??= new AutoResetEvent(false);
            packetForwarderRunning = true;
            packetForwarderThread = new Thread(PacketForwarderLoop)
            {
                IsBackground = true,
                Name = "QuestVideoPacketForwarder"
            };
            packetForwarderThread.Start();
        }

        private void StopPacketForwarder()
        {
            if (!packetForwarderRunning)
            {
                return;
            }

            packetForwarderRunning = false;
            packetSignal?.Set();

            try
            {
                packetForwarderThread?.Join(500);
            }
            catch { }

            packetForwarderThread = null;

            while (pendingPackets.TryDequeue(out var packet))
            {
                ByteArrayPool.Return(packet.Buffer);
            }
        }

        private void PacketForwarderLoop()
        {
            try
            {
                AndroidJNI.AttachCurrentThread();
            }
            catch { }

            while (packetForwarderRunning)
            {
                if (!pendingPackets.TryDequeue(out var packet))
                {
                    packetSignal?.WaitOne(5);
                    continue;
                }

                try
                {
                    PushPacketToDecoder(packet.Buffer, packet.Length);
                }
                finally
                {
                    ByteArrayPool.Return(packet.Buffer);
                }
            }

            try
            {
                AndroidJNI.DetachCurrentThread();
            }
            catch { }
        }

        private void PushPacketToDecoder(byte[] packet, int length)
        {
            if (decoder == null)
            {
                return;
            }

            EnsureJavaBridgeBuffer(length);
            for (int i = 0; i < length; i++)
            {
                javaPacketBridge[i] = unchecked((sbyte)packet[i]);
            }
            EnsureSubmitPayloadMethod();
            if (submitUdpPayloadMethodId == IntPtr.Zero)
            {
                return;
            }

            IntPtr nativeArray = AndroidJNIHelper.ConvertToJNIArray(javaPacketBridge);
            jvalue[] args = new jvalue[2];
            args[0].l = nativeArray;
            args[1].i = length;
            AndroidJNI.CallVoidMethod(decoder.GetRawObject(), submitUdpPayloadMethodId, args);
            AndroidJNI.DeleteLocalRef(nativeArray);
        }

        private void EnsureSubmitPayloadMethod()
        {
            if (decoder == null || submitUdpPayloadMethodId != IntPtr.Zero)
            {
                return;
            }

            try
            {
                submitUdpPayloadMethodId = AndroidJNIHelper.GetMethodID(
                    decoder.GetRawClass(),
                    "submitUdpPayload",
                    "([BI)V");
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[QuestStreamVideoPlayer] Failed to cache submitUdpPayload method: {ex.Message}");
            }
        }

        private void EnsureSubmitHeartbeatPayloadMethod()
        {
            if (decoder == null || submitHeartbeatPayloadMethodId != IntPtr.Zero)
            {
                return;
            }

            try
            {
                submitHeartbeatPayloadMethodId = AndroidJNIHelper.GetMethodID(
                    decoder.GetRawClass(),
                    "submitHeartbeatPayload",
                    "([BI)V");
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[QuestStreamVideoPlayer] Failed to cache submitHeartbeatPayload method: {ex.Message}");
            }
        }

        public void SubmitVideoHeartbeat(byte[] payload, int length)
        {
            if (!IsAndroidTarget() || decoder == null || unityReceivesVideoUdp)
            {
                return;
            }

            if (payload == null || length <= 0)
            {
                return;
            }

            if (length > payload.Length)
            {
                length = payload.Length;
            }

            EnsureJavaHeartbeatBridgeBuffer(length);
            for (int i = 0; i < length; i++)
            {
                javaHeartbeatBridge[i] = unchecked((sbyte)payload[i]);
            }

            EnsureSubmitHeartbeatPayloadMethod();
            if (submitHeartbeatPayloadMethodId == IntPtr.Zero)
            {
                return;
            }

            IntPtr nativeArray = AndroidJNIHelper.ConvertToJNIArray(javaHeartbeatBridge);
            jvalue[] args = new jvalue[2];
            args[0].l = nativeArray;
            args[1].i = length;
            AndroidJNI.CallVoidMethod(decoder.GetRawObject(), submitHeartbeatPayloadMethodId, args);
            AndroidJNI.DeleteLocalRef(nativeArray);
        }

        public void RestartStream()
        {
            StopStream();
            StartStream();
        }

        public void StartStream()
        {
            LogVerbose("StartStream requested.");
            Debug.Log(DataManager.Instance.videoDecodeMode + "videoDecodeMode:isav1---->" + (DataManager.Instance.videoDecodeMode == DecoderFlavor.AV1));

            if (!IsAndroidTarget())
            {
                Debug.LogWarning("[QuestStreamVideoPlayer] UDP decoder only runs on Quest/Android devices.");
                return;
            }

            if (decoder != null)
            {
                return;
            }

            try
            {
                string safeAddress = string.IsNullOrWhiteSpace(listenAddress) ? "0.0.0.0" : listenAddress.Trim();

                // 不进行发送端IP检测，接收所有来源的数据
                string safeSender = string.IsNullOrWhiteSpace(expectedSenderIp) ? string.Empty : expectedSenderIp;
                string decoderClass;
                switch (DataManager.Instance.videoDecodeMode)
                {
                    case DecoderFlavor.AV1:
                        decoderClass = "com.example.questdecoder.Av1StreamingDecoder";
                        break;
                    case DecoderFlavor.HEVC:
                        decoderClass = "com.example.questdecoder.HevcStreamingDecoder";
                        break;
                    default:
                        decoderClass = "com.example.questdecoder.H264StreamingDecoder";
                        break;
                }

                decoder = new AndroidJavaObject(
                    decoderClass,
                    expectedWidth,
                    expectedHeight,
                    safeAddress,
                    listenPort,
                    listenPortSecondary,
                    remoteHost,
                    remotePort,
                    safeSender);
                bool enableVerboseLogs = verboseLogging;
                if (verboseLogging)
                {
                    Debug.LogWarning("[QuestStreamVideoPlayer] Verbose logging is disabled for non-development builds.");
                }

                bool enableChecksums = logFrameChecksums;
                if (logFrameChecksums)
                {
                    Debug.LogWarning("[QuestStreamVideoPlayer] Frame checksum logging disabled for non-development builds.");
                }

                decoder.Call("setVerbose", enableVerboseLogs);
                decoder.Call("setDebugChecksums", enableChecksums);

                decoder.Call("setUseReleasePacketFormat", useReleasePacketFormat);
                decoder.Call("setUseExternalUdpTransport", unityReceivesVideoUdp);
                decoder.Call("start");
                StartPacketForwarder();

                if (verboseLogging)
                {
                    Debug.Log($"[QuestStreamVideoPlayer] Listening on UDP {listenPort}, expected sender: {safeSender}");
                }

                framesDecoded = 0;
                emptyFrameTicks = 0;
                ResetStreamClock();
                frameRoutine = StartCoroutine(PullFramesLoop());
            }
            catch (AndroidJavaException ex)
            {
                Debug.LogError($"[QuestStreamVideoPlayer] Failed to start decoder: {ex.Message}");
                decoder = null;
            }
        }

        private IEnumerator PullFramesLoop()
        {
            int consecutivePacketErrors = 0;
            int maxConsecutiveErrors = 10; // 最大连续错误次数
            
            while (decoder != null)
            {
                if (useBufferedPlayback)
                {
                    if (PullDecoderFramesIntoBuffer(ref consecutivePacketErrors, maxConsecutiveErrors))
                    {
                        yield break;
                    }

                    if (paceBySourceTimestamp)
                    {
                        DropLateFrames();
                    }

                    if (decodedFrameQueue.Count == 0)
                    {
                        HandleEmptyFrameTick();
                        yield return null;
                        continue;
                    }

                    DecodedFrame next = decodedFrameQueue.Peek();
                    if (paceBySourceTimestamp && next.HasTimestamp)
                    {
                        double waitSeconds = ComputeWaitSeconds(next.TimestampMs);
                        if (waitSeconds > 0.0)
                        {
                            yield return new WaitForSecondsRealtime((float)Math.Min(waitSeconds, maxWaitPerIterationSeconds));
                            continue;
                        }
                    }

                    DecodedFrame frame = decodedFrameQueue.Dequeue();
                    emptyFrameTicks = 0;
                    HandlePacketHeader(frame.HeaderData);
                    int frameWidth = frame.Width > 0 ? frame.Width : expectedWidth;
                    int frameHeight = frame.Height > 0 ? frame.Height : expectedHeight;
                    ApplyFrameToTargets(frame.ImageBytes, frameWidth, frameHeight, frame.IsYuvFormat);
                    consecutivePacketErrors = 0;

                    yield return null;
                    continue;
                }

                AndroidJavaObject frameBundle = null;
                try
                {
                    frameBundle = DrainDecoderQueue();
                }
                catch (AndroidJavaException ex)
                {
                    consecutivePacketErrors++;
                    Debug.LogError($"[QuestStreamVideoPlayer] dequeueFrameBundle failed (error #{consecutivePacketErrors}): {ex.Message}");
                    
                    // 如果连续错误过多，尝试重新初始化解码器
                    if (consecutivePacketErrors >= maxConsecutiveErrors)
                    {
                        Debug.LogError($"[QuestStreamVideoPlayer] Too many consecutive errors ({consecutivePacketErrors}), attempting to recover...");
                        consecutivePacketErrors = 0;
                        
                        // 重启解码器
                        RestartStream();
                        yield break;
                    }
                }

                if (frameBundle == null)
                {
                    HandleEmptyFrameTick();
                    yield return null;
                    continue;
                }

                try
                {
                    sbyte[] javaFrame = frameBundle.Call<sbyte[]>("getImage");
                    int[] headerData = frameBundle.Call<int[]>("getHeader");
                    HandlePacketHeader(headerData);
                    int frameWidth = frameBundle.Call<int>("getWidth");
                    int frameHeight = frameBundle.Call<int>("getHeight");
                    bool isYuvFormat = false;
                    
                    // 检查是否为YUV格式数据
                    try
                    {
                        isYuvFormat = frameBundle.Call<bool>("isYuvFormat");
                    }
                    catch (AndroidJavaException)
                    {
                        // 如果方法不存在，默认为RGBA格式（向后兼容）
                        isYuvFormat = false;
                    }

                    if (frameWidth <= 0 || frameHeight <= 0)
                    {
                        frameWidth = expectedWidth;
                        frameHeight = expectedHeight;
                    }

                    ApplyFrameToTargets(javaFrame, frameWidth, frameHeight, isYuvFormat);
                    consecutivePacketErrors = 0; // 重置错误计数
                }
                finally
                {
                    if (frameBundle != null)
                    {
                        try
                        {
                            frameBundle.Call("release");
                        }
                        catch (AndroidJavaException ex)
                        {
                            if (verboseLogging)
                            {
                                Debug.LogWarning($"[QuestStreamVideoPlayer] Failed to release decoder frame: {ex.Message}");
                            }
                        }
                        frameBundle.Dispose();
                    }
                }

                yield return null;
            }
        }

        private AndroidJavaObject DrainDecoderQueue()
        {
            if (decoder == null)
            {
                return null;
            }

            AndroidJavaObject latest = null;
            int drainBudget = (drainFrameQueueCompletely || maxFrameDrainPerTick <= 0)
                ? int.MaxValue
                : Mathf.Max(1, maxFrameDrainPerTick);
            int drained = 0;

            while (drained < drainBudget)
            {
                AndroidJavaObject candidate = decoder.Call<AndroidJavaObject>("dequeueFrameBundle");
                if (candidate == null)
                {
                    break;
                }

                latest?.Dispose();
                latest = candidate;
                drained++;
            }

            return latest;
        }

        private void ResetStreamClock()
        {
            hasStreamClock = false;
            baseRemoteTimestampMs = 0;
            baseLocalTimeSeconds = 0;
            decodedFrameQueue.Clear();
        }

        private bool PullDecoderFramesIntoBuffer(ref int consecutivePacketErrors, int maxConsecutiveErrors)
        {
            if (decoder == null)
            {
                return false;
            }

            int drainBudget = (drainFrameQueueCompletely || maxFrameDrainPerTick <= 0)
                ? int.MaxValue
                : Mathf.Max(1, maxFrameDrainPerTick);

            int pulled = 0;
            while (pulled < drainBudget)
            {
                AndroidJavaObject frameBundle = null;
                try
                {
                    frameBundle = decoder.Call<AndroidJavaObject>("dequeueFrameBundle");
                    if (frameBundle == null)
                    {
                        break;
                    }

                    var decoded = new DecodedFrame
                    {
                        ImageBytes = frameBundle.Call<sbyte[]>("getImage"),
                        HeaderData = frameBundle.Call<int[]>("getHeader"),
                        Width = frameBundle.Call<int>("getWidth"),
                        Height = frameBundle.Call<int>("getHeight"),
                        IsYuvFormat = GetIsYuvFormat(frameBundle),
                        HasTimestamp = false,
                        TimestampMs = 0
                    };

                    if (TryParseReleasePacketHeader(decoded.HeaderData, out var header))
                    {
                        decoded.HasTimestamp = true;
                        decoded.TimestampMs = unchecked((uint)header.Timestamp);

                        if (!hasStreamClock)
                        {
                            hasStreamClock = true;
                            baseRemoteTimestampMs = decoded.TimestampMs;
                            baseLocalTimeSeconds = (double)Time.realtimeSinceStartup;
                        }
                    }

                    if (decoded.ImageBytes != null && decoded.ImageBytes.Length > 0)
                    {
                        int targetCapacity = Mathf.Max(1, maxBufferedFrames);
                        while (decodedFrameQueue.Count >= targetCapacity && decodedFrameQueue.Count > 0)
                        {
                            decodedFrameQueue.Dequeue();
                        }
                        decodedFrameQueue.Enqueue(decoded);
                    }
                }
                catch (AndroidJavaException ex)
                {
                    consecutivePacketErrors++;
                    Debug.LogError($"[QuestStreamVideoPlayer] dequeueFrameBundle failed (error #{consecutivePacketErrors}): {ex.Message}");

                    if (consecutivePacketErrors >= maxConsecutiveErrors)
                    {
                        Debug.LogError($"[QuestStreamVideoPlayer] Too many consecutive errors ({consecutivePacketErrors}), attempting to recover...");
                        consecutivePacketErrors = 0;
                        RestartStream();
                        return true;
                    }
                }
                finally
                {
                    if (frameBundle != null)
                    {
                        try
                        {
                            frameBundle.Call("release");
                        }
                        catch { }

                        frameBundle.Dispose();
                    }
                }

                pulled++;
            }

            return false;
        }

        private static bool GetIsYuvFormat(AndroidJavaObject frameBundle)
        {
            if (frameBundle == null)
            {
                return false;
            }

            try
            {
                return frameBundle.Call<bool>("isYuvFormat");
            }
            catch
            {
                return false;
            }
        }

        private double ComputeWaitSeconds(uint remoteTimestampMs)
        {
            if (!hasStreamClock)
            {
                hasStreamClock = true;
                baseRemoteTimestampMs = remoteTimestampMs;
                baseLocalTimeSeconds = (double)Time.realtimeSinceStartup;
                return 0.0;
            }

            uint deltaMs = remoteTimestampMs - baseRemoteTimestampMs;
            if (deltaMs > 5000u)
            {
                // Timestamp discontinuity (stream restart / clock jump). Rebase to avoid multi-second "freeze".
                baseRemoteTimestampMs = remoteTimestampMs;
                baseLocalTimeSeconds = (double)Time.realtimeSinceStartup;
                return 0.0;
            }
            double targetLocalSeconds = baseLocalTimeSeconds + (deltaMs / 1000.0) + playbackDelaySeconds;
            return targetLocalSeconds - (double)Time.realtimeSinceStartup;
        }

        private void DropLateFrames()
        {
            if (!hasStreamClock || decodedFrameQueue.Count <= 1)
            {
                return;
            }

            double now = (double)Time.realtimeSinceStartup;
            double lateThreshold = lateDropThresholdSeconds;

            while (decodedFrameQueue.Count > 1)
            {
                DecodedFrame candidate = decodedFrameQueue.Peek();
                if (!candidate.HasTimestamp)
                {
                    break;
                }

                uint deltaMs = candidate.TimestampMs - baseRemoteTimestampMs;
                double targetLocalSeconds = baseLocalTimeSeconds + (deltaMs / 1000.0) + playbackDelaySeconds;
                if (now - targetLocalSeconds <= lateThreshold)
                {
                    break;
                }

                decodedFrameQueue.Dequeue();
            }
        }

        public void StopStream()
        {
            LogVerbose("StopStream requested.");
            StopPacketForwarder();
            if (frameRoutine != null)
            {
                StopCoroutine(frameRoutine);
                frameRoutine = null;
            }

            if (decoder == null)
            {
                return;
            }

            try
            {
                decoder.Call("stop");
                decoder.Call("release");
            }
            catch (AndroidJavaException ex)
            {
                Debug.LogWarning($"[QuestStreamVideoPlayer] Shutdown error: {ex.Message}");
            }
            finally
            {
                decoder.Dispose();
                decoder = null;
            }

            ResetStreamClock();
        }

        private bool IsAndroidTarget()
        {
            return Application.isPlaying &&
                   !Application.isEditor &&
                   Application.platform == RuntimePlatform.Android;
        }

        private string GetLocalNetworkIP()
        {
            try
            {
                var host = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName());
                foreach (var ip in host.AddressList)
                {
                    if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                    {
                        // 返回本地网络IP（通常是192.168.x.x）
                        if (ip.ToString().StartsWith("192.168."))
                        {
                            return ip.ToString();
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogWarning($"[QuestStreamVideoPlayer] Failed to get local IP: {ex.Message}");
            }
            return string.Empty;
        }

        private byte[] ConvertYuvToRgba(sbyte[] yuvData, int width, int height)
        {
            if (yuvData == null || yuvData.Length == 0 || width <= 0 || height <= 0)
            {
                return null;
            }

            // 验证YUV数据大小，允许一定程度的误差
            int expectedYuvSize = width * height + (width * height) / 2;
            if (yuvData.Length < expectedYuvSize * 0.8f) // 允许20%的数据丢失
            {
                Debug.LogWarning($"[QuestStreamVideoPlayer] YUV data too small! Expected at least {expectedYuvSize * 0.8f}, got {yuvData.Length}");
                return null;
            }

            // 创建RGBA缓冲区
            byte[] rgbaData = new byte[width * height * 4];
            
            // 计算YUV平面大小
            int ySize = width * height;
            int uvSize = (width * height) / 4; // U和V各占1/4
            
            // 使用安全的数据提取方法
            byte[] yPlane = ExtractPlaneSafely(yuvData, 0, ySize, width, height, "Y");
            byte[] uPlane = ExtractPlaneSafely(yuvData, ySize, uvSize, width / 2, height / 2, "U");
            byte[] vPlane = ExtractPlaneSafely(yuvData, ySize + uvSize, uvSize, width / 2, height / 2, "V");
            
            // YUV420到RGBA转换（使用标准转换公式）
            int rgbaIndex = 0;
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    // 获取Y值
                    int yIndex = y * width + x;
                    
                    // 获取UV值（4:2:0采样）
                    int uvX = x / 2;
                    int uvY = y / 2;
                    int uvIndex = uvY * (width / 2) + uvX;
                    
                    // 安全获取YUV值，超出范围时使用默认值
                    float y1 = GetSafeValue(yPlane, yIndex, 128.0f);
                    float u1 = GetSafeValue(uPlane, uvIndex, 128.0f) - 128.0f;
                    float v1 = GetSafeValue(vPlane, uvIndex, 128.0f) - 128.0f;
                    
                    // 标准YUV到RGB转换公式
                    int r = (int)System.Math.Max(0, System.Math.Min(255, y1 + 1.402f * v1));
                    int g = (int)System.Math.Max(0, System.Math.Min(255, y1 - 0.344f * u1 - 0.714f * v1));
                    int b = (int)System.Math.Max(0, System.Math.Min(255, y1 + 1.772f * u1));
                    
                    // 写入RGBA数据
                    rgbaData[rgbaIndex++] = (byte)r;     // R
                    rgbaData[rgbaIndex++] = (byte)g;     // G
                    rgbaData[rgbaIndex++] = (byte)b;     // B
                    rgbaData[rgbaIndex++] = 255;         // A (完全不透明)
                }
            }
            
            return rgbaData;
        }
        
        private byte[] ExtractPlaneSafely(sbyte[] source, int startIndex, int expectedSize, int planeWidth, int planeHeight, string planeName)
        {
            byte[] plane = new byte[expectedSize];
            int actualSize = Math.Min(expectedSize, source.Length - startIndex);
            
            if (actualSize < expectedSize)
            {
                Debug.LogWarning($"[QuestStreamVideoPlayer] {planeName} plane truncated: expected {expectedSize}, got {actualSize}");
            }
            
            Buffer.BlockCopy(source, startIndex, plane, 0, actualSize);
            
            // 填充剩余部分（如果有）
            for (int i = actualSize; i < expectedSize; i++)
            {
                plane[i] = 128; // 中性值
            }
            
            return plane;
        }
        
        private float GetSafeValue(byte[] array, int index, float defaultValue)
        {
            if (index >= 0 && index < array.Length)
            {
                return array[index];
            }
            return defaultValue;
        }

        private void ApplyFrameToTargets(sbyte[] frame, int frameWidth, int frameHeight, bool isYuvFormat)
        {
            if (frame == null || frame.Length == 0)
            {
                HandleEmptyFrameTick();
                return;
            }

            framesDecoded++;
            emptyFrameTicks = 0;

            int expectedYuvSize = frameWidth * frameHeight + (frameWidth * frameHeight) / 2;
            int expectedRgbaSize = frameWidth * frameHeight * 4;

            if (!isYuvFormat && frame.Length != expectedRgbaSize)
            {
                Debug.LogWarning($"[QuestStreamVideoPlayer] RGBA format mismatch! Expected {expectedRgbaSize} bytes for {frameWidth}x{frameHeight}, got {frame.Length} bytes.");
                return;
            }

            if (videoTexture == null || videoTexture.width != frameWidth || videoTexture.height != frameHeight)
            {
                Debug.Log($"[QuestStreamVideoPlayer] Resizing texture from {videoTexture?.width}x{videoTexture?.height} to {frameWidth}x{frameHeight}");
                QuestVideoImageUtils.EnsureTexture(ref videoTexture, frameWidth, frameHeight);
            }

            byte[] convertedFrame = null;
            if (isYuvFormat)
            {
                if (frame.Length != expectedYuvSize)
                {
                    Debug.LogWarning($"[QuestStreamVideoPlayer] YUV frame size mismatch! Expected {expectedYuvSize} bytes, got {frame.Length} bytes for {frameWidth}x{frameHeight} frame.");
                    return;
                }

                convertedFrame = ConvertYuvToRgba(frame, frameWidth, frameHeight);
                if (convertedFrame == null)
                {
                    Debug.LogWarning($"[QuestStreamVideoPlayer] Failed to convert YUV to RGBA for frame #{framesDecoded}.");
                    return;
                }
            }

            if (verboseLogging && framesDecoded % 30 == 0)
            {
                int displayedSize = isYuvFormat ? convertedFrame?.Length ?? 0 : frame.Length;
                Debug.Log($"[QuestStreamVideoPlayer] Frame #{framesDecoded} ({frameWidth}x{frameHeight}) size {displayedSize} bytes ({(isYuvFormat ? "YUV420" : "RGBA32")}).");
            }

            if (isYuvFormat)
            {
                QuestVideoImageUtils.ApplyFrame(videoTexture, convertedFrame);
            }
            else
            {
                QuestVideoImageUtils.ApplyFrame(videoTexture, frame);
            }
            QuestVideoImageUtils.BindTexture(
                videoTexture,
                targetRenderer,
                targetUI,
                flipTextureHorizontally,
                flipTextureVertically,
                frameWidth,
                frameHeight,
                expectedWidth,
                expectedHeight);

            DebugTextManager.Instance?.NotifyVideoFramePresented();
        }

        private void HandlePacketHeader(int[] headerData)
        {
            if (headerData == null || !TryParseReleasePacketHeader(headerData, out var releaseHeader))
            {
                LogReleasePacketHeader(null);
                return;
            }

            latestReleasePacketHeader = releaseHeader;
            if (releasePacketHeaderQueue.Count >= MaxCachedReleasePacketHeaders)
            {
                releasePacketHeaderQueue.Dequeue();
            }
            releasePacketHeaderQueue.Enqueue(releaseHeader);
            ReleasePacketHeaderReceived?.Invoke(releaseHeader);
            LogReleasePacketHeader(releaseHeader);
        }

        private bool TryParseReleasePacketHeader(int[] headerData, out VideoReleasePacketHeader header)
        {
            header = default;
            if (headerData == null || headerData.Length < 8)
            {
                return false;
            }

            header = new VideoReleasePacketHeader
            {
                Timestamp = headerData[0],
                FrameId = headerData[1],
                SplitId = headerData[2],
                TotalSplits = headerData[3],
                FragmentId = headerData[4],
                TotalFragments = headerData[5],
                FragmentSize = headerData[6],
                TestingId = headerData[7]
            };
            return true;
        }

        private void LogVerbose(string message)
        {
            if (verboseLogging)
            {
                Debug.Log($"[QuestStreamVideoPlayer] {message}");
            }
        }

        private void LogDecoderHealth(int ticksWithoutFrame)
        {
            if (!verboseLogging || decoder == null)
            {
                return;
            }

            try
            {
                long produced = decoder.Call<long>("getProducedFrameCount");
                int pending = decoder.Call<int>("getPendingFrameCount");
                long packets = decoder.Call<long>("getPacketsReceived");
                Debug.Log($"[QuestStreamVideoPlayer] Health check (no frames for {ticksWithoutFrame} ticks). Produced={produced}, pending={pending}, packetsReceived={packets}.");
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[QuestStreamVideoPlayer] Failed to query decoder health: {ex.Message}");
            }
        }

        private void HandleEmptyFrameTick()
        {
            emptyFrameTicks++;

            if (!verboseLogging)
            {
                return;
            }

            if (emptyFrameTicks == 1 || emptyFrameTicks % 30 == 0)
            {
                Debug.Log("[QuestStreamVideoPlayer] No frame dequeued this tick.");
                LogDecoderHealth(emptyFrameTicks);
            }
        }

        private void LogReleasePacketHeader(VideoReleasePacketHeader? header)
        {
            if (!verboseLogging)
            {
                return;
            }

            if (!header.HasValue)
            {
                Debug.Log("[QuestStreamVideoPlayer] Release packet header unavailable for this frame.");
                return;
            }

            VideoReleasePacketHeader value = header.Value;
            Debug.Log($"[QuestStreamVideoPlayer] ReleasePacketHeader => timestamp:{value.Timestamp} frame:{value.FrameId} split:{value.SplitId}/{value.TotalSplits} fragment:{value.FragmentId}/{value.TotalFragments} size:{value.FragmentSize} testing:{value.TestingId}");
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            expectedWidth = Mathf.Max(16, expectedWidth);
            expectedHeight = Mathf.Max(16, expectedHeight);
            listenPort = Mathf.Clamp(listenPort, 1024, 65535);
            listenPortSecondary = Mathf.Clamp(listenPortSecondary, 0, 65535);
            maxFrameDrainPerTick = Mathf.Clamp(maxFrameDrainPerTick, 1, 64);
            maxBufferedFrames = Mathf.Clamp(maxBufferedFrames, 1, 16);
        }
#endif
    }
}
