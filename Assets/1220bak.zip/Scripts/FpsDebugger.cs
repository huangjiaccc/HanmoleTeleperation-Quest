
using UnityEngine;
using Debug = AppLog;

public class FpsDebugger : MonoBehaviour
{
    [SerializeField, Tooltip("���������һ��֡��")]
    private float sampleInterval = 0.5f;

    [SerializeField, Tooltip("�Ƿ��֡�����������̨��־")]
    private bool logToConsole = true;

    private float elapsed;
    private int frames;
    private float currentFps;

    private void Update()
    {
        elapsed += Time.unscaledDeltaTime;
        frames++;

        if (elapsed >= sampleInterval)
        {
            currentFps = frames / elapsed;
            if (logToConsole)
            {
                Debug.Log($"[FPS] {currentFps:0.0}");
            }

            elapsed = 0f;
            frames = 0;
        }
    }

    private void OnGUI()
    {
        GUI.Label(new Rect(10, 10, 160, 30), $"FPS: {currentFps:0.0}");
    }
}