﻿using System.Collections.Generic;
using UnityEngine;
using Debug = AppLog;

/// <summary>
/// 通用组件定位器：在给定父节点下通过名称查找 Transform / Component。
/// </summary>
public class AutoBinder : MonoBehaviour
{
    [SerializeField] private Transform lookupRoot;
    [SerializeField] private bool includeInactive = true;

    private readonly Dictionary<string, Transform> _namedTransforms =
        new Dictionary<string, Transform>(System.StringComparer.OrdinalIgnoreCase);
    private bool _cacheBuilt;

    private void Awake()
    {
        EnsureCache();
    }

    /// <summary>
    /// 重新扫描层级，保证缓存与场景一致。
    /// </summary>
    public void RefreshCache()
    {
        BuildCache();
    }

    /// <summary>
    /// 按名称查找 Transform 并返回 GameObject。
    /// </summary>
    public bool TryGetGameObject(string objectName, out GameObject target)
    {
        target = null;
        if (string.IsNullOrEmpty(objectName))
        {
            return false;
        }

        EnsureCache();
        if (_namedTransforms.TryGetValue(objectName, out var tr) && tr != null)
        {
            target = tr.gameObject;
            return true;
        }

        Debug.LogWarning($"[AutoBinder] 未找到名为 {objectName} 的对象。");
        return false;
    }

    /// <summary>
    /// 按名称查找指定类型的组件。
    /// </summary>
    public bool TryGetComponent<T>(string objectName, out T component) where T : Component
    {
        component = null;
        if (string.IsNullOrEmpty(objectName))
        {
            return false;
        }

        EnsureCache();
        if (_namedTransforms.TryGetValue(objectName, out var tr) && tr != null)
        {
            component = tr.GetComponent<T>();
            if (component != null)
            {
                return true;
            }

            Debug.LogWarning($"[AutoBinder] 在 {objectName} 上找不到 {typeof(T).Name} 组件。");
            return false;
        }

        Debug.LogWarning($"[AutoBinder] 未找到名为 {objectName} 的对象。");
        return false;
    }

    private void EnsureCache()
    {
        if (_cacheBuilt && _namedTransforms.Count > 0)
        {
            return;
        }
        BuildCache();
    }

    private void BuildCache()
    {
        _namedTransforms.Clear();
        if (lookupRoot == null)
        {
            lookupRoot = transform;
        }

        if (lookupRoot == null)
        {
            Debug.LogWarning("[AutoBinder] 未设置 lookupRoot，无法缓存层级。");
            return;
        }

        foreach (var tr in lookupRoot.GetComponentsInChildren<Transform>(includeInactive))
        {
            if (tr == null || string.IsNullOrEmpty(tr.name))
            {
                continue;
            }

            if (_namedTransforms.ContainsKey(tr.name))
            {
                continue;
            }

            _namedTransforms.Add(tr.name, tr);
        }

        _cacheBuilt = true;
    }
}
