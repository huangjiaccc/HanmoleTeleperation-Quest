using UnityEngine;
using TMPro;
public class DebugTextManager : MonoBehaviour
{
    
    public static DebugTextManager Instance;
    public TextMeshProUGUI _debugClientstatetext;
    public TextMeshProUGUI _debugServerstatetext;
    public TextMeshProUGUI _debugText1;
    public TextMeshProUGUI _debugText2;
    public TextMeshProUGUI _debugText3;
    public float updateInterval = 0.3f; // 每隔多久更新一次 FPS

    private float _accum = 0f;
    private int _frames = 0;
    private float _timeLeft;

    public float CurrentFPS { get; private set; }
    public float CurrentVideoFPS { get; private set; }

    private int _videoFramesPresented;
    private float _videoTimeAccum;

    public void NotifyVideoFramePresented()
    {
        _videoFramesPresented++;
    }
    private void Awake()
    {
        Instance = this;
    }
    private void Start()
    {
        _timeLeft = updateInterval;

    }

    private void Update()
    {
        _timeLeft -= Time.unscaledDeltaTime;
        _accum += Time.timeScale / Time.unscaledDeltaTime;
        _frames++;
        _videoTimeAccum += Time.unscaledDeltaTime;

        if (_timeLeft <= 0.0f)
        {
            CurrentFPS = _accum / _frames;
            _timeLeft = updateInterval;
            _accum = 0f;
            _frames = 0;


            float videoInterval = Mathf.Max(0.0001f, _videoTimeAccum);
            CurrentVideoFPS = _videoFramesPresented / videoInterval;
            _videoFramesPresented = 0;
            _videoTimeAccum = 0f;
            _debugText1.text = ($"FPS: {CurrentFPS:F1}Video FPS: {CurrentVideoFPS:F1}");
        }
    }
}
