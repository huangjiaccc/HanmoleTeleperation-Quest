using UnityEngine;
using Debug = AppLog;
using System;
using System.Collections.Generic;

public class RobotJointController : MonoBehaviour
{
    [Header("�ؽ�ӳ��")]
    public URDFJointMapper mapper;

    [Header("�ؽ�ֵ��ʾ")]
    public bool showJointValues = true;
    public Vector2 displayOffset = new Vector2(10, 10);

    [Header("��������")]
    public bool logChanges = false;
    public float updateThreshold = 0.001f; // ֻ���±仯���ڴ�ֵ�Ĺؽ�

    // ��ǰ�ؽ�ֵ�洢�����ȣ�
    private double[] currentJoints = new double[20];
    private double[] previousJoints = new double[20];


    double[] zeroJoints = new double[20] {
    0.0f, 0.0f, 0.0f, 0.0f,           // ����: yaw, pitch; ϥ��; ����
    0.0f, 0.0f, 0.0f, 0.0f, 0.0f,     // ���: ������, ������, �ϱ�, ��, ǰ��
    0.0f, 0.0f,                       // ���: ����, ����
    0.0f, 0.0f, 0.0f, 0.0f, 0.0f,     // �ұ�: ������, ������, �ϱ�, ��, ǰ��
    0.0f, 0.0f,                       // �ұ�: ����, ����
    0.0f, 0.0f                        // ����: yaw, pitch
};

    double[] tPoseJoints = new double[20] {
    0.0f,      // waist_yaw: 0
    0.0f,      // waist_pitch: 0
    0.0f,      // knee: 0
    0.0f,      // ankle: 0
    
    // ��� - ˮƽչ������΢����
    0.0f,      // left_shoulder_inner: 0
    1.57f,     // left_shoulder_outer: 90�� (��/2)
    0.0f,      // left_upper_arm: 0
    0.0f,      // left_elbow: 0
    0.0f,      // left_forearm: 0
    0.0f,      // left_wrist_upper: 0
    0.0f,      // left_wrist_lower: 0
    
    // �ұ� - ˮƽչ������΢����
    0.0f,      // right_shoulder_inner: 0
    -1.57f,    // right_shoulder_outer: -90�� (-��/2)
    0.0f,      // right_upper_arm: 0
    0.0f,      // right_elbow: 0
    0.0f,      // right_forearm: 0
    0.0f,      // right_wrist_upper: 0
    0.0f,      // right_wrist_lower: 0
    
    // ����
    0.0f,      // neck_yaw: 0
    0.0f       // neck_pitch: 0
};

    double[] greetingPose = new double[20] {
    0.3f,      // waist_yaw: 17.2�� (��΢��ת)
    0.1f,      // waist_pitch: 5.7�� (��΢ǰ��)
    0.0f,      // knee: 0
    0.0f,      // ankle: 0
    
    // ��� - ��������
    0.0f,      // left_shoulder_inner: 0
    0.8f,      // left_shoulder_outer: 45.8�� (̧��)
    0.5f,      // left_upper_arm: 28.6�� (��ǰ)
    -1.0f,     // left_elbow: -57.3�� (����)
    0.0f,      // left_forearm: 0
    0.2f,      // left_wrist_upper: 11.5��
    -0.2f,     // left_wrist_lower: -11.5��
    
    // �ұ� - ָ������
    0.0f,      // right_shoulder_inner: 0
    -0.5f,     // right_shoulder_outer: -28.6�� (��΢����)
    0.3f,      // right_upper_arm: 17.2�� (��ǰ)
    -1.2f,     // right_elbow: -68.8�� (����)
    0.0f,      // right_forearm: 0
    0.1f,      // right_wrist_upper: 5.7��
    0.1f,      // right_wrist_lower: 5.7��
    
    // ���� - �������
    0.5f,      // neck_yaw: 28.6�� (����)
    0.1f       // neck_pitch: 5.7�� (��΢����)
};
    double[] walkingPose = new double[20] {
    0.1f,      // waist_yaw: 5.7�� (��΢ת��)
    -0.05f,    // waist_pitch: -2.9�� (��΢����)
    0.3f,      // knee: 17.2�� (����)
    0.1f,      // ankle: 5.7��
    
    // ��� - �ڶ����
    0.0f,      // left_shoulder_inner: 0
    0.3f,      // left_shoulder_outer: 17.2�� (���)
    0.2f,      // left_upper_arm: 11.5��
    -0.5f,     // left_elbow: -28.6�� (����)
    0.0f,      // left_forearm: 0
    0.0f,      // left_wrist_upper: 0
    0.0f,      // left_wrist_lower: 0
    
    // �ұ� - �ڶ���ǰ
    0.0f,      // right_shoulder_inner: 0
    -0.3f,     // right_shoulder_outer: -17.2�� (��ǰ)
    0.2f,      // right_upper_arm: 11.5��
    -0.5f,     // right_elbow: -28.6�� (����)
    0.0f,      // right_forearm: 0
    0.0f,      // right_wrist_upper: 0
    0.0f,      // right_wrist_lower: 0
    
    // ���� - ����ǰ��
    0.0f,      // neck_yaw: 0
    0.0f       // neck_pitch: 0
};
    double[] DefaultPose = new double[20] {
        -0.00014,
        0.00045,
        0.00005,
        -0.00123,
        2.54633,
        -0.71035,
        0.92892,
        -2.02177,
        0.05464,
        7.96685,
        -0.03279,
        -2.67748,
        1.73763,
        -2.02177,
        10.3274,
        -10.19626,
        -0.05464,
        28.86209,
        0.0,
        0.0
};

    double[] TestPose = new double[20] 
    {   1.46,0.89,-2.09,1.05,
        -1.56,-0.35,-0.14,0.0,-0.35,0.43,0.43,
        1.57,-0.35,-0.14,0.0,-0.14,0.43,0.43,
        1.03,-0.56
    };


    void Start()
    {
        // �ȴ�һ֡ȷ��mapper�ѳ�ʼ��
        StartCoroutine(InitializeDelayed());
    }

    System.Collections.IEnumerator InitializeDelayed()
    {
        yield return null;

        if (mapper == null)
            mapper = GetComponent<URDFJointMapper>();

        if (mapper != null && mapper.jointMap.Count > 0)
        {
            // ��ʼ��Ϊ��λ
            ResetToZero();
            Debug.Log("�����˹ؽڿ�������ʼ����ɣ��ؽ���: " + mapper.jointMap.Count);
        }
    }

    // �������йؽڵ���λ
    public void ResetToZero()
    {
        ApplyJoints(TestPose);
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.J)) 
        {
            ApplyJoints(walkingPose);
        }
        else if (Input.GetKeyDown(KeyCode.K)) 
        {
            ApplyJoints(greetingPose); 
        }
        else if (Input.GetKeyDown(KeyCode.L)) 
        {
            ApplyJoints(tPoseJoints);
        }
    }

    // ���̶�˳��Ӧ�ùؽ�ֵ�����ȣ�
    public void ApplyJoints(double[] j)
    {
        if (mapper == null || mapper.jointMap == null || mapper.jointMap.Count == 0)
        {
            Debug.LogWarning("�ؽ�ӳ��δ��ʼ����");
            return;
        }

        if (j.Length < 20)
        {
            Debug.LogError($"�ؽ����鳤�Ȳ���: {j.Length}����Ҫ20��");
            return;
        }

        // ���¹ؽ�ֵ
        Array.Copy(currentJoints, previousJoints, currentJoints.Length);
        Array.Copy(j, currentJoints, Math.Min(j.Length, currentJoints.Length));

        // Ӧ��ÿ���ؽ�
        SetJoint(j[0], "waist_yaw");
        SetJoint(j[1], "waist_pitch");
        SetJoint(j[2], "knee");
        SetJoint(j[3], "ankle");

        SetJoint(j[4], "left_shoulder_inner");
        SetJoint(j[5], "left_shoulder_outer");
        SetJoint(j[6], "left_upper_arm");
        SetJoint(j[7], "left_elbow");
        SetJoint(j[8], "left_forearm");
        SetJoint(j[9], "left_wrist_upper");
        SetJoint(j[10], "left_wrist_lower");

        SetJoint(j[11], "right_shoulder_inner");
        SetJoint(j[12], "right_shoulder_outer");
        SetJoint(j[13], "right_upper_arm");
        SetJoint(j[14], "right_elbow");
        SetJoint(j[15], "right_forearm");
        SetJoint(j[16], "right_wrist_upper");
        SetJoint(j[17], "right_wrist_lower");

        SetJoint(j[18], "neck_yaw");
        SetJoint(j[19], "neck_pitch");
    }

    // �����ؽ�����
    void SetJoint(double rad, string name)
    {
        if (!mapper.jointMap.ContainsKey(name))
            return;

        // ����Ƿ��������仯
        int index = GetJointIndex(name);
        if (index >= 0 && Math.Abs(currentJoints[index] - previousJoints[index]) < updateThreshold)
            return;

        var articulation = mapper.jointMap[name];
        if (articulation == null)
            return;

        var drive = articulation.xDrive;
        drive.target = (float)(rad * Mathf.Rad2Deg); // ����ת�Ƕ�
        articulation.xDrive = drive;

        if (logChanges)
        {
            Debug.Log($"{name}: {rad:F6} rad -> {drive.target:F2}��");
        }
    }

    // ��ȡ�ؽ�����
    int GetJointIndex(string name)
    {
        string[] names = new string[]
        {
            "waist_yaw", "waist_pitch", "knee", "ankle",
            "left_shoulder_inner", "left_shoulder_outer", "left_upper_arm", "left_elbow",
            "left_forearm", "left_wrist_upper", "left_wrist_lower",
            "right_shoulder_inner", "right_shoulder_outer", "right_upper_arm", "right_elbow",
            "right_forearm", "right_wrist_upper", "right_wrist_lower",
            "neck_yaw", "neck_pitch"
        };

        return Array.IndexOf(names, name);
    }

    // ��ȡ��ǰ�ؽ�ֵ�����ȣ�
    public double[] GetCurrentJoints()
    {
        return (double[])currentJoints.Clone();
    }

    // ��ȡ��ǰ�ؽ�ֵ���Ƕȣ�
    public float[] GetCurrentJointsDegrees()
    {
        float[] degrees = new float[currentJoints.Length];
        for (int i = 0; i < currentJoints.Length; i++)
        {
            degrees[i] = (float)(currentJoints[i] * Mathf.Rad2Deg);
        }
        return degrees;
    }

    void OnGUI()
    {
        if (!showJointValues || currentJoints == null)
            return;

        GUILayout.BeginArea(new Rect(displayOffset.x, displayOffset.y, 300, 600));
        GUILayout.BeginVertical("box");

        GUILayout.Label("�ؽ�״̬�����ȣ�:");
        for (int i = 0; i < currentJoints.Length; i++)
        {
            string jointName = GetJointName(i);
            GUILayout.Label($"{jointName}: {currentJoints[i]:F4} rad");
        }

        GUILayout.EndVertical();
        GUILayout.EndArea();
    }

    string GetJointName(int index)
    {
        string[] names = new string[]
        {
            "waist_yaw", "waist_pitch", "knee", "ankle",
            "left_shoulder_inner", "left_shoulder_outer", "left_upper_arm", "left_elbow",
            "left_forearm", "left_wrist_upper", "left_wrist_lower",
            "right_shoulder_inner", "right_shoulder_outer", "right_upper_arm", "right_elbow",
            "right_forearm", "right_wrist_upper", "right_wrist_lower",
            "neck_yaw", "neck_pitch"
        };

        return index < names.Length ? names[index] : $"�ؽ�{index}";
    }
}