﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Threading;
using UnityEngine;
using Debug = AppLog;

public class DataManager : MonoBehaviour
{
    public static DataManager Instance;
    [Header("Debug Settings")]
    [Tooltip("控制是否输出 Unity 的 Debug 日志")]
    public bool enableDebugLogs = true;

    [HideInInspector]
    public RobotState oldrobotState;
    [HideInInspector]
    public RobotState currobotState;
    [HideInInspector]
    public ACTION ACTION = new ACTION();
    [HideInInspector]
    public TTS TTS = new TTS();
    private HelmeData helmeData;
    private Transform headTrans;
    private Transform leftHandTrans;
    private Transform rightHandTrans;

    private Vector3 bodyOrigin;
    //[SerializeField]
    //[Tooltip("Offset from head anchor to pelvis (tracking space, meters)")]
    private Vector3 pelvisOffsetFromHead = new Vector3(0f, -0.6f, -0.15f);

    //=============================
    // 线程运行控制
    //=============================
    private Thread sendThread;
    private bool running = false;     // 当前线程是否运行中
    private bool shouldRun = false;   // 控制线程退出的标志位
    private readonly object dataLock = new object();

    //=============================
    // Unity 主线程采集的数据
    //=============================
    private Vector3 latestHeadPos;
    private Quaternion latestHeadRot;

    private Vector3 latestLeftPos;
    private Quaternion latestLeftRot;

    private Vector3 latestRightPos;
    private Quaternion latestRightRot;
    [HideInInspector]
    public float[] latestJoyL = new float[2];
    public float[] latestJoyR = new float[2];
    [HideInInspector]
    public float[] leftFingerPos = new float[6];
    [HideInInspector]
    public float[] rightFingerPos = new float[6];

    private string deviceId;

    private long initialUtcMs;    // 初始绝对时间戳（毫秒）
    private double startTicks;    // Stopwatch 起点
    private double tickToMs;      // tick → ms 转换系数

    private int handmode;


    private Vector3 _lastLeftPosition;
    private Quaternion _lastLeftRotation = Quaternion.identity;
    private Vector3 _lastRightPosition;
    private Quaternion _lastRightRotation = Quaternion.identity;
    private bool _wasLeftConnected;
    private bool _wasRightConnected;

    private static readonly Queue<Action> actions = new Queue<Action>();
    private JsonSerializerSettings jsonSettings = new JsonSerializerSettings
    {
        NullValueHandling = NullValueHandling.Ignore
    };
    [HideInInspector]
    public long lastTimestamp { get; private set; } // 最终稳定时间戳
    [HideInInspector]
    public float LeftHandAngle;
    [HideInInspector]
    public float RightHandAngle;
    [HideInInspector]
    public float robotheight;
    [HideInInspector]
    public int velocity;

    [HideInInspector]
    public RobotStateMessage robotStateMessage;
    [HideInInspector]
    public RobotStateData latestRobotStateData;
    [HideInInspector]
    public RobotJointStateMessage robotJointStateMessage;
    [HideInInspector]
    public RobotJointStateData latestRobotJointStateData;
    [HideInInspector]
    public DecoderFlavor videoDecodeMode = DecoderFlavor.AV1;

    private void Awake()
    {
        Instance = this;
        videoDecodeMode = DecoderFlavor.AV1;
        UnityEngine.Debug.unityLogger.logEnabled = enableDebugLogs;
        AppLog.SetAll(enableDebugLogs);
    }

    private void Start()
    {

        currobotState = new RobotState();
        oldrobotState = new RobotState();
        helmeData = new HelmeData();

#if !IS_ANDROID
        leftBoneMap = new Dictionary<OVRSkeleton.BoneId, Transform>();
        rightBoneMap = new Dictionary<OVRSkeleton.BoneId, Transform>();
        ovrRig = GameObject.Find("OVRCameraRig")?.GetComponent<OVRCameraRig>();
        if (OVRManager.instance != null)
        {
            OVRManager.instance.isInsightPassthroughEnabled = false;
        }

        if (leftSkeleton != null)
        {
            foreach (var b in leftSkeleton.Bones)
            {
                leftBoneMap[b.Id] = b.Transform;
            }
        }

        if (rightSkeleton != null)
        {
            foreach (var b in rightSkeleton.Bones)
            {
                rightBoneMap[b.Id] = b.Transform;
            }
        }

        if (ovrRig != null)
        {
            headTrans = ovrRig.centerEyeAnchor;
        }

        leftHandTrans = GetXRPalm(leftSkeleton);
        rightHandTrans = GetXRPalm(rightSkeleton);
#endif

        InitHelmeDataArrays();
        StartCoroutine(WaitTimeGetBodyPos());
    }

    //---------------------------------------------
    //   Unity 主线程采集输入（60 FPS）
    //---------------------------------------------
    float testtime;
    private void Update()
    {
        lock (dataLock)
        {
#if IS_ANDROID
            SampleAndroidInput();
#else
            SampleQuestInput();
#endif
            deviceId = SystemInfo.deviceUniqueIdentifier;
            //if (AudioStreamPlayer.Instance != null)
            //{
            //    audioVolume = AudioStreamPlayer.Instance.volumeSlider.value;
            //}

            lock (actions)
            {
                while (actions.Count > 0)
                {
                    actions.Dequeue().Invoke();
                }
            }

        }
    }
    public static void Enqueue(Action action)
    {
        lock (actions)
        {
            actions.Enqueue(action);
        }
    }


    public void UpdateRobotState(RobotStateMessage message)
    {
        robotStateMessage = message;
        latestRobotStateData = message != null ? message.data : null;
    }

    public void UpdateRobotJointState(RobotJointStateMessage message)
    {
        robotJointStateMessage = message;
        latestRobotJointStateData = message != null ? message.data : null;
    }
    private IEnumerator WaitTimeGetBodyPos()
    {
        yield return new WaitForSeconds(0.5f);
        InitBodyOrigin();
    }

    // 初始化所有数组（避免GC）
    private void InitHelmeDataArrays()
    {
        helmeData.pos_head = new float[3];
        helmeData.quat_head = new float[4];

        helmeData.pos_left_hand = new float[6];
        helmeData.pos_left_arm = new float[3];
        helmeData.quat_left_arm = new float[4];

        helmeData.pos_right_hand = new float[6];
        helmeData.pos_right_arm = new float[3];
        helmeData.quat_right_arm = new float[4];

        helmeData.joystick_left = new float[2];
        helmeData.joystick_right = new float[2];

        robotheight = 1;
        velocity = 20;
        LeftHandAngle = 1;
        RightHandAngle = 1;

        // 初始化单调时钟
        // 1. 获取初始 UTC 时间戳（用于和服务器对齐）
        initialUtcMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

        // 2. 初始化单调时钟（不会漂移）
        startTicks = Stopwatch.GetTimestamp();
        tickToMs = 1000.0 / Stopwatch.Frequency;
    }


    //---------------------------------------------
    //   手动选择机器人 → 开启线程
    //---------------------------------------------
    public void OnSelectRobot(string deviceId)
    {
        NetClient.instance._heartbeatMessage.target_device_id = deviceId;
        StartSending();
    }

    //---------------------------------------------
    //   启动发送线程
    //---------------------------------------------
    public void StartSending()
    {
        if (running)
        {
            Debug.Log("  线程已经启动");
            return;
        }

        Debug.Log("  启动100Hz发送线程");

        shouldRun = true;
        sendThread = new Thread(ThreadSendLoop);
        sendThread.IsBackground = true;
        sendThread.Start();

    }

    //---------------------------------------------
    //   100Hz 发送线程（独立，不受Unity FPS影响）
    //---------------------------------------------
    private void ThreadSendLoop()
    {
        running = true;

        while (shouldRun)
        {
            lock (dataLock)
            {

                // 复制全部姿态与输入
                helmeData.pos_head[0] = latestHeadPos.x;
                helmeData.pos_head[1] = latestHeadPos.y;
                helmeData.pos_head[2] = latestHeadPos.z;

                helmeData.quat_head[0] = latestHeadRot.x;
                helmeData.quat_head[1] = latestHeadRot.y;
                helmeData.quat_head[2] = latestHeadRot.z;
                helmeData.quat_head[3] = latestHeadRot.w;

                helmeData.hand_left = LeftHandAngle;
                helmeData.pos_left_hand = leftFingerPos;
                helmeData.pos_left_arm[0] = latestLeftPos.x;
                helmeData.pos_left_arm[1] = latestLeftPos.y;
                helmeData.pos_left_arm[2] = latestLeftPos.z;

                helmeData.quat_left_arm[0] = latestLeftRot.x;
                helmeData.quat_left_arm[1] = latestLeftRot.y;
                helmeData.quat_left_arm[2] = latestLeftRot.z;
                helmeData.quat_left_arm[3] = latestLeftRot.w;

                helmeData.hand_right = RightHandAngle;
                helmeData.pos_right_hand = rightFingerPos;
                helmeData.pos_right_arm[0] = latestRightPos.x;
                helmeData.pos_right_arm[1] = latestRightPos.y;
                helmeData.pos_right_arm[2] = latestRightPos.z;

                helmeData.quat_right_arm[0] = latestRightRot.x;
                helmeData.quat_right_arm[1] = latestRightRot.y;
                helmeData.quat_right_arm[2] = latestRightRot.z;
                helmeData.quat_right_arm[3] = latestRightRot.w;

                helmeData.joystick_left[0] = latestJoyL[0];
                helmeData.joystick_left[1] = latestJoyL[1];

                helmeData.joystick_right[0] = latestJoyR[0];
                helmeData.joystick_right[1] = latestJoyR[1];
                helmeData.velocity = velocity;
                helmeData.hand_mode = handmode;
            }

            // 发送时间戳
            helmeData.ts = lastTimestamp;
            helmeData.device_id = deviceId;
            helmeData.height = robotheight;

            // 状态
            //currobotState.SET_AUDIO_VOLUME = audioVolume;
            currobotState.TTS = TTS;
            currobotState.ACTION = ACTION;
            PartialCommand partial = CommandDiff.BuildPartial(oldrobotState, currobotState);
            helmeData.commands = CommandDiff.IsEmpty(partial) ? null : partial;
            // JSON
            string json = JsonConvert.SerializeObject(helmeData, jsonSettings);
            var utf8 = Encoding.UTF8;
            int payloadLength = utf8.GetByteCount(json);
            byte[] pooledBuffer = null;
            try
            {
                pooledBuffer = ByteArrayPool.Rent(payloadLength);
                utf8.GetBytes(json, 0, json.Length, pooledBuffer, 0);
                NetClient.instance.udpDataManager.Send(pooledBuffer, null, payloadLength);
            }
            finally
            {
                if (pooledBuffer != null)
                {
                    ByteArrayPool.Return(pooledBuffer);
                }
                ResetCommandTriggers();
                oldrobotState = currobotState.Clone(currobotState);
            }
            Enqueue(() =>
            {
                //Debug.Log(json);
                //DebugTextManager.Instance._debugText1.text = "robotheight:" + robotheight;
                //DebugTextManager.Instance._debugText1.text += "velocity:" + velocity;
            });

            Thread.Sleep(10); //  固定 100Hz
        }
        running = false;
    }

    private float angle;
    private Vector3 pDir;
    private Vector3 cDir;
    // 计算单个关节的弯曲度（0~1）
    private float CalcCurl(Transform parent, Transform child, float maxAngle = 90f)
    {
        pDir = parent.rotation * Vector3.forward;
        cDir = child.rotation * Vector3.forward;
        angle = Vector3.Angle(pDir, cDir);
        return Mathf.InverseLerp(0f, maxAngle, angle);
    }

    private void SampleAndroidInput()
    {
        double elapsedMs = (Stopwatch.GetTimestamp() - startTicks) * tickToMs;
        lastTimestamp = initialUtcMs + (long)elapsedMs;
        latestHeadPos = Vector3.zero;
        latestHeadRot = Quaternion.identity;
        latestLeftPos = Vector3.zero;
        latestLeftRot = Quaternion.identity;
        latestRightPos = Vector3.zero;
        latestRightRot = Quaternion.identity;
        latestJoyL[0] = latestJoyL[1] = 0f;
        latestJoyR[0] = latestJoyR[1] = 0f;
        Array.Clear(leftFingerPos, 0, leftFingerPos.Length);
        Array.Clear(rightFingerPos, 0, rightFingerPos.Length);
        handmode = 0;
    }


#if !IS_ANDROID
    private OVRCameraRig ovrRig;
    [Header("左手 (手势模式)")]
    public OVRHand leftHand;
    public OVRSkeleton leftSkeleton;

    [Header("右手 (手势模式)")]
    public OVRHand rightHand;
    public OVRSkeleton rightSkeleton;

    private Dictionary<OVRSkeleton.BoneId, Transform> leftBoneMap;
    private Dictionary<OVRSkeleton.BoneId, Transform> rightBoneMap;

    // XRHand 系列骨骼（新版）
    private readonly OVRSkeleton.BoneId[][] xrFingerBones = new OVRSkeleton.BoneId[][]
    {
        // Thumb
        new OVRSkeleton.BoneId[]
        {
            OVRSkeleton.BoneId.XRHand_ThumbMetacarpal,
            OVRSkeleton.BoneId.XRHand_ThumbProximal,
            OVRSkeleton.BoneId.XRHand_ThumbDistal
        },

        // Index
        new OVRSkeleton.BoneId[]
        {
            OVRSkeleton.BoneId.XRHand_IndexMetacarpal,
            OVRSkeleton.BoneId.XRHand_IndexProximal,
            OVRSkeleton.BoneId.XRHand_IndexIntermediate
        },

        // Middle
        new OVRSkeleton.BoneId[]
        {
            OVRSkeleton.BoneId.XRHand_MiddleMetacarpal,
            OVRSkeleton.BoneId.XRHand_MiddleProximal,
            OVRSkeleton.BoneId.XRHand_MiddleIntermediate
        },

        // Ring
        new OVRSkeleton.BoneId[]
        {
            OVRSkeleton.BoneId.XRHand_RingMetacarpal,
            OVRSkeleton.BoneId.XRHand_RingProximal,
            OVRSkeleton.BoneId.XRHand_RingIntermediate
        },

        // Little
        new OVRSkeleton.BoneId[]
        {
            OVRSkeleton.BoneId.XRHand_LittleMetacarpal,
            OVRSkeleton.BoneId.XRHand_LittleProximal,
            OVRSkeleton.BoneId.XRHand_LittleIntermediate
        }
    };
    
    private Transform GetXRPalm(OVRSkeleton skeleton)
    {
        foreach (var bone in skeleton.Bones)
        {
            if (bone.Id == OVRSkeleton.BoneId.XRHand_Palm)
            {
                return bone.Transform;
            }
        }
        return null;
    }
    
    private bool IsLeftHandTracking(OVRInput.Controller controller) 
    {
        return controller == OVRInput.Controller.Hands ||
               controller == OVRInput.Controller.LHand;
    }
    private bool IsRightHandTracking(OVRInput.Controller controller)
    {
        return controller == OVRInput.Controller.Hands ||
               controller == OVRInput.Controller.RHand;
    }

    private bool IsHandTracking(OVRInput.Controller controller)
    {
        return controller == OVRInput.Controller.Hands ||
               controller == OVRInput.Controller.LHand ||
               controller == OVRInput.Controller.RHand;
    }

    private void CacheControllerPose(
        OVRInput.Controller controller,
        bool isConnected,
        ref bool wasConnected,
        ref Vector3 lastPosition,
        ref Quaternion lastRotation)
    {
        if (isConnected)
        {
            // 更新为最新姿态，只要控制器在线就刷新
            lastPosition = OVRInput.GetLocalControllerPosition(controller);
            lastRotation = OVRInput.GetLocalControllerRotation(controller);
        }
        else if (wasConnected && !isConnected)
        {
            // 丢失控制器时保持上一帧缓存，不做额外处理
        }

        wasConnected = isConnected;
    }
    private Transform j0;
    private Transform j1;
    private Transform j2;
    // 获取五指三关节的 curl（[finger][joint]）
    private void GetFingerCurls()
    {
        if(leftBoneMap.Count <= 0) { return; }
        for (int f = 0; f < 5; f++)
        {
            j0 = leftBoneMap[xrFingerBones[f][0]];
            j1 = leftBoneMap[xrFingerBones[f][1]];
            j2 = leftBoneMap[xrFingerBones[f][2]];
            if (f == 0)
            {
                leftFingerPos[f] = CalcCurl(j0, j1);
                leftFingerPos[f + 1] = CalcCurl(j1, j2);
            }
            else
            {
                leftFingerPos[f + 1] = CalcCurl(j0, j1);
            }
        }

        for (int f = 0; f < 5; f++)
        {
            j0 = rightBoneMap[xrFingerBones[f][0]];
            j1 = rightBoneMap[xrFingerBones[f][1]];
            j2 = rightBoneMap[xrFingerBones[f][2]];
            if (f == 0)
            {
                rightFingerPos[f] = CalcCurl(j0, j1);
                rightFingerPos[f + 1] = CalcCurl(j1, j2);
            }
            else
            {
                rightFingerPos[f + 1] = CalcCurl(j0, j1);
            }
        }
    }

    private void SampleQuestInput()
    {
        var activeController = OVRInput.GetActiveController();
        handmode = IsHandTracking(activeController) ? 1 : 0;

        _lastLeftPosition = BackToRelativePosition(latestLeftPos);
        _lastLeftRotation = latestLeftRot;
        _lastRightPosition = BackToRelativePosition(latestRightPos);
        _lastRightRotation = latestRightRot;

        bool leftControlConnected = OVRInput.IsControllerConnected(OVRInput.Controller.LTouch);
        bool rightControlConnected = OVRInput.IsControllerConnected(OVRInput.Controller.RTouch);

        CacheControllerPose(OVRInput.Controller.LTouch, leftControlConnected, ref _wasLeftConnected,
            ref _lastLeftPosition, ref _lastLeftRotation);
        CacheControllerPose(OVRInput.Controller.RTouch, rightControlConnected, ref _wasRightConnected,
            ref _lastRightPosition, ref _lastRightRotation);

        double elapsedMs = (Stopwatch.GetTimestamp() - startTicks) * tickToMs;
        lastTimestamp = initialUtcMs + (long)elapsedMs;

        if (headTrans != null)
        {
            latestHeadPos = GetBodyRelativePosition(headTrans.position);
            latestHeadRot = headTrans.rotation;
        }
        else
        {
            latestHeadPos = Vector3.zero;
            latestHeadRot = Quaternion.identity;
        }

        if (!leftControlConnected && !IsLeftHandTracking(activeController))
        {
            latestLeftPos = GetBodyRelativePosition(_lastLeftPosition);
            latestLeftRot = _lastLeftRotation;
        }
        else if (leftHandTrans != null)
        {
            latestLeftPos = GetBodyRelativePosition(leftHandTrans.position);
            latestLeftRot = leftHandTrans.rotation;
        }

        if (!rightControlConnected && !IsRightHandTracking(activeController))
        {
            latestRightPos = GetBodyRelativePosition(_lastRightPosition);
            latestRightRot = _lastRightRotation;
        }
        else if (rightHandTrans != null)
        {
            latestRightPos = GetBodyRelativePosition(rightHandTrans.position);
            latestRightRot = rightHandTrans.rotation;
        }

        latestJoyL[0] = OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick).x;
        latestJoyL[1] = OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick).y;

        latestJoyR[0] = OVRInput.Get(OVRInput.Axis2D.SecondaryThumbstick).x;
        latestJoyR[1] = OVRInput.Get(OVRInput.Axis2D.SecondaryThumbstick).y;

        GetFingerCurls();
    }
#endif

    //---------------------------------------------
    //   停止发送线程
    //---------------------------------------------

    public void StopSending()
    {
        if (!running)
        {
            Debug.Log("  线程未运行");
            return;
        }

        Debug.Log("  请求停止发送线程…");
        shouldRun = false;
    }

    //---------------------------------------------
    //   数据是否变化
    //---------------------------------------------

    private void InitBodyOrigin()
    {
        RefreshBodyOriginFromHead();
    }

    public void RefreshBodyOriginFromHead()
    {
        if (headTrans == null)
        {
            bodyOrigin = Vector3.zero;
            return;
        }
        bodyOrigin = headTrans.position + pelvisOffsetFromHead;
        Debug.Log("bodyOrigin" + bodyOrigin);
    }

    private Vector3 GetBodyRelativePosition(Vector3 worldPos)
    {
        return worldPos - bodyOrigin;
    }

    private Vector3 BackToRelativePosition(Vector3 bodyPos)
    {
        return bodyPos + bodyOrigin;
    }

    //---------------------------------------------
    //  Unity销毁时必须停止线程（非常重要）
    //---------------------------------------------
    private void OnDestroy()
    {
        shouldRun = false;

        if (sendThread != null && sendThread.IsAlive)
        {
            sendThread.Join();
        }
    }

    private void ResetCommandTriggers()
    {
        if (ACTION != null)
        {
            ACTION.cmd = string.Empty;
            ACTION.name = string.Empty;
        }

        if (TTS != null)
        {
            TTS.cmd = string.Empty;
            TTS.text = string.Empty;
        }

        currobotState.ACTION = ACTION;
        currobotState.TTS = TTS;

        currobotState.MOVE_IDX_LEFT_X = 0f;
        currobotState.MOVE_IDX_LEFT_Y = 0f;
        currobotState.MOVE_IDX_RIGHT_X = 0f;
        currobotState.MOVE_IDX_RIGHT_Y = 0f;
        currobotState.SET_LEFT_ROTATE_ANGLE = 0f;
        currobotState.SET_RIGHT_ROTATE_ANGLE = 0f;
    }
}
