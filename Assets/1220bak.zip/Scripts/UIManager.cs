using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using Debug = AppLog;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance;

    public GameObject loginPanel;
    public GameObject selectPanel;
    public GameObject confirmPanel;
    public GameObject robotSelect_prefab;
    public GameObject robotSelectContent;



    private float timer = 0f;
    private readonly Dictionary<string, Button> buttonDict = new Dictionary<string, Button>();
    private readonly Dictionary<string, string> lastRobotSnapshot = new Dictionary<string, string>();

    int clickindex = 0;

    [Header("loginpanel")]
    public Button openserverlist_btn;
    public GameObject serverlist_page;
    public InputField ip_inputField;
    public TMP_InputField tmpip_inputField;
    public Button server1_btn;
    public Button server2_btn;
    public Button server3_btn;
    public Button loginBtn;
    public Toggle islantoggle;
    public Toggle videoav1_tog;
    public Toggle videoh264_tog;
    public Toggle videohevc_tog;

    [Header("Robot Command Buttons")]
    public Button robotModeBtn;
    public Button robotAudioBtn;
    public Button robotVideoBtn;

    [Header("TTS UI")]
    public Toggle TTSToggle;
    //public GameObject TTSTogGroup;
    public GameObject TTSListObj;
    public GameObject TTSListContent;
    public Button TTSCmdPlayButton;
    public Button TTSCmdPauseButton;
    public Button TTSCmdStopButton;
    private string TTSCmdText;
    //private List<Button> TTSCmdBtnList = new List<Button>();
    private List<Button> TTSBtnList = new List<Button>();

    [Header("Action UI")]
    public Toggle ActionToggle;
    //public GameObject ActionTogGroup;
    public GameObject ActionListObj;
    public GameObject ActionListContent;

    public Button ActionCmdPlayButton;
    public Button ActionCmdPauseButton;
    public Button ActionCmdStopButton;
    //private List<Button> ActionCmdBtnList = new List<Button>();
    private List<Button> ActionBtnList = new List<Button>();


    private string ActionCmdText;

    [Header("Settings UI")]
    public Toggle settingTog;
    public GameObject settingPanel;

    [Header("Hand Input UI")]
    public Slider leftSlider;
    public TextMeshProUGUI leftSliderText;
    public Slider rightSlider;
    public TextMeshProUGUI rightSliderText;

    public FixedJoystick leftJoy;
    public FixedJoystick rightJoy;

    public Slider volumeSlider;
    public TextMeshProUGUI volumeSliderText;
    public Slider heightSlider;
    public TextMeshProUGUI heightSliderText;


    [Header("TTS Presets")]
    [SerializeField] private List<string> defaultTTSOptions = new List<string> ()/*{ "Hi", "WelCome", "I Can" }*/;

    [Header("Action Presets")]
    [SerializeField] private List<string> defaultActionOptions = new List<string>();
    //{
    //    "wave_hand",
    //    "thumbs_up",
    //    "bow",
    //    "hands_up",
    //    "home",
    //    "handshake",
    //    "pick_from_floor",
    //    "place_item",
    //    "pick_object",
    //    "place_object",
    //};

    private readonly int[] robotModePattern = { 0, 1, 2, 1, 0 };
    private readonly int[] robotAudioPattern = { 0, 1, 2, 1, 0 };
    private readonly int[] robotVideoPattern = { 0, 1, 2, 1, 0 };
    private int robotModeIndex;
    private int robotAudioIndex;
    private int robotVideoIndex;
    private bool ttsListNeedsRebuild = true;
    private bool actionListNeedsRebuild = true;
    private bool haveLogin =false;
    private bool robotListInitialized;
    //public Button PassthroughBtn;


    private Color ModeBtnDefaultColor;              //#1A2236;
    private Color ModeBtnClickColor;                //#004E63;

    private Color GroupBtnDefaultColor;         //#0D1622

    private Color StartBtnClickColor;           //#00FF17;
    private Color PauseBtnClickColor;           //#FFB020;
    private Color StopBtnClickColor;            //#FF0E00;

    private Color DefaultPrefabTextColor; //#2DE1EB
    private Color ClickPrefabTextColor;   //#FFFFFF

    private Color DefaultPrefabBtnColor; //#132E3F
    private Color ClickPrefabBtnColor;   //#00CFEA

    [Header("leftcam按钮")]
    public Button MOVE_IDX_LEFT_X_ADDBtn;
    public Button MOVE_IDX_LEFT_X_REDUCEBtn;
    public Button MOVE_IDX_LEFT_Y_ADDBtn;
    public Button MOVE_IDX_LEFT_Y_REDUCEBtn;
    public Button SET_LEFT_ROTATE_ANGLE_ADDBtn;
    public Button SET_LEFT_ROTATE_ANGLE_REDUCEBtn;


    [Header("rightcam按钮")]
    public Button MOVE_IDX_RIGHT_X_ADDBtn;
    public Button MOVE_IDX_RIGHT_X_REDUCEBtn;
    public Button MOVE_IDX_RIGHT_Y_ADDBtn;
    public Button MOVE_IDX_RIGHT_Y_REDUCEBtn;
    public Button SET_RIGHT_ROTATE_ANGLEADDBtn;
    public Button SET_RIGHT_ROTATE_ANGLEREDUCEBtn;

    private void Awake()
    {
        Instance = this;
    }

    private void Start()
    {
        if (loginBtn != null)
        {
            AddPointerClickEvent(loginBtn, LoginBtnClick);
        }
        if (openserverlist_btn != null)
        {
            AddPointerClickEvent(openserverlist_btn, OnServerListBtnClick);
        }
        if (server1_btn != null)
        {
            AddPointerClickEvent(server1_btn, () => { OnSetServer(server1_btn); });
        }
        if (server2_btn != null)
        {
            AddPointerClickEvent(server2_btn, () => { OnSetServer(server2_btn); });
        }
        if (server3_btn != null)
        {
            AddPointerClickEvent(server3_btn, () => { OnSetServer(server3_btn); });
        }
        if (ip_inputField != null)
        {
            ip_inputField.text = RuntimeServerConfig.serverIp;
        }

        if (tmpip_inputField != null)
        {
            tmpip_inputField.text = RuntimeServerConfig.serverIp;
        }

        if (islantoggle != null)
        {
            islantoggle.onValueChanged.AddListener((bool ison) =>
            {
                Debug.Log("CurIsLan:" + islantoggle.isOn);
                if (ison)
                {
                    NetClient.instance.islan = true;
                    islantoggle.transform.Find("Label").GetComponent<Text>().text = "本地连接";
                }
                else
                {
                    NetClient.instance.islan = false;
                    islantoggle.transform.Find("Label").GetComponent<Text>().text = "远程连接";
                }
            });
            islantoggle.isOn = false;
        }

        if (videoav1_tog != null)
        {
            videoav1_tog.onValueChanged.AddListener((bool ison) =>
            {
                if (ison)
                {
                    DataManager.Instance.videoDecodeMode = DecoderFlavor.AV1;
                    if (videoh264_tog != null && videoh264_tog.isOn) videoh264_tog.isOn = false;
                    if (videohevc_tog != null && videohevc_tog.isOn) videohevc_tog.isOn = false;
                }
            });
            videoav1_tog.isOn = true;
        }

        if (videoh264_tog != null)
        {
            videoh264_tog.onValueChanged.AddListener((bool ison) =>
            {
                if (ison)
                {
                    DataManager.Instance.videoDecodeMode = DecoderFlavor.H264;
                    if (videoav1_tog != null && videoav1_tog.isOn) videoav1_tog.isOn = false;
                    if (videohevc_tog != null && videohevc_tog.isOn) videohevc_tog.isOn = false;
                }
            });
            videoh264_tog.isOn = false;
        }

        if (videohevc_tog != null)
        {
            videohevc_tog.onValueChanged.AddListener((bool ison) =>
            {
                if (ison)
                {
                    DataManager.Instance.videoDecodeMode = DecoderFlavor.HEVC;
                    if (videoav1_tog != null && videoav1_tog.isOn) videoav1_tog.isOn = false;
                    if (videoh264_tog != null && videoh264_tog.isOn) videoh264_tog.isOn = false;
                }
            });
            videohevc_tog.isOn = false;
        }

        if (loginPanel != null) loginPanel.SetActive(true);
        if (selectPanel != null) selectPanel.SetActive(false);
        if (settingPanel != null) settingPanel.SetActive(false);



        //临时添加！！

        if (MOVE_IDX_LEFT_X_ADDBtn != null) 
        {
            MOVE_IDX_LEFT_X_ADDBtn.onClick.AddListener(() =>
            {
                if (DataManager.Instance != null && DataManager.Instance.currobotState != null)
                {
                    DataManager.Instance.currobotState.MOVE_IDX_LEFT_X = 0.1f;
                }
            });
        }

        if (MOVE_IDX_LEFT_X_REDUCEBtn != null)
        {
            MOVE_IDX_LEFT_X_REDUCEBtn.onClick.AddListener(() =>
            {
                if (DataManager.Instance != null && DataManager.Instance.currobotState != null)
                {
                    DataManager.Instance.currobotState.MOVE_IDX_LEFT_X = -0.1f;
                }
            });
        }


        if (MOVE_IDX_LEFT_Y_ADDBtn != null)
        {
            MOVE_IDX_LEFT_Y_ADDBtn.onClick.AddListener(() =>
            {
                if (DataManager.Instance != null && DataManager.Instance.currobotState != null)
                {
                    DataManager.Instance.currobotState.MOVE_IDX_LEFT_Y = 0.1f;
                }
            });
        }

        if (MOVE_IDX_LEFT_Y_REDUCEBtn != null)
        {
            MOVE_IDX_LEFT_Y_REDUCEBtn.onClick.AddListener(() =>
            {
                if (DataManager.Instance != null && DataManager.Instance.currobotState != null)
                {
                    DataManager.Instance.currobotState.MOVE_IDX_LEFT_Y = -0.1f;
                }
            });
        }


        if (MOVE_IDX_RIGHT_X_ADDBtn != null) 
        {
            MOVE_IDX_RIGHT_X_ADDBtn.onClick.AddListener(() =>
            {
                if (DataManager.Instance != null && DataManager.Instance.currobotState != null)
                {
                    DataManager.Instance.currobotState.MOVE_IDX_RIGHT_X = 0.1f;
                }
            });
        }

        if (MOVE_IDX_RIGHT_X_REDUCEBtn != null)
        {
            MOVE_IDX_RIGHT_X_REDUCEBtn.onClick.AddListener(() =>
            {
                if (DataManager.Instance != null && DataManager.Instance.currobotState != null)
                {
                    DataManager.Instance.currobotState.MOVE_IDX_RIGHT_X = -0.1f;
                }
            });
        }


        if (MOVE_IDX_RIGHT_Y_ADDBtn != null)
        {
            MOVE_IDX_RIGHT_Y_ADDBtn.onClick.AddListener(() =>
            {
                if (DataManager.Instance != null && DataManager.Instance.currobotState != null)
                {
                    DataManager.Instance.currobotState.MOVE_IDX_RIGHT_Y = 0.1f;
                }
            });
        }

        if (MOVE_IDX_RIGHT_Y_REDUCEBtn != null)
        {
            MOVE_IDX_RIGHT_Y_REDUCEBtn.onClick.AddListener(() =>
            {
                if (DataManager.Instance != null && DataManager.Instance.currobotState != null)
                {
                    DataManager.Instance.currobotState.MOVE_IDX_RIGHT_Y = -0.1f;
                }
            });
        }


        if (SET_LEFT_ROTATE_ANGLE_ADDBtn != null)
        {
            SET_LEFT_ROTATE_ANGLE_ADDBtn.onClick.AddListener(() =>
            {
                if (DataManager.Instance != null && DataManager.Instance.currobotState != null)
                {
                    DataManager.Instance.currobotState.SET_LEFT_ROTATE_ANGLE = 0.1f;
                }
            });
        }

        if (SET_LEFT_ROTATE_ANGLE_REDUCEBtn != null)
        {
            SET_LEFT_ROTATE_ANGLE_REDUCEBtn.onClick.AddListener(() =>
            {
                if (DataManager.Instance != null && DataManager.Instance.currobotState != null)
                {
                    DataManager.Instance.currobotState.SET_LEFT_ROTATE_ANGLE = -0.1f;
                }
            });
        }


        if (SET_RIGHT_ROTATE_ANGLEADDBtn != null)
        {
            SET_RIGHT_ROTATE_ANGLEADDBtn.onClick.AddListener(() =>
            {
                if (DataManager.Instance != null && DataManager.Instance.currobotState != null)
                {
                    DataManager.Instance.currobotState.SET_RIGHT_ROTATE_ANGLE = 0.1f;
                }
            });
        }

        if (SET_RIGHT_ROTATE_ANGLEREDUCEBtn != null)
        {
            SET_RIGHT_ROTATE_ANGLEREDUCEBtn.onClick.AddListener(() =>
            {
                if (DataManager.Instance != null && DataManager.Instance.currobotState != null)
                {
                    DataManager.Instance.currobotState.SET_RIGHT_ROTATE_ANGLE = -0.1f;
                }
            });
        }


        RegisterRobotCommandButtons();
        SetupTTSUI();
        SetupActionUI();
        SetupSettingsToggle();
        SetupHandInputUI();

        SetupVolumeInput();
        SetupHeightInput();

        GetColor();
    }


    private void Update()
    {
        UpdateJoystickInputs();

        if (selectPanel != null && selectPanel.activeInHierarchy)
        {
            timer += Time.deltaTime;
            if (timer >= 10f)
            {
                timer = 0f;
                // 在这里执行你希望每 5 秒触发的逻辑
                NetClient.instance.StartRequest();
            }
        }

    }
    private void AddPointerClickEvent(Button button, UnityEngine.Events.UnityAction call)
    {
        if (button == null) return;
        EventTrigger trigger = button.AddComponent<EventTrigger>();
        if (trigger.triggers == null)
        {
            trigger.triggers = new List<EventTrigger.Entry>();
        }
        EventTrigger.Entry entry = new EventTrigger.Entry();
        entry.eventID = EventTriggerType.PointerClick;
        entry.callback.AddListener((data) => { call(); });
        trigger.triggers.Add(entry);

        EventTrigger.Entry submitEntry = new EventTrigger.Entry();
        submitEntry.eventID = EventTriggerType.Submit;
        submitEntry.callback.AddListener((data) => { call(); });
        trigger.triggers.Add(submitEntry);
    }

    private void RemovePointerClickEvent(Button button)
    {
        EventTrigger trigger = button.GetComponent<EventTrigger>();
        if (trigger != null)
        {
            Destroy(trigger);
        }
    }

    void OnSetServer(Button trans)
    {
        if (ip_inputField!=null)
        {
            ip_inputField.text = trans.transform.GetComponentInChildren<TextMeshProUGUI>().text;
        }

        if (tmpip_inputField != null) 
        {
            tmpip_inputField.text = trans.transform.GetComponentInChildren<TextMeshProUGUI>().text;
        }

        LoginBtnClick();
    }


    Vector3 openlistangle = new Vector3(0, 0, -180);
    Vector3 closelistangle = new Vector3(0, 0, -270);
    void OnServerListBtnClick()
    {
        clickindex++;
        if (clickindex % 2 == 0)
        {
            serverlist_page.gameObject.SetActive(false);
            openserverlist_btn.transform.localEulerAngles = closelistangle;
        }
        else
        {
            serverlist_page.gameObject.SetActive(true);
            openserverlist_btn.transform.localEulerAngles = openlistangle;
        }
    }


    public void LoginBtnClick()
    {
        ApplyVideoDecoderSelection();
#if !IS_ANDROID
        if (ip_inputField != null) 
        {
            if (ip_inputField.text != null)
            {
                if (RuntimeServerConfig.serverIp != ip_inputField.text)
                {
                    RuntimeServerConfig.serverIp = ip_inputField.text;
                    RuntimeServerConfig.Save();
                }

                if (!NetClient.instance.islan)
                {
                    NetClient.instance.StartRequest();
                }
                else
                {
                    DataManager.Instance.StartSending();
                    loginPanel.SetActive(false);
                    if (settingTog != null)
                    {
                        settingTog.gameObject.SetActive(false);
                    }
                settingTog.gameObject.SetActive(true);
                settingTog.isOn = true;
                }

                haveLogin = true;
            }
        }
#endif

#if IS_ANDROID
        if (tmpip_inputField != null)
        {
            if (tmpip_inputField.text != null)
            {
                if (RuntimeServerConfig.serverIp != tmpip_inputField.text)
                {
                    RuntimeServerConfig.serverIp = tmpip_inputField.text;
                    RuntimeServerConfig.Save();
                }

                if (!NetClient.instance.islan)
                {
                    NetClient.instance.StartRequest();
                }
                else
                {
                    DataManager.Instance.StartSending();
                    loginPanel.SetActive(false);
                    if (settingTog != null)
                    {
                        settingTog.gameObject.SetActive(false);
                    }
                settingTog.gameObject.SetActive(true);
                settingTog.isOn = true;
                }

                haveLogin = true;
            }
        }
#endif

    }

    private void ApplyVideoDecoderSelection()
    {
        if (DataManager.Instance == null)
        {
            return;
        }

        if (videoav1_tog != null && videoav1_tog.isOn)
        {
            DataManager.Instance.videoDecodeMode = DecoderFlavor.AV1;
            return;
        }

        if (videoh264_tog != null && videoh264_tog.isOn)
        {
            DataManager.Instance.videoDecodeMode = DecoderFlavor.H264;
            return;
        }

        if (videohevc_tog != null && videohevc_tog.isOn)
        {
            DataManager.Instance.videoDecodeMode = DecoderFlavor.HEVC;
            return;
        }
    }

    public void CreateRobotList(ServerRobotList list)
    {
        if (!IsRobotListChanged(list))
        {
            return;
        }

        loginPanel?.SetActive(false);
        selectPanel?.SetActive(true);
        robotListInitialized = true;

        if (list?.list == null || list.list.Length == 0)
        {
            ClearRobotButtons();
            SnapshotRobotList(list);
            return;
        }

        HashSet<string> incomingIds = new HashSet<string>();
        foreach (var item in list.list)
        {
            if (string.IsNullOrEmpty(item.device_id))
            {
                continue;
            }

            incomingIds.Add(item.device_id);
            if (!buttonDict.ContainsKey(item.device_id))
            {
                CreateRobotPrefab(item.name, item.device_id);
            }
            else
            {
                UpdateButtonIfChanged(item.name, item.device_id);
            }
        }

        RemoveMissingRobots(incomingIds);
        SnapshotRobotList(list);
    }

    private void CreateRobotPrefab(string name, string device_id)
    {
        GameObject temp = Instantiate(robotSelect_prefab);
        temp.gameObject.SetActive(true);
        temp.transform.SetParent(robotSelectContent.transform);
        temp.transform.localScale = Vector3.one;
        temp.transform.localPosition = Vector3.zero;
        temp.name = device_id;
        temp.transform.Find("Name").GetComponent<Text>().text = name;
        string tempid = device_id;
        var button = temp.GetComponent<Button>();
        button.onClick.RemoveAllListeners();
        button.onClick.AddListener(() => SelectRobot(tempid));
        buttonDict[device_id] = button;
    }

    void UpdateButtonIfChanged(string name, string device_id)
    {
        Button btn = buttonDict[device_id];
        RemovePointerClickEvent(btn);
        Text text = btn.GetComponentInChildren<Text>();
        // **名称变化：更新 UI**
        if (text.text != name)
        {
            text.text = name;
        }

        string tempid = device_id;
        btn.onClick.RemoveAllListeners();
        btn.onClick.AddListener(() => SelectRobot(tempid));
    }

    public void SelectRobot(string device_id)
    {
        selectPanel.SetActive(false);
        DataManager.Instance.OnSelectRobot(device_id);
    }

    private void RegisterRobotCommandButtons()
    {
        if (robotModeBtn != null)
        {
            robotModeBtn.onClick.AddListener(() =>
            {
                CyclePattern(ref robotModeIndex, robotModePattern, value =>
                {
                    if (DataManager.Instance != null && DataManager.Instance.currobotState != null)
                    {
                        DataManager.Instance.currobotState.SET_ROBOT_MODE = value;
                    }
                    StartCoroutine(ChangeBtnColor(robotModeBtn));
                    DebugState();
                });
            });
        }

        if (robotAudioBtn != null)
        {
            robotAudioBtn.onClick.AddListener(() =>
            {
                CyclePattern(ref robotAudioIndex, robotAudioPattern, value =>
                {
                    if (DataManager.Instance != null && DataManager.Instance.currobotState != null)
                    {
                        DataManager.Instance.currobotState.SET_AUDIO_MODE = value;

                    }
                    StartCoroutine(ChangeBtnColor(robotAudioBtn));
                    DebugState();

                });
            });
        }

        if (robotVideoBtn != null)
        {
            robotVideoBtn.onClick.AddListener(() =>
            {
                CyclePattern(ref robotVideoIndex, robotVideoPattern, value =>
                {
                    if (DataManager.Instance != null && DataManager.Instance.currobotState != null)
                    {
                        DataManager.Instance.currobotState.SET_VIDEO_MODE = value;
                    }
                    StartCoroutine(ChangeBtnColor(robotVideoBtn));
                    DebugState();

                });
            });
        }
    }

    private void CyclePattern(ref int index, int[] pattern, System.Action<int> setter)
    {
        if (pattern == null || pattern.Length == 0 || setter == null) return;
        int value = pattern[index];
        setter.Invoke(value);
        index = (index + 1) % pattern.Length;
    }

    private void SetupTTSUI()
    {
        //TTSCmdBtnList.Clear();
        if (TTSToggle != null)
        {
            TTSToggle.onValueChanged.AddListener(OnTTSToggleChanged);
            OnTTSToggleChanged(TTSToggle.isOn);
        }

        if (TTSCmdPlayButton != null) 
        {
            //TTSCmdBtnList.Add(TTSCmdPlayButton);
            TTSCmdPlayButton.onClick.AddListener(() =>
            {
                //HighlightButton(TTSCmdPlayButton, TTSCmdBtnList);
                StartCoroutine(ChangeBtnColor(TTSCmdPlayButton));
                SetTTSCommand("play", TTSCmdText);
            });
        }

        if (TTSCmdPauseButton != null) 
        {
            //TTSCmdBtnList.Add(TTSCmdPauseButton);
            TTSCmdPauseButton.onClick.AddListener(() =>
            {
                //HighlightButton(TTSCmdPauseButton, TTSCmdBtnList);
                StartCoroutine(ChangeBtnColor(TTSCmdPauseButton));
                SetTTSCommand("interrupt");
            });
        }

        if (TTSCmdStopButton!=null)
        {
            //TTSCmdBtnList.Add(TTSCmdStopButton);
            TTSCmdStopButton.onClick.AddListener(() =>
            {
                //HighlightButton(TTSCmdStopButton, TTSCmdBtnList);
                StartCoroutine(ChangeBtnColor(TTSCmdStopButton));
                SetTTSCommand("stop");
            });
        }
    }

    private IEnumerator ChangeBtnColor(Button btn) 
    {
        Color CurColor = new Color();
        Color TargetColor = new Color();
        if(btn == robotModeBtn || btn == robotAudioBtn || btn == robotVideoBtn) 
        {
            CurColor = ModeBtnDefaultColor;
            TargetColor = ModeBtnClickColor;
        }
        else if( btn == TTSCmdPlayButton || btn == ActionCmdPlayButton) 
        {
            CurColor = GroupBtnDefaultColor;
            TargetColor = StartBtnClickColor;
        }
        else if( btn == TTSCmdPauseButton || btn == ActionCmdPauseButton) 
        {
            CurColor = GroupBtnDefaultColor;
            TargetColor = PauseBtnClickColor ;
        }
        else if (btn == TTSCmdStopButton || btn == ActionCmdStopButton)
        {
            CurColor = GroupBtnDefaultColor;
            TargetColor = StopBtnClickColor;
        }

        btn.transform.GetComponent<Image>().color = TargetColor;
        yield return new WaitForSeconds(0.2f);
        btn.transform.GetComponent<Image>().color = CurColor;

    }



    private void OnTTSToggleChanged(bool isOn)
    {
        //if (TTSTogGroup != null) TTSTogGroup.SetActive(isOn);
        if (TTSListObj != null) TTSListObj.SetActive(isOn);
        if (isOn)
        {
            //ResetButtonBGs(TTSCmdBtnList);
            //ResetButtonBGs(TTSBtnList);
            BuildTTSList();
        }
    }

    private void BuildTTSList()
    {
        if (!ttsListNeedsRebuild || TTSListContent == null || robotSelect_prefab == null) return;
        ClearListContent(TTSListContent.transform);
        TTSBtnList.Clear();
        if (defaultTTSOptions == null)
        {
            ttsListNeedsRebuild = false;
            return;
        }
        foreach (var text in defaultTTSOptions)
        {
            if (string.IsNullOrEmpty(text)) continue;
            var item = Instantiate(robotSelect_prefab, TTSListContent.transform);
            item.SetActive(true);
            item.transform.localScale = Vector3.one;
            item.transform.localPosition = Vector3.zero;
            item.name = $"TTS_{text}";
            var label = item.transform.Find("Name")?.GetComponent<Text>();
            if (label != null)
            {
                label.text = text;
            }
            var button = item.GetComponent<Button>();
            if (button != null)
            {
                TTSBtnList.Add(button);
                string optionText = text;
                button.onClick.RemoveAllListeners();
                button.onClick.AddListener(() =>
                {
                    if (DataManager.Instance != null && DataManager.Instance.TTS != null)
                    {
                        TTSToggle.isOn = false;
                        TTSToggle.GetComponentInChildren<TextMeshProUGUI>().text = optionText;
                        TTSCmdText = optionText;
                    }
                    HighlightButton(button, TTSBtnList);
                });
            }
        }
        ResetButtonBGs(TTSBtnList);
        ttsListNeedsRebuild = false;
    }

    private void SetupActionUI()
    {
        //ActionCmdBtnList.Clear();
        if (ActionToggle != null)
        {
            ActionToggle.onValueChanged.AddListener(OnActionToggleChanged);
            OnActionToggleChanged(ActionToggle.isOn);
        }

        if (ActionCmdPlayButton != null) 
        {
            //ActionCmdBtnList.Add(ActionCmdPlayButton);
            ActionCmdPlayButton.onClick.AddListener(() =>
            {
                //HighlightButton(ActionCmdPlayButton, ActionCmdBtnList);
                StartCoroutine(ChangeBtnColor(ActionCmdPlayButton));

                SetActionCommand("play", ActionCmdText);
            });
        }

        if (ActionCmdPauseButton!=null)
        {
            //ActionCmdBtnList.Add(ActionCmdPauseButton);
            ActionCmdPauseButton.onClick.AddListener(() =>
            {
                //HighlightButton(ActionCmdPauseButton, ActionCmdBtnList);
                StartCoroutine(ChangeBtnColor(ActionCmdPauseButton));
                SetActionCommand("interrupt");
            });
        }

        if (ActionCmdStopButton != null) 
        {
            //ActionCmdBtnList.Add(ActionCmdStopButton);
            ActionCmdStopButton.onClick.AddListener(() =>
            {
                //HighlightButton(ActionCmdStopButton, ActionCmdBtnList);
                StartCoroutine(ChangeBtnColor(ActionCmdStopButton));
                SetActionCommand("stop");
            });
        }

    }

    private void OnActionToggleChanged(bool isOn)
    {
        //if (ActionTogGroup != null) ActionTogGroup.SetActive(isOn);
        if (ActionListObj != null) ActionListObj.SetActive(isOn);
        if (isOn)
        {
            //ResetButtonBGs(ActionCmdBtnList);
            //ResetButtonBGs(ActionBtnList);
            BuildActionList();
        }
    }

    private void BuildActionList()
    {
        if (!actionListNeedsRebuild || ActionListContent == null || robotSelect_prefab == null) return;
        ClearListContent(ActionListContent.transform);
        ActionBtnList.Clear();
        if (defaultActionOptions == null)
        {
            actionListNeedsRebuild = false;
            return;
        }
        foreach (var option in defaultActionOptions)
        {
            if (string.IsNullOrEmpty(option)) continue;
            var item = Instantiate(robotSelect_prefab, ActionListContent.transform);
            item.SetActive(true);
            item.transform.localScale = Vector3.one;
            item.transform.localPosition = Vector3.zero;
            item.name = $"Action_{option}";
            var label = item.transform.Find("Name")?.GetComponent<Text>();

            if (label != null)
            {
                label.text = option;
            }
            var button = item.GetComponent<Button>();
            if (button != null)
            {
                string actionName = option;
                ActionBtnList.Add(button);
                button.onClick.RemoveAllListeners();
                button.onClick.AddListener(() =>
                {
                    if (DataManager.Instance != null && DataManager.Instance.ACTION != null)
                    {
                        ActionToggle.isOn = false;
                        ActionToggle.GetComponentInChildren<TextMeshProUGUI>().text = actionName;
                        ActionCmdText = actionName;
                    }
                    HighlightButton(button, ActionBtnList);
                });
            }
        }
        ResetButtonBGs(ActionBtnList);
        actionListNeedsRebuild = false;
    }

    public void UpdateTTSOptions(List<string> newOptions)
    {
        if (newOptions == null) return;
        var normalizedOptions = NormalizeOptions(newOptions);
        if (!HasListChanged(defaultTTSOptions, normalizedOptions)) return;
        defaultTTSOptions = normalizedOptions;
        ttsListNeedsRebuild = true;
        BuildTTSList();
    }

    public void UpdateActionOptions(List<string> newOptions)
    {
        if (newOptions == null) return;
        var normalizedOptions = NormalizeOptions(newOptions);
        if (!HasListChanged(defaultActionOptions, normalizedOptions)) return;
        defaultActionOptions = normalizedOptions;
        actionListNeedsRebuild = true;
        BuildActionList();
    }

    private static List<string> NormalizeOptions(List<string> source)
    {
        List<string> result = new List<string>();
        if (source == null) return result;
        foreach (var option in source)
        {
            if (!string.IsNullOrEmpty(option))
            {
                result.Add(option);
            }
        }
        return result;
    }

    private bool HasListChanged(List<string> current, List<string> incoming)
    {
        if (incoming == null) return false;
        if (current == null) return incoming.Count > 0;
        if (current.Count != incoming.Count) return true;
        for (int i = 0; i < current.Count; i++)
        {
            if (!string.Equals(current[i], incoming[i], StringComparison.Ordinal))
            {
                return true;
            }
        }
        return false;
    }

    private void SetupSettingsToggle()
    {
        if (settingTog == null) return;
        settingTog.onValueChanged.AddListener(isOn =>
        {
            if (settingPanel != null)
            {
                settingPanel.SetActive(isOn);
            }
            if (!haveLogin) 
            {
                loginPanel.SetActive(!isOn);
            }

        });
    }
    private void SetupVolumeInput() 
    {
        if (volumeSlider != null)
        {
            volumeSlider.onValueChanged.AddListener(OnVolumeSliderChanged);
            OnVolumeSliderChanged(volumeSlider.value);
        }
    }

    void OnVolumeSliderChanged(float value) 
    {
        if (DataManager.Instance != null)
        {
            DataManager.Instance.currobotState.SET_AUDIO_VOLUME = value;
            volumeSliderText.text = value.ToString("F2");
           
        }
    }

    private void SetupHeightInput() 
    {
        if (heightSlider != null)
        {
            heightSlider.onValueChanged.AddListener(OnHeightSliderChanged);
            OnHeightSliderChanged(heightSlider.value);
        }
    }

    void OnHeightSliderChanged(float value) 
    {
        if (DataManager.Instance != null)
        {
            DataManager.Instance.robotheight = value;
            heightSliderText.text = value.ToString("F2");
           
        }
    }

    private void SetupHandInputUI()
    {
        if (leftSlider != null)
        {
            leftSlider.onValueChanged.AddListener(OnLeftSliderChanged);
            OnLeftSliderChanged(leftSlider.value);
        }

        if (rightSlider != null)
        {
            rightSlider.onValueChanged.AddListener(OnRightSliderChanged);
            OnRightSliderChanged(rightSlider.value);
        }
    }


    private void SetTTSCommand(string cmd,string? name = null)
    {
        if (DataManager.Instance != null && DataManager.Instance.TTS != null)
        {
            DataManager.Instance.TTS.cmd = cmd;
        }
        if (name != null) 
        {
            DataManager.Instance.TTS.text = TTSCmdText;
        }
    }
    

    private void SetActionCommand(string cmd, string? name = null)
    {
        if (DataManager.Instance != null && DataManager.Instance.ACTION != null)
        {
            DataManager.Instance.ACTION.cmd = cmd;
        }
        if (name != null)
        {
            DataManager.Instance.ACTION.name = ActionCmdText;
        }
    }

    private void OnLeftSliderChanged(float value)
    {
        if (DataManager.Instance != null)
        {
            DataManager.Instance.LeftHandAngle = value;
            leftSliderText.text = value.ToString("F2");
        }
    }

    private void OnRightSliderChanged(float value)
    {
        if (DataManager.Instance != null)
        {
            DataManager.Instance.RightHandAngle = value;
            rightSliderText.text = value.ToString("F2");
        }
    }

    private void UpdateJoystickInputs()
    {
        if (DataManager.Instance == null)
        {
            return;
        }

        if (leftJoy != null && DataManager.Instance.latestJoyL != null && DataManager.Instance.latestJoyL.Length >= 2)
        {
            DataManager.Instance.latestJoyL[0] = leftJoy.Horizontal;
            DataManager.Instance.latestJoyL[1] = leftJoy.Vertical;
        }

        if (rightJoy != null && DataManager.Instance.latestJoyR != null && DataManager.Instance.latestJoyR.Length >= 2)
        {
            DataManager.Instance.latestJoyR[0] = rightJoy.Horizontal;
            DataManager.Instance.latestJoyR[1] = rightJoy.Vertical;
        }
    }

    private bool IsRobotListChanged(ServerRobotList list)
    {
        if (list?.list == null || list.list.Length == 0)
        {
            return !robotListInitialized || lastRobotSnapshot.Count != 0;
        }

        HashSet<string> seenIds = new HashSet<string>();
        foreach (var robot in list.list)
        {
            if (robot == null || string.IsNullOrEmpty(robot.device_id))
            {
                continue;
            }

            if (!seenIds.Add(robot.device_id))
            {
                continue;
            }

            string incomingName = robot.name ?? string.Empty;
            if (!lastRobotSnapshot.TryGetValue(robot.device_id, out var cachedName))
            {
                return true;
            }

            if (!string.Equals(cachedName, incomingName, StringComparison.Ordinal))
            {
                return true;
            }
        }

        return seenIds.Count != lastRobotSnapshot.Count;
    }

    private void SnapshotRobotList(ServerRobotList list)
    {
        lastRobotSnapshot.Clear();
        if (list?.list == null)
        {
            return;
        }

        foreach (var robot in list.list)
        {
            if (robot == null || string.IsNullOrEmpty(robot.device_id))
            {
                continue;
            }

            string normalizedName = robot.name ?? string.Empty;
            if (!lastRobotSnapshot.ContainsKey(robot.device_id))
            {
                lastRobotSnapshot.Add(robot.device_id, normalizedName);
            }
            else
            {
                lastRobotSnapshot[robot.device_id] = normalizedName;
            }
        }
    }

    private void RemoveMissingRobots(HashSet<string> incomingIds)
    {
        if (incomingIds == null || incomingIds.Count == 0)
        {
            ClearRobotButtons();
            return;
        }

        List<string> toRemove = null;
        foreach (var pair in buttonDict)
        {
            if (!incomingIds.Contains(pair.Key))
            {
                if (pair.Value != null)
                {
                    Destroy(pair.Value.gameObject);
                }
                toRemove ??= new List<string>();
                toRemove.Add(pair.Key);
            }
        }

        if (toRemove != null)
        {
            foreach (var id in toRemove)
            {
                buttonDict.Remove(id);
            }
        }
    }

    private void ClearRobotButtons()
    {
        foreach (var pair in buttonDict)
        {
            if (pair.Value != null)
            {
                Destroy(pair.Value.gameObject);
            }
        }

        buttonDict.Clear();
    }

    private void ClearListContent(Transform parent)
    {
        if (parent == null) return;
        for (int i = parent.childCount - 1; i >= 0; i--)
        {
            Destroy(parent.GetChild(i).gameObject);
        }
    }

    private void HighlightButton(Button targetButton, List<Button> buttonGroup)
    {
        if (targetButton == null || buttonGroup == null) return;
        foreach (var btn in buttonGroup)
        {
            SetButtonBGState(btn, btn == targetButton);
        }
    }

    private void ResetButtonBGs(List<Button> buttons)
    {
        if (buttons == null) return;
        foreach (var btn in buttons)
        {
            SetButtonBGState(btn, false);
        }
    }

    private void SetButtonBGState(Button button, bool isActive)
    {
        if (button == null) return;
        Text nametext = button.transform.Find("Name").GetComponent<Text>();
        
        //if (bg != null)
        //{
        //    bg.gameObject.SetActive(isActive);
        //}
        if (isActive) 
        {
            if (nametext != null) 
            {
                nametext.color = ClickPrefabTextColor;
            }
            button.transform.GetComponent<Image>().color = ClickPrefabBtnColor;
        }
        else 
        {
            if (nametext != null)
            {
                nametext.color = DefaultPrefabTextColor; ;
            }
            button.transform.GetComponent<Image>().color = DefaultPrefabBtnColor;

        }
    }

    void DebugState()
    {
        string robotMode = FormatEnumValue<RobotMode>(DataManager.Instance.currobotState.SET_ROBOT_MODE);
        string videoMode = FormatEnumValue<VideoMode>(DataManager.Instance.currobotState.SET_VIDEO_MODE);
        string audioMode = FormatEnumValue<AudioMode>(DataManager.Instance.currobotState.SET_AUDIO_MODE);


        DebugTextManager.Instance._debugClientstatetext.text =
            $"Client: Robot Mode = {robotMode} Audio Mode = {audioMode} Video Mode = {videoMode}";


  }

    private static string FormatEnumValue<T>(int value) where T : struct
    {
        Type enumType = typeof(T);
        if (enumType.IsEnum && Enum.IsDefined(enumType, value))
        {
            return Enum.GetName(enumType, value);
        }

        return $"Unknown({value})";
    }
    /// <summary>
    /// 将16进制的颜色转换成0-1
    /// </summary>
    private void GetColor()
    {
        ModeBtnDefaultColor = HexToColor("#1A2236");
        ModeBtnClickColor = HexToColor("#004E63");
        GroupBtnDefaultColor = HexToColor("#0D1622");
        StartBtnClickColor = HexToColor("#00FF17");
        PauseBtnClickColor = HexToColor("#FFB020");
        StopBtnClickColor = HexToColor("#FF0E00");


        DefaultPrefabTextColor = HexToColor("#2DE1EB");
        ClickPrefabTextColor = HexToColor("#FFFFFF");

        DefaultPrefabBtnColor = HexToColor("#132E3F");
        ClickPrefabBtnColor = HexToColor("#00CFEA");
        
}



    public static Color HexToColor(string hex)
    {
        // 移除#号（兼容带/不带#的输入）
        hex = hex.TrimStart('#');

        // 解析RGB分量（十六进制转十进制）
        int r = int.Parse(hex.Substring(0, 2), System.Globalization.NumberStyles.HexNumber);
        int g = int.Parse(hex.Substring(2, 2), System.Globalization.NumberStyles.HexNumber);
        int b = int.Parse(hex.Substring(4, 2), System.Globalization.NumberStyles.HexNumber);

        // 转换为0-1的浮点数并返回Color
        return new Color(r / 255f, g / 255f, b / 255f, 1.0f);
    }


}
