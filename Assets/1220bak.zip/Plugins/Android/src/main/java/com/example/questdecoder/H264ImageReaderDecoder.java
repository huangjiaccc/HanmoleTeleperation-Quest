package com.example.questdecoder;

import android.graphics.ImageFormat;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.view.Surface;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * Reads an MP4/H.264 asset using MediaExtractor, decodes through MediaCodec, and exposes frames
 * as RGBA byte arrays that Unity can upload to textures.
 */
public class H264ImageReaderDecoder implements ImageReader.OnImageAvailableListener {
    private static final String TAG = "H264ImageReaderDecoder";
    private static final int MAX_QUEUE = 4;

    private final ArrayBlockingQueue<byte[]> frameQueue = new ArrayBlockingQueue<>(MAX_QUEUE);
    private MediaExtractor extractor;
    private MediaCodec decoder;
    private ImageReader imageReader;
    private Surface decodeSurface;
    private Thread extractorThread;
    private HandlerThread imageThread;
    private Handler imageHandler;
    private volatile boolean running;
    private int width;
    private int height;
    private boolean verbose;
    private long frameCounter;
    private long samplesSubmitted;
    private long eosSignals;
    private long framesRendered;
    private long firstSampleTimeUs = -1;
    private long playbackStartNs;
    private byte[] yuvBuffer;
    private byte[] yRowScratch;
    private byte[] uRowScratch;
    private byte[] vRowScratch;

    public void setVerbose(boolean enable) {
        verbose = enable;
        Log.i(TAG, "Verbose logging " + (enable ? "enabled" : "disabled"));
    }

    private void logDebug(String message) {
        if (verbose) {
            Log.d(TAG, message);
        }
    }

    public boolean open(String absolutePath) {
        release();

        File source = new File(absolutePath);
        if (!source.exists()) {
            Log.w(TAG, "Video source does not exist: " + absolutePath);
        } else {
            logDebug("Opening source: " + absolutePath + " (" + source.length() + " bytes)");
        }

        extractor = new MediaExtractor();
        try {
            extractor.setDataSource(absolutePath);
        } catch (IOException io) {
            Log.e(TAG, "Unable to set data source", io);
            release();
            return false;
        }

        MediaFormat format = null;
        for (int i = 0; i < extractor.getTrackCount(); i++) {
            MediaFormat candidate = extractor.getTrackFormat(i);
            String mime = candidate.getString(MediaFormat.KEY_MIME);
            if (mime != null && mime.startsWith("video/")) {
                extractor.selectTrack(i);
                format = candidate;
                break;
            }
        }

        if (format == null) {
            Log.e(TAG, "No video track found in " + absolutePath);
            release();
            return false;
        }

        width = format.getInteger(MediaFormat.KEY_WIDTH);
        height = format.getInteger(MediaFormat.KEY_HEIGHT);
        String trackMime = format.getString(MediaFormat.KEY_MIME);
        logDebug("Selected video track: " + width + "x" + height + " (" + trackMime + ")");

        imageReader = ImageReader.newInstance(width, height, ImageFormat.YUV_420_888, 5);
        decodeSurface = imageReader.getSurface();

        String mime = trackMime;
        try {
            decoder = MediaCodec.createDecoderByType(mime);
            format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible);
            decoder.configure(format, decodeSurface, null, 0);
            decoder.start();
            logDebug("MediaCodec configured and started with YUV output.");
        } catch (IOException io) {
            Log.e(TAG, "Unable to start decoder", io);
            release();
            return false;
        }

        running = true;
        samplesSubmitted = 0;
        eosSignals = 0;
        frameCounter = 0;
        framesRendered = 0;
        firstSampleTimeUs = -1;
        playbackStartNs = 0;
        startExtractorThread();
        registerImageListener();
        return true;
    }

    public void start() {
        running = true;
    }

    public void stop() {
        running = false;
    }

    public void release() {
        running = false;
        logDebug("Releasing decoder resources.");

        if (extractor != null) {
            extractor.release();
            extractor = null;
        }

        if (decoder != null) {
            try {
                decoder.stop();
            } catch (Exception ignored) {
            }
            decoder.release();
            decoder = null;
        }

        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }

        if (decodeSurface != null) {
            decodeSurface.release();
            decodeSurface = null;
        }

        if (extractorThread != null) {
            extractorThread.interrupt();
            extractorThread = null;
        }

        if (imageThread != null) {
            imageThread.quitSafely();
            imageThread = null;
            imageHandler = null;
        }

        frameQueue.clear();
        firstSampleTimeUs = -1;
        playbackStartNs = 0;
    }

    public byte[] dequeueFrame() {
        return frameQueue.poll();
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public long getProducedFrameCount() {
        return frameCounter;
    }

    public int getPendingFrameCount() {
        return frameQueue.size();
    }

    public long getSamplesSubmitted() {
        return samplesSubmitted;
    }

    public boolean isRunning() {
        return running;
    }

    public long getFramesRendered() {
        return framesRendered;
    }

    private void startExtractorThread() {
        if (extractorThread != null && extractorThread.isAlive()) {
            extractorThread.interrupt();
        }

        extractorThread = new Thread(this::drainExtractorLoop, "QuestLocalExtractor");
        extractorThread.setPriority(Thread.NORM_PRIORITY + 1);
        extractorThread.start();
    }

    private void registerImageListener() {
        if (imageHandler == null) {
            imageThread = new HandlerThread("QuestLocalImageReader");
            imageThread.start();
            imageHandler = new Handler(imageThread.getLooper());
        }

        imageReader.setOnImageAvailableListener(this, imageHandler);
        logDebug("ImageReader listener registered.");
    }

    private void drainExtractorLoop() {
        if (extractor == null || decoder == null) {
            return;
        }

        boolean inputDone = false;
        boolean outputDone = false;
        MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
        logDebug("Starting extractor drain.");
        while (running && !Thread.interrupted()) {
            if (!inputDone) {
                int inputIndex = decoder.dequeueInputBuffer(10_000);
                if (inputIndex >= 0) {
                    ByteBuffer buffer = decoder.getInputBuffer(inputIndex);
                    if (buffer == null) {
                        continue;
                    }

                    int sampleSize = extractor.readSampleData(buffer, 0);
                    if (sampleSize < 0) {
                        decoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                        inputDone = true;
                        eosSignals++;
                        logDebug("End-of-stream signaled to decoder. Total samples: " + samplesSubmitted);
                    } else {
                        long sampleTime = extractor.getSampleTime();
                        int sampleFlags = extractor.getSampleFlags();
                        if (firstSampleTimeUs < 0 && sampleTime >= 0) {
                            firstSampleTimeUs = sampleTime;
                            playbackStartNs = System.nanoTime();
                        }
                        decoder.queueInputBuffer(inputIndex, 0, sampleSize, sampleTime, sampleFlags);
                        extractor.advance();
                        pacePlayback(sampleTime);
                        samplesSubmitted++;
                        if (verbose && samplesSubmitted % 30 == 0) {
                            Log.d(TAG, "Submitted sample #" + samplesSubmitted + " size=" + sampleSize + " timeUs=" + sampleTime);
                        }
                    }
                }
            } else {
                try {
                    Thread.sleep(5);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }

            if (!outputDone) {
                int outputIndex = decoder.dequeueOutputBuffer(bufferInfo, 10_000);
                if (outputIndex >= 0) {
                    decoder.releaseOutputBuffer(outputIndex, true);
                    framesRendered++;
                    if (verbose && framesRendered % 30 == 0) {
                        Log.d(TAG, "Released output frame #" + framesRendered + " size=" + bufferInfo.size);
                    }

                    if ((bufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        logDebug("Output end-of-stream signaled.");
                        outputDone = true;
                    }
                } else if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat newFormat = decoder.getOutputFormat();
                    logDebug("Decoder output format changed: " + newFormat);
                }
            }

            if (inputDone && outputDone) {
                break;
            }
        }
    }

    private void pacePlayback(long sampleTimeUs) {
        if (firstSampleTimeUs < 0 || playbackStartNs == 0) {
            return;
        }

        long relativeUs = sampleTimeUs - firstSampleTimeUs;
        if (relativeUs < 0) {
            relativeUs = 0;
        }

        long targetNs = playbackStartNs + relativeUs * 1_000L;
        long nowNs = System.nanoTime();
        long delayNs = targetNs - nowNs;
        if (delayNs <= 0) {
            return;
        }

        long millis = delayNs / 1_000_000L;
        int nanos = (int) (delayNs % 1_000_000L);
        try {
            Thread.sleep(millis, nanos);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    @Override
    public void onImageAvailable(ImageReader reader) {
        if (!running) {
            return;
        }

        Image image = null;
        try {
            image = reader.acquireNextImage();
            if (image == null) {
                if (verbose) {
                    Log.d(TAG, "onImageAvailable invoked but no image acquired.");
                }
                return;
            }
            logDebug("Processing new decoded frame.");

            byte[] yuv = extractI420(image);
            if (yuv != null) {
                boolean enqueued = false;
                while (running && !enqueued) {
                    try {
                        if (frameQueue.offer(yuv, 15, TimeUnit.MILLISECONDS)) {
                            enqueued = true;
                        } else if (verbose) {
                            Log.d(TAG, "Frame queue full; waiting for consumer.");
                        }
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                }

                if (enqueued) {
                    frameCounter++;
                    if (verbose && frameCounter % 30 == 0) {
                        Log.d(TAG, "Queued frame #" + frameCounter + " (" + yuv.length + " bytes), queue=" + frameQueue.size());
                    }
                }
            }
        } catch (Exception ex) {
            Log.e(TAG, "Image processing error", ex);
        } finally {
            if (image != null) {
                image.close();
            }
        }
    }

    private byte[] extractI420(Image image) {
        Image.Plane[] planes = image.getPlanes();
        if (planes == null || planes.length < 3) {
            return null;
        }

        int ySize = width * height;
        int chromaWidth = width / 2;
        int chromaHeight = height / 2;
        int planeSize = chromaWidth * chromaHeight;
        int required = ySize + planeSize * 2;
        if (yuvBuffer == null || yuvBuffer.length != required) {
            yuvBuffer = new byte[required];
        }

        yRowScratch = copyPlane(planes[0], width, height, yuvBuffer, 0, yRowScratch);
        uRowScratch = copyPlane(planes[1], chromaWidth, chromaHeight, yuvBuffer, ySize, uRowScratch);
        vRowScratch = copyPlane(planes[2], chromaWidth, chromaHeight, yuvBuffer, ySize + planeSize, vRowScratch);
        return yuvBuffer;
    }

    private static byte[] copyPlane(
            Image.Plane plane,
            int width,
            int height,
            byte[] out,
            int offset,
            byte[] scratch) {
        ByteBuffer buffer = plane.getBuffer();
        int rowStride = plane.getRowStride();
        int pixelStride = plane.getPixelStride();
        int bufferLimit = buffer.limit();

        for (int row = 0; row < height; row++) {
            int rowStart = row * rowStride;
            for (int col = 0; col < width; col++) {
                int index = rowStart + col * pixelStride;
                byte value;
                if (index >= bufferLimit) {
                    value = offset > 0 ? out[offset - 1] : 0;
                } else {
                    value = buffer.get(index);
                }
                out[offset++] = value;
            }
        }

        buffer.position(0);
        return scratch;
    }
}
